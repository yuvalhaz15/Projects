﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WindowsFormsApp1
{
    public enum RequestStatusEnum
    {
        Approved,
        DisApproved,
        Waiting_For_Handling
        

    }
}