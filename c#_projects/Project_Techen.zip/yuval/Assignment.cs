﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public class Assignment
    {
        private Calendar calendar;
        private Employee simulationDeveloper;
        private Employee projectManager;
        private Project project;
        private string note;
        private DateTime startHour;
        private DateTime finishHour;

        public Assignment(DateTime date, Employee simulationDeveloper, Employee projectManager, Project project, string note, DateTime startHour, DateTime finishHour, bool isNew)
        {
            Calendar ca = Program.isCalendarExist(date);
            if (ca == null)
            {
                ca = new Calendar(date, true);
            }
            this.calendar = ca;
            this.simulationDeveloper = simulationDeveloper;
            this.projectManager = projectManager;
            this.project = project;
            this.note = note;
            this.startHour = startHour;
            this.finishHour = finishHour;
            this.calendar.getAssignments().Add(this);
            this.simulationDeveloper.getAssignments().Add(this);
            this.projectManager.getAssignments().Add(this);
            if (isNew)
            {
                this.create_assignment();
                Program.assignments.Add(this);

            }
        }
        public Project getProject()
        {
            return this.project;
        }

        private void create_assignment()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_assignment @assignmentDate, @createdBy, @assignTo, @projectID, @note, @startHour, @finishHour";
            c.Parameters.AddWithValue("@assignmentDate", this.calendar.getDate());
            c.Parameters.AddWithValue("@createdBy", this.projectManager.getId());
            c.Parameters.AddWithValue("@assignTo", this.simulationDeveloper.getId());
            c.Parameters.AddWithValue("@projectID", this.project.getProjectID());
            c.Parameters.AddWithValue("@note", this.note);
            c.Parameters.AddWithValue("@startHour", this.startHour);
            c.Parameters.AddWithValue("@finishHour", this.finishHour);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


        public void Delete_assignment()
        {
            Program.assignments.Remove(this);
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.SP_delete_assignment @assignmentDate, @assignTo, @projectID";
            c.Parameters.AddWithValue("@assignmentDate", this.calendar.getDate());
            c.Parameters.AddWithValue("@assignTo", this.simulationDeveloper.getId());
            c.Parameters.AddWithValue("@projectID", this.project.getProjectID());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }
    }
}