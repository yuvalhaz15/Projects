﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class readCustomer : Form
    {
        private Customer customerToMakeActionON;
        private string customerId;
        public readCustomer()
        {
            InitializeComponent();
            addValuesToCustomersList();
        }



        private void addValuesToCustomersList()
        {
            foreach (Customer c in Program.customers)
                customerList.Items.Add(c.getID());

        }



        private void customersList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.customerId = this.customerList.Text;
            customerToMakeActionON = this.matchCustomerToId();
        }

        private void checkDetailsButton_Click(object sender, EventArgs e)
        {
            if (customerToMakeActionON != null)
                customerToMakeActionON.readCustomer();
            else
                MessageBox.Show("please choose customer");
        }


        private Customer matchCustomerToId()
        {
            foreach (Customer C in Program.customers)
                if (this.customerId == C.getID())
                    return C;
            return null;
        }
    }
}
