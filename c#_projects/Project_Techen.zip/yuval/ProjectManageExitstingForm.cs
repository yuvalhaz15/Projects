﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ProjectManageExitstingForm : Form
    {
        private Project projectToMakeActionOn;
        private string projectId;
        public ProjectManageExitstingForm()
        {
            InitializeComponent();
            addValuesToProjectsList();

        }

        private void addValuesToProjectsList()
        {
            foreach (Project p in Program.ProjectsInProgress)
            {
                this.projectsList.Items.Add(p.getProjectID());

            }

            foreach (Project p in Program.ProjectsInArchive)
            {
                this.projectsList.Items.Add(p.getProjectID());

            }


        }

        private void btn_ExistingProjBack_Click(object sender, EventArgs e)
        {
            ProjectManagementForm projectManagementForm = new ProjectManagementForm();
            this.Hide();
            projectManagementForm.ShowDialog();
            this.Close();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {

            if (projectToMakeActionOn != null)
                this.projectToMakeActionOn.readProject();
             else
                MessageBox.Show("Please choose Project");
        }

        private void projectsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.projectId = this.projectsList.Text;
            this.projectToMakeActionOn = matchIdToProject();
        }

        private Project matchIdToProject()
        {
            foreach (Project P in Program.ProjectsInArchive)
                if (P.getProjectID() == this.projectId)
                    return P;
            foreach (Project P in Program.ProjectsInProgress)
                if (P.getProjectID() == this.projectId)
                    return P;

            return null;
        }

        private void updateProjectButton_Click(object sender, EventArgs e)
        {
            if (projectToMakeActionOn != null)
            {
                ProjectUpdate puForm = new ProjectUpdate(this.projectToMakeActionOn);
                puForm.Show();
            }
            else
                MessageBox.Show("Please choose Project");
        }
    }
}
