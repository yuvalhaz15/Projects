﻿namespace WindowsFormsApp1
{
    public enum EStatus
    {
        Current,
        Past,
        In_learning



    }
}