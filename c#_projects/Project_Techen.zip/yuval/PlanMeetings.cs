﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class PlanMeetings : Form
    {
        private DateTime date;

        public PlanMeetings()
        {
            InitializeComponent();
            
        }

       

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
             
                

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
             DateTime date = dateTimePicker1.Value.Date;
            if (date.DayOfWeek == DayOfWeek.Saturday) 
            {
                MessageBox.Show("You choose saturday, please choose correct date");
            }

            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Choose date in the future");
            }

            foreach (Calendar C in Program.calendars)
            {
                if(date == C.getDate())
                {   
                    foreach(Meeting m in C.getMeetings())
                    {
                        Meetings_On_Day.Items.Add(m.getCustomer().getID());
                        Meetings_On_Day.Items.Add(m.getTimeOfmeeting());
                    }
                }
            }

         
        }

        private void btn_PlanMeetings_NewMeet_Click(object sender, EventArgs e)
        {
            date = dateTimePicker1.Value.Date;
            if (date != null)
            {
                CreateNewMeeting createNewMeeting = new CreateNewMeeting(date);
                this.Hide();
                createNewMeeting.ShowDialog();
                this.Close();
            }
            else MessageBox.Show("Must choose date!");

        }

        private void btn_PlanMeetings_Back_Click(object sender, EventArgs e)
        {
            MarketingManagrWelcome marketingManagrWelcome = new MarketingManagrWelcome();
            this.Hide();
            marketingManagrWelcome.ShowDialog();
            this.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Meetings_On_Day_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
