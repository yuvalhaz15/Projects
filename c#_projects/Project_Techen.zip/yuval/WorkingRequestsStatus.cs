﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class WorkingRequestsStatus : Form
    {private string wrNum;
        public WorkingRequestsStatus()
        {
            InitializeComponent();
            addValuesToList();
        }


        private void addValuesToList()
        {
            foreach (WorkingRequest w in Program.workingRequests)
             if (w.get_RequestStatusEnum().ToString() == "Waiting_For_Handling") 
               this.workingRequestListBox.Items.Add(w.getRequestNum());
        }
       

        private WorkingRequest matchWr()
        {
            foreach (WorkingRequest wr in Program.workingRequests)
                if (wr.getRequestNum() == this.wrNum)
                    return wr;
            return null;
        }

        private void btn_approveReq_Click(object sender, EventArgs e)
        {
            if (this.wrNum != null)
            {
                ApproveWorkingRequest approveWorkingRequest = new ApproveWorkingRequest(matchWr());

                approveWorkingRequest.Show();
            }
            else
                MessageBox.Show("Please choose working request");
        }

    

        private void workingRequestListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.wrNum = this.workingRequestListBox.Text;
           
        }
    }
}
