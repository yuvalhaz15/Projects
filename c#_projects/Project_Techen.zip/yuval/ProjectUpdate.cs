﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ProjectUpdate : Form
    {
        private Project projectToUpdateDetails;
        private Customer customer;
        private string projectID;
        private string projectName;
        private int complexityLevel;
        private DateTime startTime;
        private DateTime endTime;
        private double cost;
        private DateTime lastSimulationUpdate;
        private ProjectStatusEnum status;
        private string simulationLocation;
        private string summeryReport;
        private Employee manager;
        public ProjectUpdate(Project p)
        {
            InitializeComponent();
            this.projectToUpdateDetails = p;
            initializeData();
           
        }

        private void initializeData()
        {
            setIDTextBox();
            setNameTextBox();
            setEndTime();
            setCost();
            setSimulationTextBox();
            setCustomerIdTextBox();
            setSummaryTextBox();
            setManagerIdTextBox();
            setProjectStatusList();
            setLastSimulationUpdate();
            setComplexityLevel();
            setStartTime();
        }

        private void setStartTime()
        {
            this.startTime = this.projectToUpdateDetails.getStartTime();
                
        }

        private void setComplexityLevel()
        {
            this.textBox_ProjUpd_CompLevel.Text = this.projectToUpdateDetails.getComplexityLevel()+"";
            this.complexityLevel = this.projectToUpdateDetails.getComplexityLevel();
        }

        private void setLastSimulationUpdate()
        {
            this.lastUpdateDateTimePicker.Value = this.projectToUpdateDetails.getLastSimulationUpdateDT();
            this.lastSimulationUpdate= this.projectToUpdateDetails.getLastSimulationUpdateDT();
        }

        private void setManagerIdTextBox()
        {
            this.managerIdTextBox.Text = this.projectToUpdateDetails.getManager().getId();
            this.manager = this.projectToUpdateDetails.getManager();

        }

        private void setSummaryTextBox()
        {
            this.textBox_ProjUpd_SummRepLoc.Text = this.projectToUpdateDetails.getSummaryReport();
            this.summeryReport = this.projectToUpdateDetails.getSummaryReport();
        }

        private void setCustomerIdTextBox()
        {
            this.customerIdTextBox.Text = this.projectToUpdateDetails.getCustomer().getID();
            this.customer = this.projectToUpdateDetails.getCustomer();
        }

        private void setSimulationTextBox()
        {
            this.textBox_ProjUpd_SimuLoc.Text = this.projectToUpdateDetails.getSimulationLocation();
            this.simulationLocation = this.projectToUpdateDetails.getSimulationLocation();
        }

        private void setCost()
        {
            this.textBox_ProjUpd_Cost.Text = this.projectToUpdateDetails.getCost()+"";
            this.cost = this.projectToUpdateDetails.getCost();

        }

        private void setEndTime()
        {
            this.dateTimePicker_ProjUpd_EndTime.Value = this.projectToUpdateDetails.getEndTime();
            this.endTime=this.projectToUpdateDetails.getEndTime();
        }

        private void setNameTextBox()
        {
            this.textBox_ProjUpd_Name.Text = this.projectToUpdateDetails.getProjectName();
            this.projectName= this.projectToUpdateDetails.getProjectName();

        }

        private void setIDTextBox()
        {
            this.textBox_ProjUpd_ProjectID.Text = this.projectToUpdateDetails.getProjectID();
            this.projectID = this.projectToUpdateDetails.getProjectID();
        }
        private void setProjectStatusList()
        {
            this.comboBox_ProjUpd_Status.Text = this.projectToUpdateDetails.getStatus().ToString();
            this.status = this.projectToUpdateDetails.getStatus();
            setAllValues();
        }

        private void setAllValues()
        {
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Data_Analysing);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Data_Collecting);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.First_Simulation);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.In_Archive);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Main_Simulation);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Schedule_Planning);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Summary_Report_Writing);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Waiting_For_Customer_Approval);
            this.comboBox_ProjUpd_Status.Items.Add(ProjectStatusEnum.Waiting_For_Manager_Approval);








        }

        private void btn_ProjUpd_Exit_Click(object sender, EventArgs e)
        {
            ProjectManagementForm projectManagementForm = new ProjectManagementForm();
            this.Hide();
            projectManagementForm.ShowDialog();
            this.Close();
        }

        private void setProjectIdButton_Click(object sender, EventArgs e)
        {
            if (IdIsValid())
            {
                this.projectID = textBox_ProjUpd_ProjectID.Text;
                MessageBox.Show("Project ID was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!!Project ID is unvalid");
                textBox_ProjUpd_ProjectID.Text = this.projectID;

            }

        }

        private bool IdIsValid()
        {
            return textBox_ProjUpd_ProjectID.Text.Length > 0 && textBox_ProjUpd_ProjectID.Text.Length <= 10 && allNumbers(textBox_ProjUpd_ProjectID.Text) && !idExist(textBox_ProjUpd_ProjectID.Text);

        }

        private bool allNumbers(string toCheck)
        {
            for (int i = 0; i < toCheck.Length; i++)

                if (toCheck[i] < '0' || toCheck[i] > '9')
                    return false;

            return true;
        }
        private bool idExist(String idToCheck)
        {
            if (Program.ProjectsInArchive == null && Program.ProjectsInProgress == null)
                return false;
            foreach (Project p in Program.ProjectsInArchive)
                if (idToCheck == p.getProjectID())
                    return true;
            foreach (Project p in Program.ProjectsInProgress)
                if (idToCheck == p.getProjectID())
                    return true;
            return false;
        }

        private void setProjectNameButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(textBox_ProjUpd_Name.Text))
            {
                this.projectName = textBox_ProjUpd_Name.Text;
                MessageBox.Show("Project name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                textBox_ProjUpd_Name.Text = this.projectName; ;


            }
        }
        private bool nameIsValid(string name)
        {

            return allLetters(name) && name.Length > 0 && name.Length < 20;
        }
        private bool allLetters(string name)
        {
            for (int i = 0; i < name.Length; i++)
               
                    
                if ((name[i] < 'a' || name[i] > 'z')&&name[i]!=' ')
                    if ((name[i] < 'A' || name[i] > 'Z'))
                        return false;

            return true;
        }

        private void dateTimePicker_ProjUpd_EndTime_ValueChanged(object sender, EventArgs e)
        {
            if (endDateIsValid())
            {
                this.endTime = dateTimePicker_ProjUpd_EndTime.Value;
               
            }
            else
            {
                MessageBox.Show("Date is unvalid");


            }


        }

        private bool endDateIsValid()
        {
            return dateTimePicker_ProjUpd_EndTime.Value>=this.startTime;
        }

        private void setCostButton_Click(object sender, EventArgs e)
        {
            if (double.Parse(this.textBox_ProjUpd_Cost.Text) > 0)
            {
                this.cost = double.Parse(this.textBox_ProjUpd_Cost.Text);
                MessageBox.Show("Cost  was changed successfully");

            }
            else
            {
                MessageBox.Show("Erro!! Cost  un valid");
                this.textBox_ProjUpd_Cost.Text = this.cost+"";
            }




        }

        private void textBox_ProjUpd_SimuLoc_TextChanged(object sender, EventArgs e)
        {
            if (simulationLocationIsValid())
            {
                this.simulationLocation = this.textBox_ProjUpd_SimuLoc.Text;
                MessageBox.Show("Simulation location  was changed successfully");
            }
            else
            {
                MessageBox.Show("Error !!Simulation location  un valid");
                this.textBox_ProjUpd_SimuLoc.Text = this.simulationLocation;

            }


        }

        private bool simulationLocationIsValid()
        {
            return this.textBox_ProjUpd_CompLevel.Text.Length <= 30;
        }
       
        private void btn_ProjUpd_Update_Click(object sender, EventArgs e)
        {

            this.projectToUpdateDetails.updateProject(this.customer, this.projectID, this.projectName, this.manager, this.status, this.startTime, this.endTime, this.complexityLevel, this.cost, this.lastSimulationUpdate, this.simulationLocation, this.summeryReport, this.lastSimulationUpdate);
            if (this.status.ToString() == "In_Archive")
            {
                Program.ProjectsInProgress.Remove(projectToUpdateDetails);
                Program.ProjectsInArchive.Add(projectToUpdateDetails);

            }

            MessageBox.Show("Project updated successfully");



        }

        private Customer seekCustomer()
        {
            if (Program.customers == null)
                return null;
            foreach (Customer c in Program.customers)
                if (c.getID() == this.customerIdTextBox.Text)
                    return c;
            return null;
        }

        

        private bool managerIdWasInit()
        {
            return this.manager != null;
        }

        private bool customerIdWasInit()
        {
            return this.customer != null;
        }

        private bool projectSimulationLocationWasInit()
        {
            return this.simulationLocation != null && this.simulationLocation.Length > 0;
        }

        private bool projectEndTimeWasInit()
        {
            return this.endTime != null;
        }

        private bool projectCostWasInit()
        {
            return this.cost != 0;
        }

        private bool projectNameWasInit()
        {
            return this.projectName != null && this.projectName.Length > 0;
        }

        private bool projectIDWasInit()
        {
            return this.projectID != null && this.projectID.Length > 0;
        }

        private void summaryProjectSetButton_Click(object sender, EventArgs e)
        {
            if (this.textBox_ProjUpd_SummRepLoc.Text.Length <= 30)
            {
                this.summeryReport = this.textBox_ProjUpd_SummRepLoc.Text;
                MessageBox.Show("Summary was add successfully");
            }
            else
            {
                MessageBox.Show("Summary must be less then 30 characters");

            }

        }

        private void setCustomerIdButton_Click(object sender, EventArgs e)
        {
            if (cusomerIdIsValid())
            {
                this.customer = seekCustomer();
                MessageBox.Show("Customer was added successfully");
            }
            else
            {

                this.customer = null;
                MessageBox.Show("Customer id was not found or not valid");

            }

        }

        private bool cusomerIdIsValid()
        {
            return this.customerIdTextBox.Text.Length > 0 && this.customerIdTextBox.Text.Length <= 10 && allNumbers(this.customerIdTextBox.Text) && custometIdExist();
        }

        private bool custometIdExist()
        {
            if (Program.customers == null)
                return false;
            foreach (Customer c in Program.customers)
                if (c.getID() == this.customerIdTextBox.Text)
                    return true;
            return false;


        }

        private void setComplexityButton_Click(object sender, EventArgs e)
        {
            if (int.Parse(this.textBox_ProjUpd_CompLevel.Text) > 0 && int.Parse(this.textBox_ProjUpd_CompLevel.Text) <= 10)
            {
                this.complexityLevel = int.Parse(this.textBox_ProjUpd_CompLevel.Text);
                MessageBox.Show("complexity level  was changed successfully");


            }
            else
            {
                MessageBox.Show("Erro!! complexityLevel  un valid");
                this.textBox_ProjUpd_CompLevel.Text = "";
            }

        }

        private void setSimulationLocationButton_Click(object sender, EventArgs e)
        {
            if (simulationLocationIsValid())
            {
                this.simulationLocation = this.textBox_ProjUpd_SimuLoc.Text;
                MessageBox.Show("Simulation location  was changed successfully");
            }
            else
            {
                MessageBox.Show("Error !!Simulation location  un valid");
                this.textBox_ProjUpd_SimuLoc.Text = "";

            }
        }

        private void managerIdButton_Click(object sender, EventArgs e)
        {
            if (managerIdIsValid())
            {
                this.manager = seekEmployee(this.managerIdTextBox.Text);
                MessageBox.Show("Manager  was changed successfully");
            }

            else
            
                MessageBox.Show("Error!! Manager was not found");
            


        }
        

        private Employee seekEmployee(string id)
        {
            foreach (Employee e in Program.employees)
                if (e.getId() == id)
                    return e;

            return null;
        }

        private bool managerIdIsValid()
        {
            return managerIdTextBox != null && managerIdTextBox.Text.Length > 0 && managerIdTextBox.Text.Length <= 10 && idIsProjectManagerId();
        }

        private bool idIsProjectManagerId()
        {
            foreach (Employee e in Program.employees)
                if (e.getId() == this.managerIdTextBox.Text)
                    return e.getEmployeeType().ToString() == " Project_Manager";
            return false;

        }

        

        private void lastUpdateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (lastUpdateDateIsValid())
            {
                this.lastSimulationUpdate = lastUpdateDateTimePicker.Value;
               



            }
            else
            {
                lastUpdateDateTimePicker.Value= this.lastSimulationUpdate;
                MessageBox.Show("Error!! Last update date nvalid ");


            }
                    
                    
                    
                    
                    }

        private bool lastUpdateDateIsValid()
        {
            return lastUpdateDateTimePicker.Value < DateTime.Now;
        
           }

        private void comboBox_ProjUpd_Status_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.status = matchProjectStatusToString(this.comboBox_ProjUpd_Status.SelectedItem.ToString());
           
        }

        private ProjectStatusEnum matchProjectStatusToString(string status)
        {
             switch (status)
            {
                case "Data_Analysing":
                    return ProjectStatusEnum.Data_Analysing;


                case "Data_Collecting":
                    return ProjectStatusEnum.Data_Collecting;

                case "First_Simulation":
                    return ProjectStatusEnum.First_Simulation;

                case "In_Archive":
                    return ProjectStatusEnum.In_Archive;
                case "Main_Simulation":
                    return ProjectStatusEnum.Main_Simulation;
                case "Schedule_Planning":
                    return ProjectStatusEnum.Schedule_Planning;
                case "Summary_Report_Writing":
                    return ProjectStatusEnum.Summary_Report_Writing;
                case "Waiting_For_Customer_Approval":
                    return ProjectStatusEnum.Waiting_For_Customer_Approval;
                case "Waiting_For_Manager_Approval":
                    return ProjectStatusEnum.Waiting_For_Manager_Approval;

            }
            return ProjectStatusEnum.Waiting_For_Manager_Approval;
        }
    }


}

