﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CustomerUpdate : Form
    {
        private Customer customerToUpdateDetails;
        private string customerID;
        private string customerName;
        private CustomerStatus status;
        private string cMail;
        private string cName;
        private string cPhone;
        private DateTime lastContact;

        public CustomerUpdate(Customer c)
        {
            InitializeComponent();
            this.customerToUpdateDetails = c;
            

        }

        public void showForm()
        {
            this.initializeData();
            this.Show();

        }

        private void initializeData()
        {
            setCustomerID();
            setCustomerName();
            setCustomerStatus();
            setCustomerMail();
            setCustomerContactName();
            setCustomerPhone();
            setCustomerLastContactDate();
        }

        private void setCustomerLastContactDate()
        {
            this.lastContactDateTimePicker.Text = this.customerToUpdateDetails.get_lastContact() + "";
            this.lastContact = this.customerToUpdateDetails.get_lastContact();
        }

        private void setCustomerPhone()
        {
            this.phoneTextBox.Text = this.customerToUpdateDetails.get_cPhone();
            this.cPhone = this.customerToUpdateDetails.get_cPhone();
        }

        private void setCustomerContactName()
        {
            this.contactNameTextBox.Text = this.customerToUpdateDetails.get_cName();
            this.cName = this.customerToUpdateDetails.get_cName();
        }

        private void setCustomerMail()
        {
            this.emailTextBox.Text = this.customerToUpdateDetails.get_cMail();
            this.cMail= this.customerToUpdateDetails.get_cMail();

        }

        private void setCustomerStatus()
        {
            this.statusComboBox.Text = this.customerToUpdateDetails.get_status().ToString();
            this.status = this.customerToUpdateDetails.get_status();
            addAllValuesToStatusList();
        }

        private void addAllValuesToStatusList()
        {
            this.statusComboBox.Items.Add(CustomerStatus.During_Project);
            this.statusComboBox.Items.Add(CustomerStatus.Past_Customer);
            this.statusComboBox.Items.Add(CustomerStatus.Potential_Customer);


        }

        private void setCustomerName()
        {
            this.nameTextBox.Text = this.customerToUpdateDetails.get_name();
            this.customerName = this.customerToUpdateDetails.get_name();

        }

        private void setCustomerID()
        {
            this.customerIdTextBox.Text = this.customerToUpdateDetails.getID();
            this.customerID = this.customerToUpdateDetails.getID();

        }

        private void nameSetButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(this.nameTextBox.Text))
            {
                this.customerName = this.nameTextBox.Text;
                MessageBox.Show("Name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                setCustomerName();

            }

        }
        private bool allNumbers(string toCheck)
        {
            for (int i = 0; i < toCheck.Length; i++)

                if (toCheck[i] < '0' || toCheck[i] > '9')
                    return false;

            return true;
        }
        private bool nameIsValid(string name)
        {

            return allLetters(name) && name.Length > 0 && name.Length < 20;
        }
        private bool allLetters(string name)
        {
            for (int i = 0; i < name.Length; i++)

                if ((name[i] < 'a' || name[i] > 'z') && name[i] != ' ')
                    if ((name[i] < 'A' || name[i] > 'Z'))
                        return false;

            return true;
        }

        private void customerIdSetButton_Click(object sender, EventArgs e)
        {
            if (IdIsValid())
            {
                this.customerID = this.customerIdTextBox.Text;

                MessageBox.Show("Id was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! ID unvalid ");
                setCustomerID();

            }


        }
        private bool idExist(String idToCheck)
        {
            if (Program.customers == null)
                return false;
            foreach (Customer c in Program.customers)
                if (idToCheck == c.getID())
                    return true;

            return false;
        }
        private bool IdIsValid()
        {
            return customerIdTextBox.Text.Length > 0 && customerIdTextBox.Text.Length <= 10 && allNumbers(customerIdTextBox.Text) && !idExist(customerIdTextBox.Text);

        }
        private void contactNameSetButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(this.contactNameTextBox.Text))
            {
                this.cName = this.contactNameTextBox.Text;
                MessageBox.Show("Name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                setCustomerContactName();

            }
        }
        private void emailSetButton_Click(object sender, EventArgs e)
        {
            if (emailIsValid(this.emailTextBox.Text))
            {
                this.cMail = this.emailTextBox.Text;
                MessageBox.Show("email was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! Email adress is not valid ");
                setCustomerMail();

            }
        }
        private bool emailIsValid(string email)
        {
            Regex rx = new Regex(
        @"^[-!#$%&'*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+/0-9=?A-Z^_a-z{|}~])*@[a-zA-Z](-?[a-zA-Z0-9])*(\.[a-zA-Z](-?[a-zA-Z0-9])*)+$");
            return rx.IsMatch(email) && email.Length <= 50;
        }
        private void phoneNumberSetButton_Click(object sender, EventArgs e)
        {

            if (phoneNumberIsValid())
            {
                this.cPhone = phoneTextBox.Text;
                MessageBox.Show("phone number was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! The phone number must contain only numbers and must contain 10 digits ");
                setCustomerPhone();
            }


        }
        private bool phoneNumberIsValid()
        {
            return allNumbers(phoneTextBox.Text) && phoneTextBox.Text.Length == 10;
        }

        private void statusComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.status = matchStatus(statusComboBox.Text);  
        }

        private CustomerStatus matchStatus(string text)
        {
            switch (text)
            {
                case "During_Project":
                    return CustomerStatus.During_Project;
                case "Past_Customer":
                    return CustomerStatus.Past_Customer;
                case "Potential_Customer":
                    return CustomerStatus.Potential_Customer;

                  
            }
            return CustomerStatus.During_Project;

        }

        private void lastContactDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (dateIsValid())
            {
                this.lastContact = lastContactDateTimePicker.Value;
               

            }
            else
            {


                MessageBox.Show("Error!! Date un valid");
                setCustomerLastContactDate();
            }


        }

        private bool dateIsValid()
        {
            return lastContactDateTimePicker.Value <= DateTime.Now;
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
               this.customerToUpdateDetails.update(this.customerID, this.customerName, this.status, this.cMail, this.cName, this.cPhone, this.lastContact);
                MessageBox.Show("Customer updated successfully");
           
        }

        



    }



}

