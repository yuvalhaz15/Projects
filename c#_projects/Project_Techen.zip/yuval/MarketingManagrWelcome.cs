﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MarketingManagrWelcome : Form
    {
        public MarketingManagrWelcome()
        {
            InitializeComponent();
        }

        private void Label_MarketMangWel_Hello_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_CustMange_Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        private void btn_MarketMang_CustomerMang_Click(object sender, EventArgs e)
        {
            CustomersMangementForm customersMangementForm = new CustomersMangementForm();
          
            customersMangementForm.ShowDialog();
           

        }

        private void btn_MarketMang_ReadEmp_Click(object sender, EventArgs e)
        {
            readEmployee reForm = new readEmployee();
            reForm.Show();
        }

        private void btn_MarketMang_EditCalendar_Click(object sender, EventArgs e)
        {
            PlanMeetings pmForm = new PlanMeetings();
            pmForm.Show();
        }
    }
}
