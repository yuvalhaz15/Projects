﻿namespace WindowsFormsApp1
{
    partial class CustomerManageExistingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_ChooseCust_CustMang = new System.Windows.Forms.Label();
            this.Label_ChooseCust_ExistingCust = new System.Windows.Forms.Label();
            this.Label_ChooseCust = new System.Windows.Forms.Label();
            this.Combob_ChooseCust = new System.Windows.Forms.ComboBox();
            this.btn_CustMange_Back = new System.Windows.Forms.Button();
            this.viewButton = new System.Windows.Forms.Button();
            this.updateProjectButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_ChooseCust_CustMang
            // 
            this.Label_ChooseCust_CustMang.AutoSize = true;
            this.Label_ChooseCust_CustMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ChooseCust_CustMang.Location = new System.Drawing.Point(216, 72);
            this.Label_ChooseCust_CustMang.Name = "Label_ChooseCust_CustMang";
            this.Label_ChooseCust_CustMang.Size = new System.Drawing.Size(350, 37);
            this.Label_ChooseCust_CustMang.TabIndex = 0;
            this.Label_ChooseCust_CustMang.Text = "Customer Management";
            this.Label_ChooseCust_CustMang.Click += new System.EventHandler(this.label1_Click);
            // 
            // Label_ChooseCust_ExistingCust
            // 
            this.Label_ChooseCust_ExistingCust.AutoSize = true;
            this.Label_ChooseCust_ExistingCust.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ChooseCust_ExistingCust.Location = new System.Drawing.Point(297, 133);
            this.Label_ChooseCust_ExistingCust.Name = "Label_ChooseCust_ExistingCust";
            this.Label_ChooseCust_ExistingCust.Size = new System.Drawing.Size(182, 27);
            this.Label_ChooseCust_ExistingCust.TabIndex = 1;
            this.Label_ChooseCust_ExistingCust.Text = "Existing Customer";
            // 
            // Label_ChooseCust
            // 
            this.Label_ChooseCust.AutoSize = true;
            this.Label_ChooseCust.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ChooseCust.Location = new System.Drawing.Point(181, 242);
            this.Label_ChooseCust.Name = "Label_ChooseCust";
            this.Label_ChooseCust.Size = new System.Drawing.Size(125, 20);
            this.Label_ChooseCust.TabIndex = 3;
            this.Label_ChooseCust.Text = "Choose customer";
            // 
            // Combob_ChooseCust
            // 
            this.Combob_ChooseCust.FormattingEnabled = true;
            this.Combob_ChooseCust.Location = new System.Drawing.Point(323, 238);
            this.Combob_ChooseCust.Name = "Combob_ChooseCust";
            this.Combob_ChooseCust.Size = new System.Drawing.Size(121, 24);
            this.Combob_ChooseCust.TabIndex = 4;
            this.Combob_ChooseCust.SelectedIndexChanged += new System.EventHandler(this.Combob_ChooseCust_SelectedIndexChanged);
            // 
            // btn_CustMange_Back
            // 
            this.btn_CustMange_Back.Location = new System.Drawing.Point(689, 406);
            this.btn_CustMange_Back.Name = "btn_CustMange_Back";
            this.btn_CustMange_Back.Size = new System.Drawing.Size(83, 32);
            this.btn_CustMange_Back.TabIndex = 7;
            this.btn_CustMange_Back.Text = "Back";
            this.btn_CustMange_Back.UseVisualStyleBackColor = true;
            this.btn_CustMange_Back.Click += new System.EventHandler(this.btn_CustMange_Back_Click);
            // 
            // viewButton
            // 
            this.viewButton.Location = new System.Drawing.Point(139, 356);
            this.viewButton.Name = "viewButton";
            this.viewButton.Size = new System.Drawing.Size(96, 53);
            this.viewButton.TabIndex = 12;
            this.viewButton.Text = "VIEW";
            this.viewButton.UseVisualStyleBackColor = true;
            this.viewButton.Click += new System.EventHandler(this.viewButton_Click);
            // 
            // updateProjectButton
            // 
            this.updateProjectButton.Location = new System.Drawing.Point(468, 356);
            this.updateProjectButton.Name = "updateProjectButton";
            this.updateProjectButton.Size = new System.Drawing.Size(107, 53);
            this.updateProjectButton.TabIndex = 13;
            this.updateProjectButton.Text = "UPDATE";
            this.updateProjectButton.UseVisualStyleBackColor = true;
            this.updateProjectButton.Click += new System.EventHandler(this.updateProjectButton_Click);
            // 
            // CustomerManageExistingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.updateProjectButton);
            this.Controls.Add(this.viewButton);
            this.Controls.Add(this.btn_CustMange_Back);
            this.Controls.Add(this.Combob_ChooseCust);
            this.Controls.Add(this.Label_ChooseCust);
            this.Controls.Add(this.Label_ChooseCust_ExistingCust);
            this.Controls.Add(this.Label_ChooseCust_CustMang);
            this.Name = "CustomerManageExistingForm";
            this.Text = "CustomerManageExistingForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_ChooseCust_CustMang;
        private System.Windows.Forms.Label Label_ChooseCust_ExistingCust;
        private System.Windows.Forms.Label Label_ChooseCust;
        private System.Windows.Forms.ComboBox Combob_ChooseCust;
        private System.Windows.Forms.Button btn_CustMange_Back;
        private System.Windows.Forms.Button viewButton;
        private System.Windows.Forms.Button updateProjectButton;
    }
}