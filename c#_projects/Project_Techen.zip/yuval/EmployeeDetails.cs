﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class EmployeeDetails : Form
    {

        private Employee employeeToShowDetails;
        public EmployeeDetails(Employee employee)
        {
            InitializeComponent();
            this.employeeToShowDetails = employee;




        }
        public void showForm()
        {
            this.initializeData();
            this.Show();

        }
        private void initializeData()
        {
            setIDTextBox();
            setEmployeeTypeTextBox();
            setFirstNameTextBox();
            setLastNameTextBox();
            setSalaryTextBox();
            setHireDate();
            setPhonenNumberTextBox();
            setAdressTextBox();
            setBankAccountNumTextBox();
            setBankAccountBranchTextBox();
            setBankNameTextBox();
            setEmailTextBox();
            setGenderTextBox();
            setEmployeeStatusTextBox();
            setForm101TextBox();
            setRankTextBox();








        }

        private void setBankAccountBranchTextBox()
        {
            this.bankAccountBranchTextBox.Text = this.employeeToShowDetails.getBankAccountBranch();
        }

        private void setBankAccountNumTextBox()
        {
            this.bankAccountNumTextBox.Text = this.employeeToShowDetails.getBankAccountNum();
        }

        private void setForm101TextBox()
        {
            this.employeeForm101TextBox.Text = this.employeeToShowDetails.getform101();
        }

        private void setEmployeeStatusTextBox()
        {
            this.employeeStatusTextBox.Text = this.employeeToShowDetails.getEmployeeStatus().ToString();
        }

        private void setGenderTextBox()
        {
            this.employeeGenderTextBox.Text = this.employeeToShowDetails.getGender().ToString();
        }

        private void setEmailTextBox()
        {
           this.employeeEmailTextBox.Text=this.employeeToShowDetails.getEmail();
        }

       private void setBankNameTextBox()
        {
            this.employeeBankNameTextBox.Text = this.employeeToShowDetails.getBankName();
        }

        private void setAdressTextBox()
        {
            this.employeeAdressTextBox.Text = this.employeeToShowDetails.getAdress();
        }

        private void setPhonenNumberTextBox()
        {
            this.EmployeePhoneNumberTextBox.Text = this.employeeToShowDetails.getPhoneNumber();
        }

        private void setHireDate()
        {
            this.employeeHireDateTextBox.Text = this.employeeToShowDetails.getHireDate() + "";
        }

        private void setSalaryTextBox()
        {
            this.employeeSalaryTextBox.Text = this.employeeToShowDetails.getSalary()+"";
        }

        private void setLastNameTextBox()
        {
            this.EmployeeLasNameBox.Text = this.employeeToShowDetails.getLastName();
        }

        private void setRankTextBox()
        {
            this.employeeRankTextBox.Text = this.employeeToShowDetails.getRank()+"";
        }

        private void setFirstNameTextBox()
        {
            this.employeeFirstNameTextBox1.Text = this.employeeToShowDetails.getFirstName();
        }

        private void setEmployeeTypeTextBox()
        {
            this.employeeTypeTextBox.Text = this.employeeToShowDetails.getEmployeeType().ToString();
        }

        private void setIDTextBox()
        {
            this.EmployeeIDTextBox.Text = this.employeeToShowDetails.getId();
        }

        
    }
}
