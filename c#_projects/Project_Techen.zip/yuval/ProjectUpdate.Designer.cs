﻿namespace WindowsFormsApp1
{
    partial class ProjectUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label_CustUpd_Status;
            this.comboBox_ProjUpd_Status = new System.Windows.Forms.ComboBox();
            this.textBox_ProjUpd_Cost = new System.Windows.Forms.TextBox();
            this.textBox_ProjUpd_CompLevel = new System.Windows.Forms.TextBox();
            this.textBox_ProjUpd_Name = new System.Windows.Forms.TextBox();
            this.textBox_ProjUpd_ProjectID = new System.Windows.Forms.TextBox();
            this.label_ProjUpd_Cost = new System.Windows.Forms.Label();
            this.label_ProjUpd_ComplexLev = new System.Windows.Forms.Label();
            this.label_ProjUpd_ProjectID = new System.Windows.Forms.Label();
            this.label_ProjUpd_EndTime = new System.Windows.Forms.Label();
            this.label_ProjUpd_Name = new System.Windows.Forms.Label();
            this.label_ProjUpd_ProjUpdate = new System.Windows.Forms.Label();
            this.label_ProjUpd_ProjMang = new System.Windows.Forms.Label();
            this.btn_ProjUpd_Exit = new System.Windows.Forms.Button();
            this.btn_ProjUpd_Go = new System.Windows.Forms.Button();
            this.label_ProjUpd_SummRepLoc = new System.Windows.Forms.Label();
            this.label_ProjUpd_SimuLoc = new System.Windows.Forms.Label();
            this.textBox_ProjUpd_SimuLoc = new System.Windows.Forms.TextBox();
            this.textBox_ProjUpd_SummRepLoc = new System.Windows.Forms.TextBox();
            this.dateTimePicker_ProjUpd_EndTime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.managerIdTextBox = new System.Windows.Forms.TextBox();
            this.nameSetButton = new System.Windows.Forms.Button();
            this.complexityLevelSetButton = new System.Windows.Forms.Button();
            this.costSetButton = new System.Windows.Forms.Button();
            this.simulationLocationSetButoon = new System.Windows.Forms.Button();
            this.SummarySetButton = new System.Windows.Forms.Button();
            this.managerIDSetButton = new System.Windows.Forms.Button();
            this.customerIdLabel = new System.Windows.Forms.Label();
            this.customerIdTextBox = new System.Windows.Forms.TextBox();
            this.customerSetButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lastUpdateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            label_CustUpd_Status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_CustUpd_Status
            // 
            label_CustUpd_Status.AutoSize = true;
            label_CustUpd_Status.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label_CustUpd_Status.Location = new System.Drawing.Point(196, 378);
            label_CustUpd_Status.Name = "label_CustUpd_Status";
            label_CustUpd_Status.Size = new System.Drawing.Size(53, 20);
            label_CustUpd_Status.TabIndex = 21;
            label_CustUpd_Status.Text = "Status:";
            // 
            // comboBox_ProjUpd_Status
            // 
            this.comboBox_ProjUpd_Status.FormattingEnabled = true;
            this.comboBox_ProjUpd_Status.Location = new System.Drawing.Point(322, 378);
            this.comboBox_ProjUpd_Status.Name = "comboBox_ProjUpd_Status";
            this.comboBox_ProjUpd_Status.Size = new System.Drawing.Size(200, 24);
            this.comboBox_ProjUpd_Status.TabIndex = 28;
            this.comboBox_ProjUpd_Status.SelectedIndexChanged += new System.EventHandler(this.comboBox_ProjUpd_Status_SelectedIndexChanged);
            // 
            // textBox_ProjUpd_Cost
            // 
            this.textBox_ProjUpd_Cost.Location = new System.Drawing.Point(322, 336);
            this.textBox_ProjUpd_Cost.Name = "textBox_ProjUpd_Cost";
            this.textBox_ProjUpd_Cost.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjUpd_Cost.TabIndex = 27;
            // 
            // textBox_ProjUpd_CompLevel
            // 
            this.textBox_ProjUpd_CompLevel.Location = new System.Drawing.Point(322, 291);
            this.textBox_ProjUpd_CompLevel.Name = "textBox_ProjUpd_CompLevel";
            this.textBox_ProjUpd_CompLevel.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjUpd_CompLevel.TabIndex = 26;
            // 
            // textBox_ProjUpd_Name
            // 
            this.textBox_ProjUpd_Name.Location = new System.Drawing.Point(322, 197);
            this.textBox_ProjUpd_Name.Name = "textBox_ProjUpd_Name";
            this.textBox_ProjUpd_Name.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjUpd_Name.TabIndex = 24;
            // 
            // textBox_ProjUpd_ProjectID
            // 
            this.textBox_ProjUpd_ProjectID.Location = new System.Drawing.Point(322, 152);
            this.textBox_ProjUpd_ProjectID.Name = "textBox_ProjUpd_ProjectID";
            this.textBox_ProjUpd_ProjectID.ReadOnly = true;
            this.textBox_ProjUpd_ProjectID.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjUpd_ProjectID.TabIndex = 23;
            // 
            // label_ProjUpd_Cost
            // 
            this.label_ProjUpd_Cost.AutoSize = true;
            this.label_ProjUpd_Cost.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_Cost.Location = new System.Drawing.Point(197, 336);
            this.label_ProjUpd_Cost.Name = "label_ProjUpd_Cost";
            this.label_ProjUpd_Cost.Size = new System.Drawing.Size(41, 20);
            this.label_ProjUpd_Cost.TabIndex = 22;
            this.label_ProjUpd_Cost.Text = "Cost:";
            // 
            // label_ProjUpd_ComplexLev
            // 
            this.label_ProjUpd_ComplexLev.AutoSize = true;
            this.label_ProjUpd_ComplexLev.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_ComplexLev.Location = new System.Drawing.Point(162, 291);
            this.label_ProjUpd_ComplexLev.Name = "label_ProjUpd_ComplexLev";
            this.label_ProjUpd_ComplexLev.Size = new System.Drawing.Size(122, 20);
            this.label_ProjUpd_ComplexLev.TabIndex = 20;
            this.label_ProjUpd_ComplexLev.Text = "Complexity level:";
            // 
            // label_ProjUpd_ProjectID
            // 
            this.label_ProjUpd_ProjectID.AutoSize = true;
            this.label_ProjUpd_ProjectID.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_ProjectID.Location = new System.Drawing.Point(185, 154);
            this.label_ProjUpd_ProjectID.Name = "label_ProjUpd_ProjectID";
            this.label_ProjUpd_ProjectID.Size = new System.Drawing.Size(78, 20);
            this.label_ProjUpd_ProjectID.TabIndex = 19;
            this.label_ProjUpd_ProjectID.Text = "Project ID:";
            // 
            // label_ProjUpd_EndTime
            // 
            this.label_ProjUpd_EndTime.AutoSize = true;
            this.label_ProjUpd_EndTime.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_EndTime.Location = new System.Drawing.Point(188, 250);
            this.label_ProjUpd_EndTime.Name = "label_ProjUpd_EndTime";
            this.label_ProjUpd_EndTime.Size = new System.Drawing.Size(75, 20);
            this.label_ProjUpd_EndTime.TabIndex = 18;
            this.label_ProjUpd_EndTime.Text = "End Time:";
            // 
            // label_ProjUpd_Name
            // 
            this.label_ProjUpd_Name.AutoSize = true;
            this.label_ProjUpd_Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_Name.Location = new System.Drawing.Point(197, 199);
            this.label_ProjUpd_Name.Name = "label_ProjUpd_Name";
            this.label_ProjUpd_Name.Size = new System.Drawing.Size(52, 20);
            this.label_ProjUpd_Name.TabIndex = 17;
            this.label_ProjUpd_Name.Text = "Name:";
            // 
            // label_ProjUpd_ProjUpdate
            // 
            this.label_ProjUpd_ProjUpdate.AutoSize = true;
            this.label_ProjUpd_ProjUpdate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_ProjUpdate.Location = new System.Drawing.Point(346, 98);
            this.label_ProjUpd_ProjUpdate.Name = "label_ProjUpd_ProjUpdate";
            this.label_ProjUpd_ProjUpdate.Size = new System.Drawing.Size(154, 27);
            this.label_ProjUpd_ProjUpdate.TabIndex = 16;
            this.label_ProjUpd_ProjUpdate.Text = "Project Update";
            // 
            // label_ProjUpd_ProjMang
            // 
            this.label_ProjUpd_ProjMang.AutoSize = true;
            this.label_ProjUpd_ProjMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_ProjMang.Location = new System.Drawing.Point(274, 45);
            this.label_ProjUpd_ProjMang.Name = "label_ProjUpd_ProjMang";
            this.label_ProjUpd_ProjMang.Size = new System.Drawing.Size(311, 37);
            this.label_ProjUpd_ProjMang.TabIndex = 15;
            this.label_ProjUpd_ProjMang.Text = "Project Management";
            // 
            // btn_ProjUpd_Exit
            // 
            this.btn_ProjUpd_Exit.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjUpd_Exit.Location = new System.Drawing.Point(709, 601);
            this.btn_ProjUpd_Exit.Name = "btn_ProjUpd_Exit";
            this.btn_ProjUpd_Exit.Size = new System.Drawing.Size(95, 34);
            this.btn_ProjUpd_Exit.TabIndex = 30;
            this.btn_ProjUpd_Exit.Text = "Exit";
            this.btn_ProjUpd_Exit.UseVisualStyleBackColor = true;
            // 
            // btn_ProjUpd_Go
            // 
            this.btn_ProjUpd_Go.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjUpd_Go.Location = new System.Drawing.Point(12, 604);
            this.btn_ProjUpd_Go.Name = "btn_ProjUpd_Go";
            this.btn_ProjUpd_Go.Size = new System.Drawing.Size(120, 43);
            this.btn_ProjUpd_Go.TabIndex = 29;
            this.btn_ProjUpd_Go.Text = "Update";
            this.btn_ProjUpd_Go.UseVisualStyleBackColor = true;
            this.btn_ProjUpd_Go.Click += new System.EventHandler(this.btn_ProjUpd_Update_Click);
            // 
            // label_ProjUpd_SummRepLoc
            // 
            this.label_ProjUpd_SummRepLoc.AutoSize = true;
            this.label_ProjUpd_SummRepLoc.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_SummRepLoc.Location = new System.Drawing.Point(184, 469);
            this.label_ProjUpd_SummRepLoc.Name = "label_ProjUpd_SummRepLoc";
            this.label_ProjUpd_SummRepLoc.Size = new System.Drawing.Size(79, 20);
            this.label_ProjUpd_SummRepLoc.TabIndex = 22;
            this.label_ProjUpd_SummRepLoc.Text = "Summary :";
            // 
            // label_ProjUpd_SimuLoc
            // 
            this.label_ProjUpd_SimuLoc.AutoSize = true;
            this.label_ProjUpd_SimuLoc.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProjUpd_SimuLoc.Location = new System.Drawing.Point(147, 423);
            this.label_ProjUpd_SimuLoc.Name = "label_ProjUpd_SimuLoc";
            this.label_ProjUpd_SimuLoc.Size = new System.Drawing.Size(147, 20);
            this.label_ProjUpd_SimuLoc.TabIndex = 22;
            this.label_ProjUpd_SimuLoc.Text = "Simulation Location:";
            // 
            // textBox_ProjUpd_SimuLoc
            // 
            this.textBox_ProjUpd_SimuLoc.Location = new System.Drawing.Point(322, 423);
            this.textBox_ProjUpd_SimuLoc.Name = "textBox_ProjUpd_SimuLoc";
            this.textBox_ProjUpd_SimuLoc.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjUpd_SimuLoc.TabIndex = 27;
            // 
            // textBox_ProjUpd_SummRepLoc
            // 
            this.textBox_ProjUpd_SummRepLoc.Location = new System.Drawing.Point(322, 467);
            this.textBox_ProjUpd_SummRepLoc.Name = "textBox_ProjUpd_SummRepLoc";
            this.textBox_ProjUpd_SummRepLoc.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjUpd_SummRepLoc.TabIndex = 27;
            // 
            // dateTimePicker_ProjUpd_EndTime
            // 
            this.dateTimePicker_ProjUpd_EndTime.Location = new System.Drawing.Point(322, 247);
            this.dateTimePicker_ProjUpd_EndTime.Name = "dateTimePicker_ProjUpd_EndTime";
            this.dateTimePicker_ProjUpd_EndTime.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker_ProjUpd_EndTime.TabIndex = 31;
            this.dateTimePicker_ProjUpd_EndTime.ValueChanged += new System.EventHandler(this.dateTimePicker_ProjUpd_EndTime_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(184, 515);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Manager ID :";
            // 
            // managerIdTextBox
            // 
            this.managerIdTextBox.Location = new System.Drawing.Point(322, 515);
            this.managerIdTextBox.Name = "managerIdTextBox";
            this.managerIdTextBox.Size = new System.Drawing.Size(200, 22);
            this.managerIdTextBox.TabIndex = 33;
            // 
            // nameSetButton
            // 
            this.nameSetButton.Location = new System.Drawing.Point(528, 197);
            this.nameSetButton.Name = "nameSetButton";
            this.nameSetButton.Size = new System.Drawing.Size(37, 22);
            this.nameSetButton.TabIndex = 81;
            this.nameSetButton.Text = "set\r\n\r\n";
            this.nameSetButton.UseVisualStyleBackColor = true;
            this.nameSetButton.Click += new System.EventHandler(this.setProjectNameButton_Click);
            // 
            // complexityLevelSetButton
            // 
            this.complexityLevelSetButton.Location = new System.Drawing.Point(528, 289);
            this.complexityLevelSetButton.Name = "complexityLevelSetButton";
            this.complexityLevelSetButton.Size = new System.Drawing.Size(37, 22);
            this.complexityLevelSetButton.TabIndex = 82;
            this.complexityLevelSetButton.Text = "set\r\n\r\n";
            this.complexityLevelSetButton.UseVisualStyleBackColor = true;
            this.complexityLevelSetButton.Click += new System.EventHandler(this.setComplexityButton_Click);
            // 
            // costSetButton
            // 
            this.costSetButton.Location = new System.Drawing.Point(528, 334);
            this.costSetButton.Name = "costSetButton";
            this.costSetButton.Size = new System.Drawing.Size(37, 22);
            this.costSetButton.TabIndex = 83;
            this.costSetButton.Text = "set\r\n\r\n";
            this.costSetButton.UseVisualStyleBackColor = true;
            this.costSetButton.Click += new System.EventHandler(this.setCostButton_Click);
            // 
            // simulationLocationSetButoon
            // 
            this.simulationLocationSetButoon.Location = new System.Drawing.Point(528, 423);
            this.simulationLocationSetButoon.Name = "simulationLocationSetButoon";
            this.simulationLocationSetButoon.Size = new System.Drawing.Size(37, 22);
            this.simulationLocationSetButoon.TabIndex = 85;
            this.simulationLocationSetButoon.Text = "set\r\n\r\n";
            this.simulationLocationSetButoon.UseVisualStyleBackColor = true;
            this.simulationLocationSetButoon.Click += new System.EventHandler(this.setSimulationLocationButton_Click);
            // 
            // SummarySetButton
            // 
            this.SummarySetButton.Location = new System.Drawing.Point(528, 467);
            this.SummarySetButton.Name = "SummarySetButton";
            this.SummarySetButton.Size = new System.Drawing.Size(37, 22);
            this.SummarySetButton.TabIndex = 86;
            this.SummarySetButton.Text = "set\r\n\r\n";
            this.SummarySetButton.UseVisualStyleBackColor = true;
            this.SummarySetButton.Click += new System.EventHandler(this.summaryProjectSetButton_Click);
            // 
            // managerIDSetButton
            // 
            this.managerIDSetButton.Location = new System.Drawing.Point(528, 515);
            this.managerIDSetButton.Name = "managerIDSetButton";
            this.managerIDSetButton.Size = new System.Drawing.Size(37, 22);
            this.managerIDSetButton.TabIndex = 87;
            this.managerIDSetButton.Text = "set\r\n\r\n";
            this.managerIDSetButton.UseVisualStyleBackColor = true;
            this.managerIDSetButton.Click += new System.EventHandler(this.managerIdButton_Click);
            // 
            // customerIdLabel
            // 
            this.customerIdLabel.AutoSize = true;
            this.customerIdLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerIdLabel.Location = new System.Drawing.Point(185, 557);
            this.customerIdLabel.Name = "customerIdLabel";
            this.customerIdLabel.Size = new System.Drawing.Size(99, 20);
            this.customerIdLabel.TabIndex = 88;
            this.customerIdLabel.Text = "Customer ID :";
            // 
            // customerIdTextBox
            // 
            this.customerIdTextBox.Location = new System.Drawing.Point(322, 555);
            this.customerIdTextBox.Name = "customerIdTextBox";
            this.customerIdTextBox.Size = new System.Drawing.Size(200, 22);
            this.customerIdTextBox.TabIndex = 89;
            // 
            // customerSetButton
            // 
            this.customerSetButton.Location = new System.Drawing.Point(528, 555);
            this.customerSetButton.Name = "customerSetButton";
            this.customerSetButton.Size = new System.Drawing.Size(37, 22);
            this.customerSetButton.TabIndex = 90;
            this.customerSetButton.Text = "set\r\n\r\n";
            this.customerSetButton.UseVisualStyleBackColor = true;
            this.customerSetButton.Click += new System.EventHandler(this.setCustomerIdButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(181, 592);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 20);
            this.label2.TabIndex = 91;
            this.label2.Text = "Last update :";
            // 
            // lastUpdateDateTimePicker
            // 
            this.lastUpdateDateTimePicker.Location = new System.Drawing.Point(322, 592);
            this.lastUpdateDateTimePicker.Name = "lastUpdateDateTimePicker";
            this.lastUpdateDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.lastUpdateDateTimePicker.TabIndex = 94;
            this.lastUpdateDateTimePicker.ValueChanged += new System.EventHandler(this.lastUpdateDateTimePicker_ValueChanged);
            // 
            // ProjectUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 659);
            this.Controls.Add(this.lastUpdateDateTimePicker);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.customerSetButton);
            this.Controls.Add(this.customerIdTextBox);
            this.Controls.Add(this.customerIdLabel);
            this.Controls.Add(this.managerIDSetButton);
            this.Controls.Add(this.SummarySetButton);
            this.Controls.Add(this.simulationLocationSetButoon);
            this.Controls.Add(this.costSetButton);
            this.Controls.Add(this.complexityLevelSetButton);
            this.Controls.Add(this.nameSetButton);
            this.Controls.Add(this.managerIdTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker_ProjUpd_EndTime);
            this.Controls.Add(this.btn_ProjUpd_Exit);
            this.Controls.Add(this.btn_ProjUpd_Go);
            this.Controls.Add(this.comboBox_ProjUpd_Status);
            this.Controls.Add(this.textBox_ProjUpd_SummRepLoc);
            this.Controls.Add(this.textBox_ProjUpd_SimuLoc);
            this.Controls.Add(this.textBox_ProjUpd_Cost);
            this.Controls.Add(this.textBox_ProjUpd_CompLevel);
            this.Controls.Add(this.textBox_ProjUpd_Name);
            this.Controls.Add(this.textBox_ProjUpd_ProjectID);
            this.Controls.Add(label_CustUpd_Status);
            this.Controls.Add(this.label_ProjUpd_SummRepLoc);
            this.Controls.Add(this.label_ProjUpd_SimuLoc);
            this.Controls.Add(this.label_ProjUpd_Cost);
            this.Controls.Add(this.label_ProjUpd_ComplexLev);
            this.Controls.Add(this.label_ProjUpd_ProjectID);
            this.Controls.Add(this.label_ProjUpd_EndTime);
            this.Controls.Add(this.label_ProjUpd_Name);
            this.Controls.Add(this.label_ProjUpd_ProjUpdate);
            this.Controls.Add(this.label_ProjUpd_ProjMang);
            this.Name = "ProjectUpdate";
            this.Text = "ProjectUpdate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_ProjUpd_Status;
        private System.Windows.Forms.TextBox textBox_ProjUpd_Cost;
        private System.Windows.Forms.TextBox textBox_ProjUpd_CompLevel;
        private System.Windows.Forms.TextBox textBox_ProjUpd_Name;
        private System.Windows.Forms.TextBox textBox_ProjUpd_ProjectID;
        private System.Windows.Forms.Label label_ProjUpd_Cost;
        private System.Windows.Forms.Label label_ProjUpd_ComplexLev;
        private System.Windows.Forms.Label label_ProjUpd_ProjectID;
        private System.Windows.Forms.Label label_ProjUpd_EndTime;
        private System.Windows.Forms.Label label_ProjUpd_Name;
        private System.Windows.Forms.Label label_ProjUpd_ProjUpdate;
        private System.Windows.Forms.Label label_ProjUpd_ProjMang;
        private System.Windows.Forms.Button btn_ProjUpd_Exit;
        private System.Windows.Forms.Button btn_ProjUpd_Go;
        private System.Windows.Forms.Label label_ProjUpd_SummRepLoc;
        private System.Windows.Forms.Label label_ProjUpd_SimuLoc;
        private System.Windows.Forms.TextBox textBox_ProjUpd_SimuLoc;
        private System.Windows.Forms.TextBox textBox_ProjUpd_SummRepLoc;
        private System.Windows.Forms.DateTimePicker dateTimePicker_ProjUpd_EndTime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox managerIdTextBox;
        private System.Windows.Forms.Button nameSetButton;
        private System.Windows.Forms.Button complexityLevelSetButton;
        private System.Windows.Forms.Button costSetButton;
        private System.Windows.Forms.Button simulationLocationSetButoon;
        private System.Windows.Forms.Button SummarySetButton;
        private System.Windows.Forms.Button managerIDSetButton;
        private System.Windows.Forms.Label customerIdLabel;
        private System.Windows.Forms.TextBox customerIdTextBox;
        private System.Windows.Forms.Button customerSetButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker lastUpdateDateTimePicker;
    }
}