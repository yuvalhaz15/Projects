﻿namespace WindowsFormsApp1
{
    public enum CustomerStatus
    {
        During_Project,
        Past_Customer,
        Potential_Customer
    }
}