﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CEOForm : Form
    {
        public CEOForm()
        {
            InitializeComponent();
        }

        private void EmployeesButton_Click(object sender, EventArgs e)
        {
            EmployeesEnterMangement employeesForm = new EmployeesEnterMangement();
            employeesForm.Show();
        }

        private void btn_CEO_CustomerMang_Click(object sender, EventArgs e)
        {
            CustomersMangementForm customersMangementForm = new CustomersMangementForm();
            this.Hide();
            customersMangementForm.ShowDialog();
            this.Close();
        }

        private void btn_CEO_ProjMang_Click(object sender, EventArgs e)
        {

            ProjectManagementForm projectManagementForm = new ProjectManagementForm();
            this.Hide();
            projectManagementForm.ShowDialog();
            this.Close();
        }
    }
}
