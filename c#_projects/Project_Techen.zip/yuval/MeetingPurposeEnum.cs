﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1

{
    public enum MeetingPurposeEnum
    {
        matching_Expectations,
        first_Meeting_With_A_Client,
        simulation_Presentation,
        summary_Meeting,
        price_Quote,
        other

    }
}