﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CustomerManageExistingForm : Form
    {
       private  Customer customerToMakeActionON;
        private string customerId;
        public CustomerManageExistingForm()
        {
            InitializeComponent();
            addValuesToCustomersList();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void addValuesToCustomersList()
        {
            foreach (Customer c in Program.customers)
                Combob_ChooseCust.Items.Add(c.getID());

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_CustMange_Back_Click(object sender, EventArgs e)
        {
            CustomersMangementForm customersMangementForm = new CustomersMangementForm();
            this.Hide();
            customersMangementForm.ShowDialog();
            this.Close();

        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            if (this.customerToMakeActionON != null)
                customerToMakeActionON.readCustomer();
            else
                MessageBox.Show("please choose customer");
        }

        private void updateProjectButton_Click(object sender, EventArgs e)
        {
            if (this.customerToMakeActionON != null)
                this.customerToMakeActionON.updateCustomer();
            else
                MessageBox.Show("please choose customer");
        }

        private void Combob_ChooseCust_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.customerId = this.Combob_ChooseCust.Text;
            this.customerToMakeActionON = matchCustomerToId();
        }

        private Customer matchCustomerToId()
        {
            foreach (Customer c in Program.customers)
                if (this.customerId== c.getID())
                    return c;
            return null;
        }
    }
}
