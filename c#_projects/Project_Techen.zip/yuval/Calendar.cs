﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Calendar
    {
        private DateTime date;
        private System.Collections.Generic.List<Meeting> Meetings;
        private System.Collections.Generic.List<Assignment> Assignments;

        public Calendar(DateTime date, bool isNew)
        {

            this.date = date;
            Meetings = new List<Meeting>();
            Assignments = new List<Assignment>();
            if (isNew)
            {

                createCalendar();
                Program.calendars.Add(this);
            }
        }

        public bool availableTimeForMeeting(DateTime meetingTime, List<Employee> employees)
        {
            foreach (Meeting m in Meetings)
            {
                if (m.getTimeOfmeeting().Equals(meetingTime) && checkEmployees(employees, m))
                    return false;    
               
            }
            return true;
        }

        public bool checkEmployees(List<Employee> employees , Meeting m)
        {
            foreach (Employee e1 in employees)
            {
                foreach (Employee e2 in m.GetEmployees())
                {
                    if (e1.getId() == e2.getId())
                        return true;
                }
            }
            return false;

        }

        public void createCalendar()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_calendar @date";
            c.Parameters.AddWithValue("@date", this.date);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public DateTime getDate()
        {
            return this.date;
        }
        public void setDate(DateTime date)
        {
            this.date = date;
        }

        public List<Meeting> getMeetings()
        {
            return Meetings;
        }


        public List<Assignment> getAssignments()
        {
            return Assignments;
        }


    }
}
