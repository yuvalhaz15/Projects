﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace WindowsFormsApp1
{
    public class Project
    {
        private Customer customer;
        private string projectID;
        private string projectName;
        private Employee manager;
        private int complexityLevel;
        private DateTime startTime;
        private DateTime endTime;
        private double cost;
        private DateTime lastSimulationUpdateDT;
        private ProjectStatusEnum status;
        private string simulationLocation;
        private string summaryReport;

        public Project(Customer customer, string projectID, string projectName, Employee manager, ProjectStatusEnum status, DateTime startTime, DateTime endTime, int complexityLevel,
                      double cost, DateTime lastSimulationUpdateDT, string simulationLocation, string summaryReport, bool isNew)
        {

            this.customer = customer;
            this.projectID = projectID;
            this.projectName = projectName;
            this.manager = manager;
            this.complexityLevel = complexityLevel;
            this.startTime = startTime;
            this.endTime = endTime;
            this.cost = cost;
            this.lastSimulationUpdateDT = lastSimulationUpdateDT;
            this.status = status;
            this.simulationLocation = simulationLocation;
            this.summaryReport = summaryReport;
            this.customer.getProjects().Add(this);
            this.manager.getProjects().Add(this);

            if (isNew)
            {
                this.CreateProject();
                Program.ProjectsInProgress.Add(this);
            }
        }

        public string getSummaryReport()
        {

            return this.summaryReport;

        }
        public void setSummaryReport(string summary)
        {
            this.summaryReport = summary;
        }

        public void readProject()
        {

            ProjectDetails pdForm = new ProjectDetails(this);
            pdForm.showForm();

        }


        private bool projectIDNotexist()
        {
            if (Program.ProjectsInArchive == null && Program.ProjectsInProgress == null)
                return true;
            return idNotExistInArchiveProjects() && idNotExistInProgressProjects();
        }

        private bool idNotExistInArchiveProjects()
        {
            foreach (Project p in Program.ProjectsInArchive)
            {
                if (this.projectID == p.getProjectID())
                    return false;
            }
            return true;
        }

        private bool idNotExistInProgressProjects()
        {
            foreach (Project p in Program.ProjectsInProgress)
            {
                if (this.projectID == p.getProjectID())
                    return false;
            }
            return true;
        }

        public Customer getCustomer()
        {
            return this.customer;
        }
        public string getProjectID()
        {
            return this.projectID;
        }

        public void setProjectID(string projectID)
        {
            this.projectID = projectID;
        }



        private void CreateProject()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_projects @customerId, @projectId , @projectName ,@manager, @projectStatus , @startTime ,@endTime ,@complexityLevel ,@cost ,@lastSimulationUpdateDT ,@simulationLocation  ,@summaryReport";
            c.Parameters.AddWithValue("@customerId", this.customer.getID());
            c.Parameters.AddWithValue("@projectId", this.projectID);
            c.Parameters.AddWithValue("@projectName", this.projectName);
            c.Parameters.AddWithValue("@manager", this.manager.getId());
            c.Parameters.AddWithValue("@projectStatus", this.status.ToString());
            c.Parameters.AddWithValue("@startTime", this.startTime);
            c.Parameters.AddWithValue("@endTime", this.endTime);
            c.Parameters.AddWithValue("@complexityLevel", this.complexityLevel);
            c.Parameters.AddWithValue("@cost", this.cost);
            c.Parameters.AddWithValue("@lastSimulationUpdateDT", this.lastSimulationUpdateDT);
            c.Parameters.AddWithValue("@simulationLocation", this.simulationLocation);
            c.Parameters.AddWithValue("@summaryReport", this.summaryReport);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        private void update_Project()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Update_project @customerId , @projectId , @projectName , @manager ,@projectStatus , @startTime , @endTime , @complexityLevel , @cost , @lastSimulationUpdateDT , @simulationLocation , @summaryReport ";
            c.Parameters.AddWithValue("@customerId", this.customer.getID());
            c.Parameters.AddWithValue("@projectId", this.projectID);
            c.Parameters.AddWithValue("@projectName", this.projectName);
            c.Parameters.AddWithValue("@manager", this.manager.getId());
            c.Parameters.AddWithValue("@projectStatus", this.status.ToString());
            c.Parameters.AddWithValue("@startTime", this.startTime);
            c.Parameters.AddWithValue("@endTime", this.endTime);
            c.Parameters.AddWithValue("@complexityLevel", this.complexityLevel);
            c.Parameters.AddWithValue("@cost", this.cost);
            c.Parameters.AddWithValue("@lastSimulationUpdateDT", this.lastSimulationUpdateDT);
            c.Parameters.AddWithValue("@simulationLocation", this.simulationLocation);
            c.Parameters.AddWithValue("@summaryReport", this.summaryReport);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }


        private void changeStatus(ProjectStatusEnum newStatus)
        {
            setStatus(newStatus);
        }

        private void lastUpdate()
        {
            setLastSimulationUpdate(DateTime.Now.Date);
        }

        private void transferToArchive()
        {
            Program.ProjectsInArchive.Add(this);
            Program.ProjectsInProgress.Remove(this);
        }

        public string getProjectName()
        {

            return this.projectName;
        }

        public Employee getManager()
        {
            return this.manager;
        }
        public void setProjectName(string projectName)
        {
            this.projectName = projectName;
        }
        public int getComplexityLevel()
        {

            return complexityLevel;
        }
        public void setComplexityLevel(int complexityLevel)
        {
            this.complexityLevel = complexityLevel;
        }
        public DateTime getStartTime()
        {

            return startTime;

        }
        public void setStartTime(DateTime startTime)
        {
            this.startTime = startTime;
        }
        public DateTime getEndTime()
        {

            return endTime;
        }
        public void setEndTime(DateTime endTime)
        {
            this.endTime = endTime;
        }
        public DateTime getLastSimulationUpdateDT()
        {
            return lastSimulationUpdateDT;
        }
        public void setLastSimulationUpdate(DateTime lastSimulationUpdateDT)
        {
            this.lastSimulationUpdateDT = lastSimulationUpdateDT;
        }
        public double getCost()
        {

            return cost;
        }
        public void setCost(double cost)
        {
            this.cost = cost;
        }
        public ProjectStatusEnum getStatus()
        {

            return status;
        }
        public void setStatus(ProjectStatusEnum status)
        {
            this.status = status;
        }
        public String getSimulationLocation()
        {

            return simulationLocation;
        }
        public void setSimulationLocation(string simulationLocation)
        {
            this.simulationLocation = simulationLocation;
        }

        public void updateProject(Customer customer, string projectID, string projectName, Employee manager, ProjectStatusEnum status, DateTime startTime, DateTime endTime, int complexityLevel, double cost, DateTime now, string simulationLocation, string summaryReport, DateTime lastUpdate)
        {
            this.customer = customer;
            this.projectID = projectID;
            this.projectName = projectName;
            this.manager = manager;
            this.complexityLevel = complexityLevel;
            this.startTime = startTime;
            this.endTime = endTime;
            this.cost = cost;
            this.lastSimulationUpdateDT = lastUpdate;
            this.status = status;
            this.simulationLocation = simulationLocation;
            this.summaryReport = summaryReport;
            this.update_Project();

        }
        public static DateTime RecommendedProjectEndTime(int complexityLevel)
        {
            int numOfCurrentProjects = Program.ProjectsInProgress.Count;
            int numOfDevelopers = Employee.calculateNumOfDevelopers();
            Double averageRank = Employee.getTotalRank() / numOfDevelopers;
            Double averageComplexity = totalComplexity() / numOfCurrentProjects;
            DateTime d;
            if (numOfCurrentProjects > numOfDevelopers)
            {
                d = DateTime.Now.AddYears(1);
                return d;
            }
            if (2 * numOfCurrentProjects < numOfDevelopers)
            {
                d = DateTime.Now.AddMonths(3);
                return d;
            }

            if (averageRank - averageComplexity > 0)
            {
                d = DateTime.Now.AddMonths(6);
                return d;
            }
            d = DateTime.Now.AddMonths(9);
            return d;

        }

        private static int totalComplexity()
        {
            int total = 0;
            foreach (Employee e in Program.employees)
            {
                if (e.getEmployeeType().ToString() == "Simulation_Developer")
                {
                    total += e.calculateRank();
                }

            }
            return total;
        }








    }

}