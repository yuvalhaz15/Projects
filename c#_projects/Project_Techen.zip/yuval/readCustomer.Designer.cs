﻿namespace WindowsFormsApp1
{
    partial class readCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkDetailsButton = new System.Windows.Forms.Button();
            this.customerList = new System.Windows.Forms.ListBox();
            this.selectCustomerLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkDetailsButton
            // 
            this.checkDetailsButton.Location = new System.Drawing.Point(489, 302);
            this.checkDetailsButton.Name = "checkDetailsButton";
            this.checkDetailsButton.Size = new System.Drawing.Size(130, 96);
            this.checkDetailsButton.TabIndex = 8;
            this.checkDetailsButton.Text = "Check Details";
            this.checkDetailsButton.UseVisualStyleBackColor = true;
            this.checkDetailsButton.Click += new System.EventHandler(this.checkDetailsButton_Click);
            // 
            // customerList
            // 
            this.customerList.FormattingEnabled = true;
            this.customerList.ItemHeight = 16;
            this.customerList.Location = new System.Drawing.Point(609, 52);
            this.customerList.Name = "customerList";
            this.customerList.Size = new System.Drawing.Size(192, 148);
            this.customerList.TabIndex = 7;
            this.customerList.SelectedIndexChanged += new System.EventHandler(this.customersList_SelectedIndexChanged);
            // 
            // selectCustomerLabel
            // 
            this.selectCustomerLabel.AutoSize = true;
            this.selectCustomerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.selectCustomerLabel.Location = new System.Drawing.Point(-1, 60);
            this.selectCustomerLabel.Name = "selectCustomerLabel";
            this.selectCustomerLabel.Size = new System.Drawing.Size(333, 29);
            this.selectCustomerLabel.TabIndex = 6;
            this.selectCustomerLabel.Text = "Select customer from the list : ";
            // 
            // readCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.checkDetailsButton);
            this.Controls.Add(this.customerList);
            this.Controls.Add(this.selectCustomerLabel);
            this.Name = "readCustomer";
            this.Text = "readCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button checkDetailsButton;
        private System.Windows.Forms.ListBox customerList;
        private System.Windows.Forms.Label selectCustomerLabel;
    }
}