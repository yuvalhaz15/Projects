﻿namespace WindowsFormsApp1
{
    public enum Gender
    {
        Male,
        Female,
        Other



    }
}