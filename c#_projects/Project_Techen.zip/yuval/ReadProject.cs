﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ReadProject : Form
    {
        private Project projectToMakeActionOn;
        private string projectId;
        public ReadProject()
        {
            InitializeComponent();
            addValuesToProjectsList();
        }
        private void addValuesToProjectsList()
        {
            foreach (Project p in Program.ProjectsInProgress)
            {
                this.projectsList.Items.Add(p.getProjectID());

            }

            foreach (Project p in Program.ProjectsInArchive)
            {
                this.projectsList.Items.Add(p.getProjectID());

            }


        }
        private void projectsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.projectId = this.projectsList.Text;
            this.projectToMakeActionOn = matchIdToProject();
        }

        private Project matchIdToProject()
        {
            foreach (Project P in Program.ProjectsInArchive)
                if (P.getProjectID() == this.projectId)
                    return P;
            foreach (Project P in Program.ProjectsInProgress)
                if (P.getProjectID() == this.projectId)
                    return P;

            return null;
        }
       

        private void ViewButton_Click_1(object sender, EventArgs e)
        {
            if (projectToMakeActionOn != null)
                this.projectToMakeActionOn.readProject();
            else
                MessageBox.Show("Please choose Project");
        }
    }



}

