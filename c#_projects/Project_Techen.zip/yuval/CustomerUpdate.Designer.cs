﻿namespace WindowsFormsApp1
{
    partial class CustomerUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_CustUpd_CustomerMang = new System.Windows.Forms.Label();
            this.label_CustUpd_CustomerUpdate = new System.Windows.Forms.Label();
            this.label_CustUpd_Name = new System.Windows.Forms.Label();
            this.label_CustUpd_CustomerID = new System.Windows.Forms.Label();
            this.label_CustUpd_ContactName = new System.Windows.Forms.Label();
            this.label_CustUpd_Email = new System.Windows.Forms.Label();
            this.label_CustUpd_Phone = new System.Windows.Forms.Label();
            this.btn_CustUpd_Go = new System.Windows.Forms.Button();
            this.btn_CustUpd_Exit = new System.Windows.Forms.Button();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.customerIdTextBox = new System.Windows.Forms.TextBox();
            this.contactNameTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.label_CustUpd_Status = new System.Windows.Forms.Label();
            this.statusComboBox = new System.Windows.Forms.ComboBox();
            this.phoneSetButton = new System.Windows.Forms.Button();
            this.emailSetButton = new System.Windows.Forms.Button();
            this.contactNameSetButton = new System.Windows.Forms.Button();
            this.customerIdSetButton = new System.Windows.Forms.Button();
            this.nameSetButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lastContactDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label_CustUpd_CustomerMang
            // 
            this.label_CustUpd_CustomerMang.AutoSize = true;
            this.label_CustUpd_CustomerMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_CustomerMang.Location = new System.Drawing.Point(243, 58);
            this.label_CustUpd_CustomerMang.Name = "label_CustUpd_CustomerMang";
            this.label_CustUpd_CustomerMang.Size = new System.Drawing.Size(350, 37);
            this.label_CustUpd_CustomerMang.TabIndex = 0;
            this.label_CustUpd_CustomerMang.Text = "Customer Management";
            // 
            // label_CustUpd_CustomerUpdate
            // 
            this.label_CustUpd_CustomerUpdate.AutoSize = true;
            this.label_CustUpd_CustomerUpdate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_CustomerUpdate.Location = new System.Drawing.Point(321, 110);
            this.label_CustUpd_CustomerUpdate.Name = "label_CustUpd_CustomerUpdate";
            this.label_CustUpd_CustomerUpdate.Size = new System.Drawing.Size(180, 27);
            this.label_CustUpd_CustomerUpdate.TabIndex = 1;
            this.label_CustUpd_CustomerUpdate.Text = "Customer Update";
            // 
            // label_CustUpd_Name
            // 
            this.label_CustUpd_Name.AutoSize = true;
            this.label_CustUpd_Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_Name.Location = new System.Drawing.Point(215, 161);
            this.label_CustUpd_Name.Name = "label_CustUpd_Name";
            this.label_CustUpd_Name.Size = new System.Drawing.Size(49, 20);
            this.label_CustUpd_Name.TabIndex = 2;
            this.label_CustUpd_Name.Text = "Name";
            // 
            // label_CustUpd_CustomerID
            // 
            this.label_CustUpd_CustomerID.AutoSize = true;
            this.label_CustUpd_CustomerID.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_CustomerID.Location = new System.Drawing.Point(215, 207);
            this.label_CustUpd_CustomerID.Name = "label_CustUpd_CustomerID";
            this.label_CustUpd_CustomerID.Size = new System.Drawing.Size(88, 20);
            this.label_CustUpd_CustomerID.TabIndex = 3;
            this.label_CustUpd_CustomerID.Text = "CustomerID";
            // 
            // label_CustUpd_ContactName
            // 
            this.label_CustUpd_ContactName.AutoSize = true;
            this.label_CustUpd_ContactName.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_ContactName.Location = new System.Drawing.Point(215, 257);
            this.label_CustUpd_ContactName.Name = "label_CustUpd_ContactName";
            this.label_CustUpd_ContactName.Size = new System.Drawing.Size(105, 20);
            this.label_CustUpd_ContactName.TabIndex = 4;
            this.label_CustUpd_ContactName.Text = "Contact Name";
            // 
            // label_CustUpd_Email
            // 
            this.label_CustUpd_Email.AutoSize = true;
            this.label_CustUpd_Email.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_Email.Location = new System.Drawing.Point(215, 300);
            this.label_CustUpd_Email.Name = "label_CustUpd_Email";
            this.label_CustUpd_Email.Size = new System.Drawing.Size(46, 20);
            this.label_CustUpd_Email.TabIndex = 5;
            this.label_CustUpd_Email.Text = "Email";
            // 
            // label_CustUpd_Phone
            // 
            this.label_CustUpd_Phone.AutoSize = true;
            this.label_CustUpd_Phone.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_Phone.Location = new System.Drawing.Point(215, 344);
            this.label_CustUpd_Phone.Name = "label_CustUpd_Phone";
            this.label_CustUpd_Phone.Size = new System.Drawing.Size(53, 20);
            this.label_CustUpd_Phone.TabIndex = 6;
            this.label_CustUpd_Phone.Text = "Phone";
            // 
            // btn_CustUpd_Go
            // 
            this.btn_CustUpd_Go.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CustUpd_Go.Location = new System.Drawing.Point(326, 470);
            this.btn_CustUpd_Go.Name = "btn_CustUpd_Go";
            this.btn_CustUpd_Go.Size = new System.Drawing.Size(120, 43);
            this.btn_CustUpd_Go.TabIndex = 7;
            this.btn_CustUpd_Go.Text = "Update";
            this.btn_CustUpd_Go.UseVisualStyleBackColor = true;
            this.btn_CustUpd_Go.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_CustUpd_Exit
            // 
            this.btn_CustUpd_Exit.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CustUpd_Exit.Location = new System.Drawing.Point(691, 499);
            this.btn_CustUpd_Exit.Name = "btn_CustUpd_Exit";
            this.btn_CustUpd_Exit.Size = new System.Drawing.Size(95, 34);
            this.btn_CustUpd_Exit.TabIndex = 8;
            this.btn_CustUpd_Exit.Text = "Exit";
            this.btn_CustUpd_Exit.UseVisualStyleBackColor = true;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(326, 161);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(121, 22);
            this.nameTextBox.TabIndex = 9;
            // 
            // customerIdTextBox
            // 
            this.customerIdTextBox.Location = new System.Drawing.Point(326, 206);
            this.customerIdTextBox.Name = "customerIdTextBox";
            this.customerIdTextBox.Size = new System.Drawing.Size(121, 22);
            this.customerIdTextBox.TabIndex = 10;
            // 
            // contactNameTextBox
            // 
            this.contactNameTextBox.Location = new System.Drawing.Point(326, 257);
            this.contactNameTextBox.Name = "contactNameTextBox";
            this.contactNameTextBox.Size = new System.Drawing.Size(121, 22);
            this.contactNameTextBox.TabIndex = 11;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(326, 300);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(121, 22);
            this.emailTextBox.TabIndex = 12;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(326, 343);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(121, 22);
            this.phoneTextBox.TabIndex = 13;
            // 
            // label_CustUpd_Status
            // 
            this.label_CustUpd_Status.AutoSize = true;
            this.label_CustUpd_Status.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CustUpd_Status.Location = new System.Drawing.Point(215, 387);
            this.label_CustUpd_Status.Name = "label_CustUpd_Status";
            this.label_CustUpd_Status.Size = new System.Drawing.Size(50, 20);
            this.label_CustUpd_Status.TabIndex = 6;
            this.label_CustUpd_Status.Text = "Status";
            // 
            // statusComboBox
            // 
            this.statusComboBox.FormattingEnabled = true;
            this.statusComboBox.Location = new System.Drawing.Point(326, 387);
            this.statusComboBox.Name = "statusComboBox";
            this.statusComboBox.Size = new System.Drawing.Size(121, 24);
            this.statusComboBox.TabIndex = 14;
            this.statusComboBox.SelectedIndexChanged += new System.EventHandler(this.statusComboBox_SelectedIndexChanged);
            this.statusComboBox.Click += new System.EventHandler(this.statusComboBox_SelectedIndexChanged);
            // 
            // phoneSetButton
            // 
            this.phoneSetButton.Location = new System.Drawing.Point(464, 344);
            this.phoneSetButton.Name = "phoneSetButton";
            this.phoneSetButton.Size = new System.Drawing.Size(37, 22);
            this.phoneSetButton.TabIndex = 83;
            this.phoneSetButton.Text = "set\r\n\r\n";
            this.phoneSetButton.UseVisualStyleBackColor = true;
            this.phoneSetButton.Click += new System.EventHandler(this.phoneNumberSetButton_Click);
            // 
            // emailSetButton
            // 
            this.emailSetButton.Location = new System.Drawing.Point(464, 298);
            this.emailSetButton.Name = "emailSetButton";
            this.emailSetButton.Size = new System.Drawing.Size(37, 22);
            this.emailSetButton.TabIndex = 84;
            this.emailSetButton.Text = "set\r\n\r\n";
            this.emailSetButton.UseVisualStyleBackColor = true;
            this.emailSetButton.Click += new System.EventHandler(this.emailSetButton_Click);
            // 
            // contactNameSetButton
            // 
            this.contactNameSetButton.Location = new System.Drawing.Point(464, 256);
            this.contactNameSetButton.Name = "contactNameSetButton";
            this.contactNameSetButton.Size = new System.Drawing.Size(37, 22);
            this.contactNameSetButton.TabIndex = 85;
            this.contactNameSetButton.Text = "set\r\n\r\n";
            this.contactNameSetButton.UseVisualStyleBackColor = true;
            this.contactNameSetButton.Click += new System.EventHandler(this.contactNameSetButton_Click);
            // 
            // customerIdSetButton
            // 
            this.customerIdSetButton.Location = new System.Drawing.Point(464, 205);
            this.customerIdSetButton.Name = "customerIdSetButton";
            this.customerIdSetButton.Size = new System.Drawing.Size(37, 22);
            this.customerIdSetButton.TabIndex = 86;
            this.customerIdSetButton.Text = "set\r\n\r\n";
            this.customerIdSetButton.UseVisualStyleBackColor = true;
            this.customerIdSetButton.Click += new System.EventHandler(this.customerIdSetButton_Click);
            // 
            // nameSetButton
            // 
            this.nameSetButton.Location = new System.Drawing.Point(464, 159);
            this.nameSetButton.Name = "nameSetButton";
            this.nameSetButton.Size = new System.Drawing.Size(37, 22);
            this.nameSetButton.TabIndex = 87;
            this.nameSetButton.Text = "set\r\n\r\n";
            this.nameSetButton.UseVisualStyleBackColor = true;
            this.nameSetButton.Click += new System.EventHandler(this.nameSetButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(174, 429);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 17);
            this.label1.TabIndex = 89;
            this.label1.Text = " Last Contact Date ";
            // 
            // lastContactDateTimePicker
            // 
            this.lastContactDateTimePicker.Location = new System.Drawing.Point(326, 429);
            this.lastContactDateTimePicker.Name = "lastContactDateTimePicker";
            this.lastContactDateTimePicker.Size = new System.Drawing.Size(211, 22);
            this.lastContactDateTimePicker.TabIndex = 90;
            this.lastContactDateTimePicker.ValueChanged += new System.EventHandler(this.lastContactDateTimePicker_ValueChanged);
            // 
            // CustomerUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 545);
            this.Controls.Add(this.lastContactDateTimePicker);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nameSetButton);
            this.Controls.Add(this.customerIdSetButton);
            this.Controls.Add(this.contactNameSetButton);
            this.Controls.Add(this.emailSetButton);
            this.Controls.Add(this.phoneSetButton);
            this.Controls.Add(this.statusComboBox);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.emailTextBox);
            this.Controls.Add(this.contactNameTextBox);
            this.Controls.Add(this.customerIdTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.btn_CustUpd_Exit);
            this.Controls.Add(this.btn_CustUpd_Go);
            this.Controls.Add(this.label_CustUpd_Status);
            this.Controls.Add(this.label_CustUpd_Phone);
            this.Controls.Add(this.label_CustUpd_Email);
            this.Controls.Add(this.label_CustUpd_ContactName);
            this.Controls.Add(this.label_CustUpd_CustomerID);
            this.Controls.Add(this.label_CustUpd_Name);
            this.Controls.Add(this.label_CustUpd_CustomerUpdate);
            this.Controls.Add(this.label_CustUpd_CustomerMang);
            this.Name = "CustomerUpdate";
            this.Text = "CustomerUpdate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_CustUpd_CustomerMang;
        private System.Windows.Forms.Label label_CustUpd_CustomerUpdate;
        private System.Windows.Forms.Label label_CustUpd_Name;
        private System.Windows.Forms.Label label_CustUpd_CustomerID;
        private System.Windows.Forms.Label label_CustUpd_ContactName;
        private System.Windows.Forms.Label label_CustUpd_Email;
        private System.Windows.Forms.Label label_CustUpd_Phone;
        private System.Windows.Forms.Button btn_CustUpd_Go;
        private System.Windows.Forms.Button btn_CustUpd_Exit;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox customerIdTextBox;
        private System.Windows.Forms.TextBox contactNameTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.Label label_CustUpd_Status;
        private System.Windows.Forms.ComboBox statusComboBox;
        private System.Windows.Forms.Button phoneSetButton;
        private System.Windows.Forms.Button emailSetButton;
        private System.Windows.Forms.Button contactNameSetButton;
        private System.Windows.Forms.Button customerIdSetButton;
        private System.Windows.Forms.Button nameSetButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker lastContactDateTimePicker;
    }
}