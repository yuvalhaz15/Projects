﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
  public   class Meeting
    {
        private Customer customer;
        private Calendar calendar;
        private MeetingPurposeEnum meetingPurpose;
        private MeetingStatusEnum meetingStatus;
        private string additionalNote;
        private DateTime timeOfMeeting;
        private Employee createdBy;
        private List<Employee> employees;

        public Meeting(Calendar ca, Customer customer, DateTime timeOfMeeting, Employee createdBy, MeetingPurposeEnum meetingPurpose, String additionalNote, MeetingStatusEnum meetingStatus, List<Employee> employees2, bool isNew)
        {
           
            this.customer = customer;
            this.calendar = ca;
            this.meetingPurpose = meetingPurpose;
            this.meetingStatus = meetingStatus;
            this.additionalNote = additionalNote;
            this.timeOfMeeting = timeOfMeeting;
            this.createdBy = createdBy;
            this.employees = employees2;
            this.calendar.getMeetings().Add(this);
            this.createdBy.getCreatedMeetings().Add(this);
            this.customer.getMyMeetings().Add(this);
            foreach (Employee e in employees)
                e.getMyMeetings().Add(this);
            if (isNew)
            {
                
                    this.createMeeting();
                    Program.meetings.Add(this);

                
            }
        }

        private void createMeeting()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_meeting @meetingDate, @customerID, @timeOfMeeting, @createdBy, @purposeOfMeeting, @aditionalNote, @status";
            c.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
            c.Parameters.AddWithValue("@customerID", this.customer.getID());
            c.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
            c.Parameters.AddWithValue("@createdBy", this.createdBy.getId());
            c.Parameters.AddWithValue("@purposeOfMeeting", this.meetingPurpose.ToString());
            c.Parameters.AddWithValue("@aditionalNote", this.additionalNote);
            c.Parameters.AddWithValue("@status", this.meetingStatus.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);

            foreach (Employee e in employees)
            {
                SqlCommand c2 = new SqlCommand();
                c2.CommandText = "EXECUTE SP_add_employeesInMeeting @customerID, @meetingDate, @timeOfMeeting, @employeeID";
                c2.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
                c2.Parameters.AddWithValue("@customerID", this.customer.getID());
                c2.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
                c2.Parameters.AddWithValue("@employeeID", e.getId());
                SQL_CON SC2= new SQL_CON();
                SC2.execute_non_query(c2);
            }


        }

        public void Delete_meeting()
        {
            Program.meetings.Remove(this);
            foreach (Employee e in employees)
            {

                SqlCommand c2 = new SqlCommand();
                c2.CommandText = "EXECUTE dbo.SP_delete_employeesInMeeting @customerID, @meetingDate, @timeOfMeeting, @employeeID";
                c2.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
                c2.Parameters.AddWithValue("@customerID", this.customer.getID());
                c2.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
                c2.Parameters.AddWithValue("@employeeID", e.getId());
                SQL_CON SC2 = new SQL_CON();
                SC2.execute_non_query(c2);
            }
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_delete_meeting @meetingDate, @customerID, @timeOfMeeting, @createdBy, @purposeOfMeeting, @aditionalNote, @status";
            c.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
            c.Parameters.AddWithValue("@customerID", this.customer.getID());
            c.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
            c.Parameters.AddWithValue("@createdBy", this.createdBy.getId());
            c.Parameters.AddWithValue("@purposeOfMeeting", this.meetingPurpose.ToString());
            c.Parameters.AddWithValue("@aditionalNote", this.additionalNote);
            c.Parameters.AddWithValue("@status", this.meetingStatus.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);

        }

        public void Update_meeting(DateTime date, Customer customer, DateTime timeOfMeeting, Employee createdBy, MeetingPurposeEnum meetingPurpose, String additionalNote, MeetingStatusEnum meetingStatus, List<Employee> employees2)
        {
            foreach (Employee e in employees)//מחיקת כל העובדים המשתתפים בפגישה מטבלת העובדים בפגישה
            {

                SqlCommand c1 = new SqlCommand();
                c1.CommandText = "EXECUTE dbo.SP_delete_employeesInMeeting @customerID, @meetingDate, @timeOfMeeting, @employeeID";
                c1.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
                c1.Parameters.AddWithValue("@customerID", this.customer.getID());
                c1.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
                c1.Parameters.AddWithValue("@employeeID", e.getId());
                SQL_CON SC1 = new SQL_CON();
                SC1.execute_non_query(c1);
            }

            Calendar ca = Program.isCalendarExist(date);//אתחול המשתנים החדשים
            if (ca == null)
            {
                ca = new Calendar(date, true);
            }
            this.customer = customer;
            this.calendar = ca;
            this.meetingPurpose = meetingPurpose;
            this.meetingStatus = meetingStatus;
            this.additionalNote = additionalNote;
            this.timeOfMeeting = timeOfMeeting;
            this.createdBy = createdBy;
            foreach (Employee e in employees)
                employees.Remove(e);
            foreach (Employee e in employees2)
                employees.Add(e);

            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_update_meeting @meetingDate, @customerID, @timeOfMeeting, @createdBy, @purposeOfMeeting, @aditionalNote, @status";
            c.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
            c.Parameters.AddWithValue("@customerID", this.customer.getID());
            c.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
            c.Parameters.AddWithValue("@createdBy", this.createdBy.getId());
            c.Parameters.AddWithValue("@purposeOfMeeting", this.meetingPurpose.ToString());
            c.Parameters.AddWithValue("@aditionalNote", this.additionalNote);
            c.Parameters.AddWithValue("@status", this.meetingStatus.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);

            foreach (Employee e in employees)
            {
                SqlCommand c3 = new SqlCommand();
                c3.CommandText = "EXECUTE SP_add_employeesInMeeting @customerID, @meetingDate, @timeOfMeeting, @employeeID";
                c3.Parameters.AddWithValue("@meetingDate", this.calendar.getDate());
                c3.Parameters.AddWithValue("@customerID", this.customer.getID());
                c3.Parameters.AddWithValue("@timeOfMeeting", this.timeOfMeeting);
                c3.Parameters.AddWithValue("@employeeID", e.getId());
                SQL_CON SC3 = new SQL_CON();
                SC3.execute_non_query(c3);
            }
        }

        public Customer getCustomer()
        {

            return customer;
        }

        public List<Employee> GetEmployees()
        {
            return this.employees;
        }
        public void setCustomer(Customer customer)
        {
            this.customer = customer;
        }
        public Calendar getCalendar()
        {

            return this.calendar;
        }
        public void setDT(Calendar c)
        {
            this.calendar = c;
        }
        public MeetingPurposeEnum getMeetingPurpose()
        {

            return meetingPurpose;
        }
        public void setMeetingPurpose(MeetingPurposeEnum meetingPurpose)
        {
            this.meetingPurpose = meetingPurpose;
        }

        public MeetingStatusEnum getMeetingStatus()
        {

            return meetingStatus;
        }
        public void setMeetingStatus(MeetingStatusEnum meetingStatus)
        {
            this.meetingStatus = meetingStatus;
        }

        public string getAdditionalNote()
        {

            return additionalNote;
        }
        public void setAdditionalNote(string additionalNote)
        {
            this.additionalNote = additionalNote;
        }
        public DateTime getTimeOfmeeting()
        {
            return this.timeOfMeeting;
        }
        public void setTimeOfmeeting(DateTime time)
        {

            this.timeOfMeeting = time;
        }

    }
}