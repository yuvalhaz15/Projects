﻿namespace WindowsFormsApp1
{
    partial class PlanMeetings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_PlanMeetings = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.Label_PlanMeetings_ChooseDate = new System.Windows.Forms.Label();
            this.btn_PlanMeetings_NewMeet = new System.Windows.Forms.Button();
            this.btn_PlanMeetings_Back = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Meetings_On_Day = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Label_PlanMeetings
            // 
            this.Label_PlanMeetings.AutoSize = true;
            this.Label_PlanMeetings.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_PlanMeetings.Location = new System.Drawing.Point(306, 47);
            this.Label_PlanMeetings.Name = "Label_PlanMeetings";
            this.Label_PlanMeetings.Size = new System.Drawing.Size(217, 37);
            this.Label_PlanMeetings.TabIndex = 0;
            this.Label_PlanMeetings.Text = "Plan Meetings";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(535, 125);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 1;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // Label_PlanMeetings_ChooseDate
            // 
            this.Label_PlanMeetings_ChooseDate.AutoSize = true;
            this.Label_PlanMeetings_ChooseDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_PlanMeetings_ChooseDate.Location = new System.Drawing.Point(482, 364);
            this.Label_PlanMeetings_ChooseDate.Name = "Label_PlanMeetings_ChooseDate";
            this.Label_PlanMeetings_ChooseDate.Size = new System.Drawing.Size(106, 20);
            this.Label_PlanMeetings_ChooseDate.TabIndex = 2;
            this.Label_PlanMeetings_ChooseDate.Text = "Choose Date : ";
            // 
            // btn_PlanMeetings_NewMeet
            // 
            this.btn_PlanMeetings_NewMeet.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlanMeetings_NewMeet.Location = new System.Drawing.Point(297, 452);
            this.btn_PlanMeetings_NewMeet.Name = "btn_PlanMeetings_NewMeet";
            this.btn_PlanMeetings_NewMeet.Size = new System.Drawing.Size(238, 29);
            this.btn_PlanMeetings_NewMeet.TabIndex = 3;
            this.btn_PlanMeetings_NewMeet.Text = "Add New Meeting";
            this.btn_PlanMeetings_NewMeet.UseVisualStyleBackColor = true;
            this.btn_PlanMeetings_NewMeet.Click += new System.EventHandler(this.btn_PlanMeetings_NewMeet_Click);
            // 
            // btn_PlanMeetings_Back
            // 
            this.btn_PlanMeetings_Back.Location = new System.Drawing.Point(749, 487);
            this.btn_PlanMeetings_Back.Name = "btn_PlanMeetings_Back";
            this.btn_PlanMeetings_Back.Size = new System.Drawing.Size(81, 30);
            this.btn_PlanMeetings_Back.TabIndex = 4;
            this.btn_PlanMeetings_Back.Text = "Back";
            this.btn_PlanMeetings_Back.UseVisualStyleBackColor = true;
            this.btn_PlanMeetings_Back.Click += new System.EventHandler(this.btn_PlanMeetings_Back_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(611, 361);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // Meetings_On_Day
            // 
            this.Meetings_On_Day.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Meetings_On_Day.FormattingEnabled = true;
            this.Meetings_On_Day.ItemHeight = 19;
            this.Meetings_On_Day.Location = new System.Drawing.Point(54, 125);
            this.Meetings_On_Day.Name = "Meetings_On_Day";
            this.Meetings_On_Day.Size = new System.Drawing.Size(368, 194);
            this.Meetings_On_Day.TabIndex = 7;
            this.Meetings_On_Day.SelectedIndexChanged += new System.EventHandler(this.Meetings_On_Day_SelectedIndexChanged);
            // 
            // PlanMeetings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 548);
            this.Controls.Add(this.Meetings_On_Day);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btn_PlanMeetings_Back);
            this.Controls.Add(this.btn_PlanMeetings_NewMeet);
            this.Controls.Add(this.Label_PlanMeetings_ChooseDate);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.Label_PlanMeetings);
            this.Name = "PlanMeetings";
            this.Text = "PlanMeeting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_PlanMeetings;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label Label_PlanMeetings_ChooseDate;
        private System.Windows.Forms.Button btn_PlanMeetings_NewMeet;
        private System.Windows.Forms.Button btn_PlanMeetings_Back;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ListBox Meetings_On_Day;
    }
}