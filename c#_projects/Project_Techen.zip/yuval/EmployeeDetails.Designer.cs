﻿namespace WindowsFormsApp1
{
    partial class EmployeeDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeeIdLabel = new System.Windows.Forms.Label();
            this.EmployeeIDTextBox = new System.Windows.Forms.TextBox();
            this.employeeTypeLabel = new System.Windows.Forms.Label();
            this.employeeTypeTextBox = new System.Windows.Forms.TextBox();
            this.EmployeeFirstNameLabel = new System.Windows.Forms.Label();
            this.employeeFirstNameTextBox1 = new System.Windows.Forms.TextBox();
            this.EmployeeLasNameLeabel = new System.Windows.Forms.Label();
            this.EmployeeLasNameBox = new System.Windows.Forms.TextBox();
            this.employeeSalaryTextBox = new System.Windows.Forms.TextBox();
            this.EmployeePhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.employeeStatusTextBox = new System.Windows.Forms.TextBox();
            this.employeeGenderTextBox = new System.Windows.Forms.TextBox();
            this.employeeHireDateTextBox = new System.Windows.Forms.TextBox();
            this.employeeAdressTextBox = new System.Windows.Forms.TextBox();
            this.employeeBankNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeEmailTextBox = new System.Windows.Forms.TextBox();
            this.employeeForm101TextBox = new System.Windows.Forms.TextBox();
            this.employeeSalaryLabel1 = new System.Windows.Forms.Label();
            this.employeeGenderLabel = new System.Windows.Forms.Label();
            this.employeeEmailLabel = new System.Windows.Forms.Label();
            this.employeeBankAccountLabel = new System.Windows.Forms.Label();
            this.employeeAdressLabel = new System.Windows.Forms.Label();
            this.EmployeePhoneNumberLabel = new System.Windows.Forms.Label();
            this.employeeForm101Label = new System.Windows.Forms.Label();
            this.employeeStatusLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeRankLabel = new System.Windows.Forms.Label();
            this.employeeRankTextBox = new System.Windows.Forms.TextBox();
            this.bankAccountNumTextBox = new System.Windows.Forms.TextBox();
            this.bankAccountBranchTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // EmployeeIdLabel
            // 
            this.EmployeeIdLabel.AutoSize = true;
            this.EmployeeIdLabel.Location = new System.Drawing.Point(61, 32);
            this.EmployeeIdLabel.Name = "EmployeeIdLabel";
            this.EmployeeIdLabel.Size = new System.Drawing.Size(95, 17);
            this.EmployeeIdLabel.TabIndex = 0;
            this.EmployeeIdLabel.Text = "Employee ID :";
            // 
            // EmployeeIDTextBox
            // 
            this.EmployeeIDTextBox.Location = new System.Drawing.Point(560, 32);
            this.EmployeeIDTextBox.Name = "EmployeeIDTextBox";
            this.EmployeeIDTextBox.ReadOnly = true;
            this.EmployeeIDTextBox.Size = new System.Drawing.Size(165, 22);
            this.EmployeeIDTextBox.TabIndex = 1;
            // 
            // employeeTypeLabel
            // 
            this.employeeTypeLabel.AutoSize = true;
            this.employeeTypeLabel.Location = new System.Drawing.Point(61, 76);
            this.employeeTypeLabel.Name = "employeeTypeLabel";
            this.employeeTypeLabel.Size = new System.Drawing.Size(111, 17);
            this.employeeTypeLabel.TabIndex = 2;
            this.employeeTypeLabel.Text = "Employee Role :";
            // 
            // employeeTypeTextBox
            // 
            this.employeeTypeTextBox.Location = new System.Drawing.Point(560, 76);
            this.employeeTypeTextBox.Name = "employeeTypeTextBox";
            this.employeeTypeTextBox.ReadOnly = true;
            this.employeeTypeTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeTypeTextBox.TabIndex = 3;
            // 
            // EmployeeFirstNameLabel
            // 
            this.EmployeeFirstNameLabel.AutoSize = true;
            this.EmployeeFirstNameLabel.Location = new System.Drawing.Point(61, 117);
            this.EmployeeFirstNameLabel.Name = "EmployeeFirstNameLabel";
            this.EmployeeFirstNameLabel.Size = new System.Drawing.Size(150, 17);
            this.EmployeeFirstNameLabel.TabIndex = 4;
            this.EmployeeFirstNameLabel.Text = "Employee First Name :";
            // 
            // employeeFirstNameTextBox1
            // 
            this.employeeFirstNameTextBox1.Location = new System.Drawing.Point(560, 117);
            this.employeeFirstNameTextBox1.Name = "employeeFirstNameTextBox1";
            this.employeeFirstNameTextBox1.ReadOnly = true;
            this.employeeFirstNameTextBox1.Size = new System.Drawing.Size(165, 22);
            this.employeeFirstNameTextBox1.TabIndex = 5;
            // 
            // EmployeeLasNameLeabel
            // 
            this.EmployeeLasNameLeabel.AutoSize = true;
            this.EmployeeLasNameLeabel.Location = new System.Drawing.Point(61, 166);
            this.EmployeeLasNameLeabel.Name = "EmployeeLasNameLeabel";
            this.EmployeeLasNameLeabel.Size = new System.Drawing.Size(150, 17);
            this.EmployeeLasNameLeabel.TabIndex = 6;
            this.EmployeeLasNameLeabel.Text = "Employee Last Name :";
            // 
            // EmployeeLasNameBox
            // 
            this.EmployeeLasNameBox.Location = new System.Drawing.Point(560, 166);
            this.EmployeeLasNameBox.Name = "EmployeeLasNameBox";
            this.EmployeeLasNameBox.ReadOnly = true;
            this.EmployeeLasNameBox.Size = new System.Drawing.Size(165, 22);
            this.EmployeeLasNameBox.TabIndex = 7;
            // 
            // employeeSalaryTextBox
            // 
            this.employeeSalaryTextBox.Location = new System.Drawing.Point(560, 203);
            this.employeeSalaryTextBox.Name = "employeeSalaryTextBox";
            this.employeeSalaryTextBox.ReadOnly = true;
            this.employeeSalaryTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeSalaryTextBox.TabIndex = 8;
            // 
            // EmployeePhoneNumberTextBox
            // 
            this.EmployeePhoneNumberTextBox.Location = new System.Drawing.Point(560, 279);
            this.EmployeePhoneNumberTextBox.Name = "EmployeePhoneNumberTextBox";
            this.EmployeePhoneNumberTextBox.ReadOnly = true;
            this.EmployeePhoneNumberTextBox.Size = new System.Drawing.Size(165, 22);
            this.EmployeePhoneNumberTextBox.TabIndex = 9;
            // 
            // employeeStatusTextBox
            // 
            this.employeeStatusTextBox.Location = new System.Drawing.Point(560, 477);
            this.employeeStatusTextBox.Name = "employeeStatusTextBox";
            this.employeeStatusTextBox.ReadOnly = true;
            this.employeeStatusTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeStatusTextBox.TabIndex = 10;
            // 
            // employeeGenderTextBox
            // 
            this.employeeGenderTextBox.Location = new System.Drawing.Point(560, 433);
            this.employeeGenderTextBox.Name = "employeeGenderTextBox";
            this.employeeGenderTextBox.ReadOnly = true;
            this.employeeGenderTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeGenderTextBox.TabIndex = 11;
            // 
            // employeeHireDateTextBox
            // 
            this.employeeHireDateTextBox.Location = new System.Drawing.Point(560, 240);
            this.employeeHireDateTextBox.Name = "employeeHireDateTextBox";
            this.employeeHireDateTextBox.ReadOnly = true;
            this.employeeHireDateTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeHireDateTextBox.TabIndex = 12;
            // 
            // employeeAdressTextBox
            // 
            this.employeeAdressTextBox.Location = new System.Drawing.Point(560, 316);
            this.employeeAdressTextBox.Name = "employeeAdressTextBox";
            this.employeeAdressTextBox.ReadOnly = true;
            this.employeeAdressTextBox.Size = new System.Drawing.Size(228, 22);
            this.employeeAdressTextBox.TabIndex = 13;
            // 
            // employeeBankNameTextBox
            // 
            this.employeeBankNameTextBox.Location = new System.Drawing.Point(623, 355);
            this.employeeBankNameTextBox.Name = "employeeBankNameTextBox";
            this.employeeBankNameTextBox.ReadOnly = true;
            this.employeeBankNameTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeBankNameTextBox.TabIndex = 14;
            // 
            // employeeEmailTextBox
            // 
            this.employeeEmailTextBox.Location = new System.Drawing.Point(560, 395);
            this.employeeEmailTextBox.Name = "employeeEmailTextBox";
            this.employeeEmailTextBox.ReadOnly = true;
            this.employeeEmailTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeEmailTextBox.TabIndex = 15;
            // 
            // employeeForm101TextBox
            // 
            this.employeeForm101TextBox.Location = new System.Drawing.Point(560, 521);
            this.employeeForm101TextBox.Name = "employeeForm101TextBox";
            this.employeeForm101TextBox.ReadOnly = true;
            this.employeeForm101TextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeForm101TextBox.TabIndex = 16;
            // 
            // employeeSalaryLabel1
            // 
            this.employeeSalaryLabel1.AutoSize = true;
            this.employeeSalaryLabel1.Location = new System.Drawing.Point(61, 203);
            this.employeeSalaryLabel1.Name = "employeeSalaryLabel1";
            this.employeeSalaryLabel1.Size = new System.Drawing.Size(122, 17);
            this.employeeSalaryLabel1.TabIndex = 17;
            this.employeeSalaryLabel1.Text = "Employee Salary :";
            // 
            // employeeGenderLabel
            // 
            this.employeeGenderLabel.AutoSize = true;
            this.employeeGenderLabel.Location = new System.Drawing.Point(61, 433);
            this.employeeGenderLabel.Name = "employeeGenderLabel";
            this.employeeGenderLabel.Size = new System.Drawing.Size(130, 17);
            this.employeeGenderLabel.TabIndex = 19;
            this.employeeGenderLabel.Text = "Employee Gender :";
            // 
            // employeeEmailLabel
            // 
            this.employeeEmailLabel.AutoSize = true;
            this.employeeEmailLabel.Location = new System.Drawing.Point(61, 395);
            this.employeeEmailLabel.Name = "employeeEmailLabel";
            this.employeeEmailLabel.Size = new System.Drawing.Size(116, 17);
            this.employeeEmailLabel.TabIndex = 20;
            this.employeeEmailLabel.Text = "Employee Email :";
            // 
            // employeeBankAccountLabel
            // 
            this.employeeBankAccountLabel.AutoSize = true;
            this.employeeBankAccountLabel.Location = new System.Drawing.Point(61, 355);
            this.employeeBankAccountLabel.Name = "employeeBankAccountLabel";
            this.employeeBankAccountLabel.Size = new System.Drawing.Size(169, 17);
            this.employeeBankAccountLabel.TabIndex = 21;
            this.employeeBankAccountLabel.Text = "Employee Bank Account :";
            // 
            // employeeAdressLabel
            // 
            this.employeeAdressLabel.AutoSize = true;
            this.employeeAdressLabel.Location = new System.Drawing.Point(61, 316);
            this.employeeAdressLabel.Name = "employeeAdressLabel";
            this.employeeAdressLabel.Size = new System.Drawing.Size(126, 17);
            this.employeeAdressLabel.TabIndex = 22;
            this.employeeAdressLabel.Text = "Employee Adress :";
            // 
            // EmployeePhoneNumberLabel
            // 
            this.EmployeePhoneNumberLabel.AutoSize = true;
            this.EmployeePhoneNumberLabel.Location = new System.Drawing.Point(61, 279);
            this.EmployeePhoneNumberLabel.Name = "EmployeePhoneNumberLabel";
            this.EmployeePhoneNumberLabel.Size = new System.Drawing.Size(173, 17);
            this.EmployeePhoneNumberLabel.TabIndex = 23;
            this.EmployeePhoneNumberLabel.Text = "Employee Phone Number:";
            // 
            // employeeForm101Label
            // 
            this.employeeForm101Label.AutoSize = true;
            this.employeeForm101Label.Location = new System.Drawing.Point(61, 521);
            this.employeeForm101Label.Name = "employeeForm101Label";
            this.employeeForm101Label.Size = new System.Drawing.Size(168, 17);
            this.employeeForm101Label.TabIndex = 24;
            this.employeeForm101Label.Text = "Employee Form101 Link :";
            // 
            // employeeStatusLabel
            // 
            this.employeeStatusLabel.AutoSize = true;
            this.employeeStatusLabel.Location = new System.Drawing.Point(61, 477);
            this.employeeStatusLabel.Name = "employeeStatusLabel";
            this.employeeStatusLabel.Size = new System.Drawing.Size(122, 17);
            this.employeeStatusLabel.TabIndex = 25;
            this.employeeStatusLabel.Text = "Employee Status :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 17);
            this.label1.TabIndex = 26;
            this.label1.Text = "Employee Hire Date :";
            // 
            // employeeRankLabel
            // 
            this.employeeRankLabel.AutoSize = true;
            this.employeeRankLabel.Location = new System.Drawing.Point(61, 560);
            this.employeeRankLabel.Name = "employeeRankLabel";
            this.employeeRankLabel.Size = new System.Drawing.Size(115, 17);
            this.employeeRankLabel.TabIndex = 27;
            this.employeeRankLabel.Text = "Employee Rank :";
            // 
            // employeeRankTextBox
            // 
            this.employeeRankTextBox.Location = new System.Drawing.Point(560, 560);
            this.employeeRankTextBox.Name = "employeeRankTextBox";
            this.employeeRankTextBox.ReadOnly = true;
            this.employeeRankTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeRankTextBox.TabIndex = 28;
            // 
            // bankAccountNumTextBox
            // 
            this.bankAccountNumTextBox.Location = new System.Drawing.Point(281, 355);
            this.bankAccountNumTextBox.Name = "bankAccountNumTextBox";
            this.bankAccountNumTextBox.ReadOnly = true;
            this.bankAccountNumTextBox.Size = new System.Drawing.Size(165, 22);
            this.bankAccountNumTextBox.TabIndex = 29;
            // 
            // bankAccountBranchTextBox
            // 
            this.bankAccountBranchTextBox.Location = new System.Drawing.Point(452, 355);
            this.bankAccountBranchTextBox.Name = "bankAccountBranchTextBox";
            this.bankAccountBranchTextBox.ReadOnly = true;
            this.bankAccountBranchTextBox.Size = new System.Drawing.Size(165, 22);
            this.bankAccountBranchTextBox.TabIndex = 30;
            // 
            // EmployeeDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 619);
            this.Controls.Add(this.bankAccountBranchTextBox);
            this.Controls.Add(this.bankAccountNumTextBox);
            this.Controls.Add(this.employeeRankTextBox);
            this.Controls.Add(this.employeeRankLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.employeeStatusLabel);
            this.Controls.Add(this.employeeForm101Label);
            this.Controls.Add(this.EmployeePhoneNumberLabel);
            this.Controls.Add(this.employeeAdressLabel);
            this.Controls.Add(this.employeeBankAccountLabel);
            this.Controls.Add(this.employeeEmailLabel);
            this.Controls.Add(this.employeeGenderLabel);
            this.Controls.Add(this.employeeSalaryLabel1);
            this.Controls.Add(this.employeeForm101TextBox);
            this.Controls.Add(this.employeeEmailTextBox);
            this.Controls.Add(this.employeeBankNameTextBox);
            this.Controls.Add(this.employeeAdressTextBox);
            this.Controls.Add(this.employeeHireDateTextBox);
            this.Controls.Add(this.employeeGenderTextBox);
            this.Controls.Add(this.employeeStatusTextBox);
            this.Controls.Add(this.EmployeePhoneNumberTextBox);
            this.Controls.Add(this.employeeSalaryTextBox);
            this.Controls.Add(this.EmployeeLasNameBox);
            this.Controls.Add(this.EmployeeLasNameLeabel);
            this.Controls.Add(this.employeeFirstNameTextBox1);
            this.Controls.Add(this.EmployeeFirstNameLabel);
            this.Controls.Add(this.employeeTypeTextBox);
            this.Controls.Add(this.employeeTypeLabel);
            this.Controls.Add(this.EmployeeIDTextBox);
            this.Controls.Add(this.EmployeeIdLabel);
            this.Name = "EmployeeDetails";
            this.Text = "EmployeeDetails";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label EmployeeIdLabel;
        private System.Windows.Forms.TextBox EmployeeIDTextBox;
        private System.Windows.Forms.Label employeeTypeLabel;
        private System.Windows.Forms.TextBox employeeTypeTextBox;
        private System.Windows.Forms.Label EmployeeFirstNameLabel;
        private System.Windows.Forms.TextBox employeeFirstNameTextBox1;
        private System.Windows.Forms.Label EmployeeLasNameLeabel;
        private System.Windows.Forms.TextBox EmployeeLasNameBox;
        private System.Windows.Forms.TextBox employeeSalaryTextBox;
        private System.Windows.Forms.TextBox EmployeePhoneNumberTextBox;
        private System.Windows.Forms.TextBox employeeStatusTextBox;
        private System.Windows.Forms.TextBox employeeGenderTextBox;
        private System.Windows.Forms.TextBox employeeHireDateTextBox;
        private System.Windows.Forms.TextBox employeeAdressTextBox;
        private System.Windows.Forms.TextBox employeeBankNameTextBox;
        private System.Windows.Forms.TextBox employeeEmailTextBox;
        private System.Windows.Forms.TextBox employeeForm101TextBox;
        private System.Windows.Forms.Label employeeSalaryLabel1;
        private System.Windows.Forms.Label employeeGenderLabel;
        private System.Windows.Forms.Label employeeEmailLabel;
        private System.Windows.Forms.Label employeeBankAccountLabel;
        private System.Windows.Forms.Label employeeAdressLabel;
        private System.Windows.Forms.Label EmployeePhoneNumberLabel;
        private System.Windows.Forms.Label employeeForm101Label;
        private System.Windows.Forms.Label employeeStatusLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label employeeRankLabel;
        private System.Windows.Forms.TextBox employeeRankTextBox;
        private System.Windows.Forms.TextBox bankAccountNumTextBox;
        private System.Windows.Forms.TextBox bankAccountBranchTextBox;
    }
}