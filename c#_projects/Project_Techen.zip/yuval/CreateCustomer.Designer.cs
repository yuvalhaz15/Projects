﻿namespace WindowsFormsApp1
{
    partial class CreateCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_CreateCustomer_Name = new System.Windows.Forms.Label();
            this.Label_CreateCustomer_ID = new System.Windows.Forms.Label();
            this.Label_CreateCustomer_ContactName = new System.Windows.Forms.Label();
            this.Label_CreateCustomer_Email = new System.Windows.Forms.Label();
            this.Label_CreateCustomer_Phone = new System.Windows.Forms.Label();
            this.cuastomerNameTextBox = new System.Windows.Forms.TextBox();
            this.customerIDTextBox = new System.Windows.Forms.TextBox();
            this.contactNameTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.phoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Label_CreateCustomer_CustManag = new System.Windows.Forms.Label();
            this.Label_CreateCustomer_CreateCust = new System.Windows.Forms.Label();
            this.phoneNumberSetButton = new System.Windows.Forms.Button();
            this.emailSetButton = new System.Windows.Forms.Button();
            this.contactNameSetButton = new System.Windows.Forms.Button();
            this.customerIdSetButton = new System.Windows.Forms.Button();
            this.nameSetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_CreateCustomer_Name
            // 
            this.Label_CreateCustomer_Name.AutoSize = true;
            this.Label_CreateCustomer_Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_Name.Location = new System.Drawing.Point(225, 151);
            this.Label_CreateCustomer_Name.Name = "Label_CreateCustomer_Name";
            this.Label_CreateCustomer_Name.Size = new System.Drawing.Size(52, 20);
            this.Label_CreateCustomer_Name.TabIndex = 0;
            this.Label_CreateCustomer_Name.Text = "Name:";
            this.Label_CreateCustomer_Name.Click += new System.EventHandler(this.label1_Click);
            // 
            // Label_CreateCustomer_ID
            // 
            this.Label_CreateCustomer_ID.AutoSize = true;
            this.Label_CreateCustomer_ID.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_ID.Location = new System.Drawing.Point(224, 188);
            this.Label_CreateCustomer_ID.Name = "Label_CreateCustomer_ID";
            this.Label_CreateCustomer_ID.Size = new System.Drawing.Size(95, 20);
            this.Label_CreateCustomer_ID.TabIndex = 1;
            this.Label_CreateCustomer_ID.Text = "Customer ID:";
            // 
            // Label_CreateCustomer_ContactName
            // 
            this.Label_CreateCustomer_ContactName.AutoSize = true;
            this.Label_CreateCustomer_ContactName.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_ContactName.Location = new System.Drawing.Point(224, 230);
            this.Label_CreateCustomer_ContactName.Name = "Label_CreateCustomer_ContactName";
            this.Label_CreateCustomer_ContactName.Size = new System.Drawing.Size(108, 20);
            this.Label_CreateCustomer_ContactName.TabIndex = 2;
            this.Label_CreateCustomer_ContactName.Text = "Contact Name:";
            // 
            // Label_CreateCustomer_Email
            // 
            this.Label_CreateCustomer_Email.AutoSize = true;
            this.Label_CreateCustomer_Email.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_Email.Location = new System.Drawing.Point(225, 269);
            this.Label_CreateCustomer_Email.Name = "Label_CreateCustomer_Email";
            this.Label_CreateCustomer_Email.Size = new System.Drawing.Size(49, 20);
            this.Label_CreateCustomer_Email.TabIndex = 3;
            this.Label_CreateCustomer_Email.Text = "Email:";
            // 
            // Label_CreateCustomer_Phone
            // 
            this.Label_CreateCustomer_Phone.AutoSize = true;
            this.Label_CreateCustomer_Phone.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_Phone.Location = new System.Drawing.Point(225, 306);
            this.Label_CreateCustomer_Phone.Name = "Label_CreateCustomer_Phone";
            this.Label_CreateCustomer_Phone.Size = new System.Drawing.Size(83, 20);
            this.Label_CreateCustomer_Phone.TabIndex = 4;
            this.Label_CreateCustomer_Phone.Text = "Phone No.:";
            // 
            // cuastomerNameTextBox
            // 
            this.cuastomerNameTextBox.Location = new System.Drawing.Point(338, 151);
            this.cuastomerNameTextBox.Name = "cuastomerNameTextBox";
            this.cuastomerNameTextBox.Size = new System.Drawing.Size(157, 22);
            this.cuastomerNameTextBox.TabIndex = 5;
            // 
            // customerIDTextBox
            // 
            this.customerIDTextBox.Location = new System.Drawing.Point(338, 188);
            this.customerIDTextBox.Name = "customerIDTextBox";
            this.customerIDTextBox.Size = new System.Drawing.Size(157, 22);
            this.customerIDTextBox.TabIndex = 6;
            // 
            // contactNameTextBox
            // 
            this.contactNameTextBox.Location = new System.Drawing.Point(338, 229);
            this.contactNameTextBox.Name = "contactNameTextBox";
            this.contactNameTextBox.Size = new System.Drawing.Size(157, 22);
            this.contactNameTextBox.TabIndex = 7;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(338, 267);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(157, 22);
            this.emailTextBox.TabIndex = 8;
            // 
            // phoneNumberTextBox
            // 
            this.phoneNumberTextBox.Location = new System.Drawing.Point(338, 306);
            this.phoneNumberTextBox.Name = "phoneNumberTextBox";
            this.phoneNumberTextBox.Size = new System.Drawing.Size(157, 22);
            this.phoneNumberTextBox.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(338, 370);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 36);
            this.button1.TabIndex = 10;
            this.button1.Text = "Add Customer";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(663, 402);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 36);
            this.button2.TabIndex = 11;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Label_CreateCustomer_CustManag
            // 
            this.Label_CreateCustomer_CustManag.AutoSize = true;
            this.Label_CreateCustomer_CustManag.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_CustManag.Location = new System.Drawing.Point(249, 46);
            this.Label_CreateCustomer_CustManag.Name = "Label_CreateCustomer_CustManag";
            this.Label_CreateCustomer_CustManag.Size = new System.Drawing.Size(349, 37);
            this.Label_CreateCustomer_CustManag.TabIndex = 12;
            this.Label_CreateCustomer_CustManag.Text = "Customer management";
            // 
            // Label_CreateCustomer_CreateCust
            // 
            this.Label_CreateCustomer_CreateCust.AutoSize = true;
            this.Label_CreateCustomer_CreateCust.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateCustomer_CreateCust.Location = new System.Drawing.Point(324, 94);
            this.Label_CreateCustomer_CreateCust.Name = "Label_CreateCustomer_CreateCust";
            this.Label_CreateCustomer_CreateCust.Size = new System.Drawing.Size(171, 27);
            this.Label_CreateCustomer_CreateCust.TabIndex = 13;
            this.Label_CreateCustomer_CreateCust.Text = "Create Customer";
            // 
            // phoneNumberSetButton
            // 
            this.phoneNumberSetButton.Location = new System.Drawing.Point(519, 306);
            this.phoneNumberSetButton.Name = "phoneNumberSetButton";
            this.phoneNumberSetButton.Size = new System.Drawing.Size(37, 22);
            this.phoneNumberSetButton.TabIndex = 83;
            this.phoneNumberSetButton.Text = "set\r\n\r\n";
            this.phoneNumberSetButton.UseVisualStyleBackColor = true;
            this.phoneNumberSetButton.Click += new System.EventHandler(this.phoneNumberSetButton_Click);
            // 
            // emailSetButton
            // 
            this.emailSetButton.Location = new System.Drawing.Point(519, 269);
            this.emailSetButton.Name = "emailSetButton";
            this.emailSetButton.Size = new System.Drawing.Size(37, 22);
            this.emailSetButton.TabIndex = 84;
            this.emailSetButton.Text = "set\r\n\r\n";
            this.emailSetButton.UseVisualStyleBackColor = true;
            this.emailSetButton.Click += new System.EventHandler(this.emailSetButton_Click);
            // 
            // contactNameSetButton
            // 
            this.contactNameSetButton.Location = new System.Drawing.Point(519, 228);
            this.contactNameSetButton.Name = "contactNameSetButton";
            this.contactNameSetButton.Size = new System.Drawing.Size(37, 22);
            this.contactNameSetButton.TabIndex = 85;
            this.contactNameSetButton.Text = "set\r\n\r\n";
            this.contactNameSetButton.UseVisualStyleBackColor = true;
            this.contactNameSetButton.Click += new System.EventHandler(this.contactNameSetButton_Click);
            // 
            // customerIdSetButton
            // 
            this.customerIdSetButton.Location = new System.Drawing.Point(519, 186);
            this.customerIdSetButton.Name = "customerIdSetButton";
            this.customerIdSetButton.Size = new System.Drawing.Size(37, 22);
            this.customerIdSetButton.TabIndex = 86;
            this.customerIdSetButton.Text = "set\r\n\r\n";
            this.customerIdSetButton.UseVisualStyleBackColor = true;
            this.customerIdSetButton.Click += new System.EventHandler(this.customerIdSetButton_Click);
            // 
            // nameSetButton
            // 
            this.nameSetButton.Location = new System.Drawing.Point(519, 149);
            this.nameSetButton.Name = "nameSetButton";
            this.nameSetButton.Size = new System.Drawing.Size(37, 22);
            this.nameSetButton.TabIndex = 87;
            this.nameSetButton.Text = "set\r\n\r\n";
            this.nameSetButton.UseVisualStyleBackColor = true;
            this.nameSetButton.Click += new System.EventHandler(this.nameSetButton_Click);
            // 
            // CreateCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nameSetButton);
            this.Controls.Add(this.customerIdSetButton);
            this.Controls.Add(this.contactNameSetButton);
            this.Controls.Add(this.emailSetButton);
            this.Controls.Add(this.phoneNumberSetButton);
            this.Controls.Add(this.Label_CreateCustomer_CreateCust);
            this.Controls.Add(this.Label_CreateCustomer_CustManag);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.phoneNumberTextBox);
            this.Controls.Add(this.emailTextBox);
            this.Controls.Add(this.contactNameTextBox);
            this.Controls.Add(this.customerIDTextBox);
            this.Controls.Add(this.cuastomerNameTextBox);
            this.Controls.Add(this.Label_CreateCustomer_Phone);
            this.Controls.Add(this.Label_CreateCustomer_Email);
            this.Controls.Add(this.Label_CreateCustomer_ContactName);
            this.Controls.Add(this.Label_CreateCustomer_ID);
            this.Controls.Add(this.Label_CreateCustomer_Name);
            this.Name = "CreateCustomer";
            this.Text = "CreateCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_CreateCustomer_Name;
        private System.Windows.Forms.Label Label_CreateCustomer_ID;
        private System.Windows.Forms.Label Label_CreateCustomer_ContactName;
        private System.Windows.Forms.Label Label_CreateCustomer_Email;
        private System.Windows.Forms.Label Label_CreateCustomer_Phone;
        private System.Windows.Forms.TextBox cuastomerNameTextBox;
        private System.Windows.Forms.TextBox customerIDTextBox;
        private System.Windows.Forms.TextBox contactNameTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox phoneNumberTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Label_CreateCustomer_CustManag;
        private System.Windows.Forms.Label Label_CreateCustomer_CreateCust;
        private System.Windows.Forms.Button phoneNumberSetButton;
        private System.Windows.Forms.Button emailSetButton;
        private System.Windows.Forms.Button contactNameSetButton;
        private System.Windows.Forms.Button customerIdSetButton;
        private System.Windows.Forms.Button nameSetButton;
    }
}