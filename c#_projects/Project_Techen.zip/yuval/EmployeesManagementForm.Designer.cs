﻿namespace WindowsFormsApp1
{
    partial class EmployeesManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectEmployeeLabel = new System.Windows.Forms.Label();
            this.employeesList = new System.Windows.Forms.ListBox();
            this.checkDetailsButton = new System.Windows.Forms.Button();
            this.editDetailsButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // selectEmployeeLabel
            // 
            this.selectEmployeeLabel.AutoSize = true;
            this.selectEmployeeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.selectEmployeeLabel.Location = new System.Drawing.Point(12, 49);
            this.selectEmployeeLabel.Name = "selectEmployeeLabel";
            this.selectEmployeeLabel.Size = new System.Drawing.Size(341, 29);
            this.selectEmployeeLabel.TabIndex = 0;
            this.selectEmployeeLabel.Text = "Select employee from the list : ";
            this.selectEmployeeLabel.Click += new System.EventHandler(this.selectEmployeeLabel_Click);
            // 
            // employeesList
            // 
            this.employeesList.FormattingEnabled = true;
            this.employeesList.ItemHeight = 16;
            this.employeesList.Location = new System.Drawing.Point(622, 41);
            this.employeesList.Name = "employeesList";
            this.employeesList.Size = new System.Drawing.Size(192, 148);
            this.employeesList.TabIndex = 1;
            this.employeesList.SelectedIndexChanged += new System.EventHandler(this.employeesList_SelectedIndexChanged);
            // 
            // checkDetailsButton
            // 
            this.checkDetailsButton.Location = new System.Drawing.Point(502, 291);
            this.checkDetailsButton.Name = "checkDetailsButton";
            this.checkDetailsButton.Size = new System.Drawing.Size(130, 96);
            this.checkDetailsButton.TabIndex = 2;
            this.checkDetailsButton.Text = "Check Details";
            this.checkDetailsButton.UseVisualStyleBackColor = true;
            this.checkDetailsButton.Click += new System.EventHandler(this.checkDetailsButton_Click);
            // 
            // editDetailsButton
            // 
            this.editDetailsButton.Location = new System.Drawing.Point(814, 291);
            this.editDetailsButton.Name = "editDetailsButton";
            this.editDetailsButton.Size = new System.Drawing.Size(121, 96);
            this.editDetailsButton.TabIndex = 3;
            this.editDetailsButton.Text = "Edit Details";
            this.editDetailsButton.UseVisualStyleBackColor = true;
            this.editDetailsButton.Click += new System.EventHandler(this.editDetailsButton_Click);
            // 
            // EmployeesManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 527);
            this.Controls.Add(this.editDetailsButton);
            this.Controls.Add(this.checkDetailsButton);
            this.Controls.Add(this.employeesList);
            this.Controls.Add(this.selectEmployeeLabel);
            this.Name = "EmployeesManagementForm";
            this.Text = "EmployeesManagementForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label selectEmployeeLabel;
        private System.Windows.Forms.ListBox employeesList;
        private System.Windows.Forms.Button checkDetailsButton;
        private System.Windows.Forms.Button editDetailsButton;
    }
}