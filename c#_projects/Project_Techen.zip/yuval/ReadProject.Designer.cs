﻿namespace WindowsFormsApp1
{
    partial class ReadProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectProjectLabel = new System.Windows.Forms.Label();
            this.projectsList = new System.Windows.Forms.ListBox();
            this.ViewButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // selectProjectLabel
            // 
            this.selectProjectLabel.AutoSize = true;
            this.selectProjectLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.selectProjectLabel.Location = new System.Drawing.Point(279, 79);
            this.selectProjectLabel.Name = "selectProjectLabel";
            this.selectProjectLabel.Size = new System.Drawing.Size(206, 36);
            this.selectProjectLabel.TabIndex = 0;
            this.selectProjectLabel.Text = "Select Project ";
            // 
            // projectsList
            // 
            this.projectsList.FormattingEnabled = true;
            this.projectsList.ItemHeight = 16;
            this.projectsList.Location = new System.Drawing.Point(297, 150);
            this.projectsList.Name = "projectsList";
            this.projectsList.Size = new System.Drawing.Size(174, 148);
            this.projectsList.TabIndex = 1;
            this.projectsList.SelectedIndexChanged += new System.EventHandler(this.projectsList_SelectedIndexChanged);
            // 
            // ViewButton
            // 
            this.ViewButton.Location = new System.Drawing.Point(338, 345);
            this.ViewButton.Name = "ViewButton";
            this.ViewButton.Size = new System.Drawing.Size(97, 49);
            this.ViewButton.TabIndex = 2;
            this.ViewButton.Text = "VIEW";
            this.ViewButton.UseVisualStyleBackColor = true;
            this.ViewButton.Click += new System.EventHandler(this.ViewButton_Click_1);
            // 
            // ReadProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ViewButton);
            this.Controls.Add(this.projectsList);
            this.Controls.Add(this.selectProjectLabel);
            this.Name = "ReadProject";
            this.Text = "ReadProject";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label selectProjectLabel;
        private System.Windows.Forms.ListBox projectsList;
        private System.Windows.Forms.Button ViewButton;
    }
}