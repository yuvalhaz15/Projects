﻿namespace WindowsFormsApp1
{
    partial class CustomerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerPhoneNumberLabel = new System.Windows.Forms.Label();
            this.customerEmailLabel = new System.Windows.Forms.Label();
            this.customerLastContactDateTextBox = new System.Windows.Forms.TextBox();
            this.CustomerPhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.customerMailTextBox = new System.Windows.Forms.TextBox();
            this.customerContactNameBox = new System.Windows.Forms.TextBox();
            this.customerContactNameLabel = new System.Windows.Forms.Label();
            this.customerNameTextBox1 = new System.Windows.Forms.TextBox();
            this.CustomerNameLabel = new System.Windows.Forms.Label();
            this.customerStatusTextBox = new System.Windows.Forms.TextBox();
            this.customerStatusLabel = new System.Windows.Forms.Label();
            this.customerIDTextBox = new System.Windows.Forms.TextBox();
            this.CustomerIdLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 314);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 17);
            this.label1.TabIndex = 40;
            this.label1.Text = "Customer Last Contact Date :";
            // 
            // CustomerPhoneNumberLabel
            // 
            this.CustomerPhoneNumberLabel.AutoSize = true;
            this.CustomerPhoneNumberLabel.Location = new System.Drawing.Point(68, 359);
            this.CustomerPhoneNumberLabel.Name = "CustomerPhoneNumberLabel";
            this.CustomerPhoneNumberLabel.Size = new System.Drawing.Size(171, 17);
            this.CustomerPhoneNumberLabel.TabIndex = 39;
            this.CustomerPhoneNumberLabel.Text = "Customer Phone Number:";
            // 
            // customerEmailLabel
            // 
            this.customerEmailLabel.AutoSize = true;
            this.customerEmailLabel.Location = new System.Drawing.Point(70, 230);
            this.customerEmailLabel.Name = "customerEmailLabel";
            this.customerEmailLabel.Size = new System.Drawing.Size(114, 17);
            this.customerEmailLabel.TabIndex = 38;
            this.customerEmailLabel.Text = "Customer Email :";
            // 
            // customerLastContactDateTextBox
            // 
            this.customerLastContactDateTextBox.Location = new System.Drawing.Point(567, 311);
            this.customerLastContactDateTextBox.Name = "customerLastContactDateTextBox";
            this.customerLastContactDateTextBox.ReadOnly = true;
            this.customerLastContactDateTextBox.Size = new System.Drawing.Size(165, 22);
            this.customerLastContactDateTextBox.TabIndex = 37;
            // 
            // CustomerPhoneNumberTextBox
            // 
            this.CustomerPhoneNumberTextBox.Location = new System.Drawing.Point(567, 354);
            this.CustomerPhoneNumberTextBox.Name = "CustomerPhoneNumberTextBox";
            this.CustomerPhoneNumberTextBox.ReadOnly = true;
            this.CustomerPhoneNumberTextBox.Size = new System.Drawing.Size(165, 22);
            this.CustomerPhoneNumberTextBox.TabIndex = 36;
            // 
            // customerMailTextBox
            // 
            this.customerMailTextBox.Location = new System.Drawing.Point(516, 225);
            this.customerMailTextBox.Name = "customerMailTextBox";
            this.customerMailTextBox.ReadOnly = true;
            this.customerMailTextBox.Size = new System.Drawing.Size(216, 22);
            this.customerMailTextBox.TabIndex = 35;
            // 
            // customerContactNameBox
            // 
            this.customerContactNameBox.Location = new System.Drawing.Point(567, 266);
            this.customerContactNameBox.Name = "customerContactNameBox";
            this.customerContactNameBox.ReadOnly = true;
            this.customerContactNameBox.Size = new System.Drawing.Size(165, 22);
            this.customerContactNameBox.TabIndex = 34;
            // 
            // customerContactNameLabel
            // 
            this.customerContactNameLabel.AutoSize = true;
            this.customerContactNameLabel.Location = new System.Drawing.Point(70, 271);
            this.customerContactNameLabel.Name = "customerContactNameLabel";
            this.customerContactNameLabel.Size = new System.Drawing.Size(169, 17);
            this.customerContactNameLabel.TabIndex = 33;
            this.customerContactNameLabel.Text = "Customer Contact Name :";
            // 
            // customerNameTextBox1
            // 
            this.customerNameTextBox1.Location = new System.Drawing.Point(567, 135);
            this.customerNameTextBox1.Name = "customerNameTextBox1";
            this.customerNameTextBox1.ReadOnly = true;
            this.customerNameTextBox1.Size = new System.Drawing.Size(165, 22);
            this.customerNameTextBox1.TabIndex = 32;
            // 
            // CustomerNameLabel
            // 
            this.CustomerNameLabel.AutoSize = true;
            this.CustomerNameLabel.Location = new System.Drawing.Point(68, 140);
            this.CustomerNameLabel.Name = "CustomerNameLabel";
            this.CustomerNameLabel.Size = new System.Drawing.Size(117, 17);
            this.CustomerNameLabel.TabIndex = 31;
            this.CustomerNameLabel.Text = "Customer Name :";
            // 
            // customerStatusTextBox
            // 
            this.customerStatusTextBox.Location = new System.Drawing.Point(567, 179);
            this.customerStatusTextBox.Name = "customerStatusTextBox";
            this.customerStatusTextBox.ReadOnly = true;
            this.customerStatusTextBox.Size = new System.Drawing.Size(165, 22);
            this.customerStatusTextBox.TabIndex = 30;
            // 
            // customerStatusLabel
            // 
            this.customerStatusLabel.AutoSize = true;
            this.customerStatusLabel.Location = new System.Drawing.Point(70, 179);
            this.customerStatusLabel.Name = "customerStatusLabel";
            this.customerStatusLabel.Size = new System.Drawing.Size(120, 17);
            this.customerStatusLabel.TabIndex = 29;
            this.customerStatusLabel.Text = "Customer Status :";
            // 
            // customerIDTextBox
            // 
            this.customerIDTextBox.Location = new System.Drawing.Point(567, 91);
            this.customerIDTextBox.Name = "customerIDTextBox";
            this.customerIDTextBox.ReadOnly = true;
            this.customerIDTextBox.Size = new System.Drawing.Size(165, 22);
            this.customerIDTextBox.TabIndex = 28;
            // 
            // CustomerIdLabel
            // 
            this.CustomerIdLabel.AutoSize = true;
            this.CustomerIdLabel.Location = new System.Drawing.Point(68, 91);
            this.CustomerIdLabel.Name = "CustomerIdLabel";
            this.CustomerIdLabel.Size = new System.Drawing.Size(93, 17);
            this.CustomerIdLabel.TabIndex = 27;
            this.CustomerIdLabel.Text = "Customer ID :";
            // 
            // CustomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CustomerPhoneNumberLabel);
            this.Controls.Add(this.customerEmailLabel);
            this.Controls.Add(this.customerLastContactDateTextBox);
            this.Controls.Add(this.CustomerPhoneNumberTextBox);
            this.Controls.Add(this.customerMailTextBox);
            this.Controls.Add(this.customerContactNameBox);
            this.Controls.Add(this.customerContactNameLabel);
            this.Controls.Add(this.customerNameTextBox1);
            this.Controls.Add(this.CustomerNameLabel);
            this.Controls.Add(this.customerStatusTextBox);
            this.Controls.Add(this.customerStatusLabel);
            this.Controls.Add(this.customerIDTextBox);
            this.Controls.Add(this.CustomerIdLabel);
            this.Name = "CustomerDetails";
            this.Text = "CustomerDetails";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label CustomerPhoneNumberLabel;
        private System.Windows.Forms.Label customerEmailLabel;
        private System.Windows.Forms.TextBox customerLastContactDateTextBox;
        private System.Windows.Forms.TextBox CustomerPhoneNumberTextBox;
        private System.Windows.Forms.TextBox customerMailTextBox;
        private System.Windows.Forms.TextBox customerContactNameBox;
        private System.Windows.Forms.Label customerContactNameLabel;
        private System.Windows.Forms.TextBox customerNameTextBox1;
        private System.Windows.Forms.Label CustomerNameLabel;
        private System.Windows.Forms.TextBox customerStatusTextBox;
        private System.Windows.Forms.Label customerStatusLabel;
        private System.Windows.Forms.TextBox customerIDTextBox;
        private System.Windows.Forms.Label CustomerIdLabel;
    }
}