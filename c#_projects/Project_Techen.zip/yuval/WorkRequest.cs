﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class WorkRequest : Form
    {
        private Employee requestedBy;
        private Employee approvedBy;
        private String requestNum;
        private DateTime startDate;
        private DateTime endDate;
        private WorkingRequestEnumPurpose purpose;
        private String additionalComment;
        private RequestStatusEnum status;

        public WorkRequest()
        {
            InitializeComponent();
            addValuesToPurposeList();
            addValuesToProjectsManagerList();
        }

        private void addValuesToProjectsManagerList()
        {
            foreach (Employee e in Program.employees)
                if (e.getEmployeeType().ToString() == "Project_Manager" && e.getEmployeeStatus().ToString() == "Current")
                    this.projectManagerListBox.Items.Add(e.getId());
        }

        private void addValuesToPurposeList()
        {
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.Birth_Of_Child);
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.Day_Off);
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.sick_day);
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.submitting_shifts);
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.vacation);
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.Work_Schedule);
            this.comboBox_WorkReq_Purpose.Items.Add(WorkingRequestEnumPurpose.Other);
        }

        private void label_WorkReq_RequestNum_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker_WorkReq_StartDate_ValueChanged(object sender, EventArgs e)
        {
            var x = dateTimePicker_WorkReq_EndDate.Value.Date;
            if (dateTimePicker_WorkReq_StartDate.Value < DateTime.Today)
                MessageBox.Show("Choose date in the future");
            else if (x.DayOfWeek == DayOfWeek.Saturday)
                MessageBox.Show("You choose saturday, please choose correct date");
            else
            {
                this.startDate = dateTimePicker_WorkReq_StartDate.Value;
                MessageBox.Show("date added successfully");

            }

        }

        private void dateTimePicker_WorkReq_EndDate_ValueChanged(object sender, EventArgs e)
        {
            var x = dateTimePicker_WorkReq_EndDate.Value.Date;
            if (dateTimePicker_WorkReq_EndDate.Value < DateTime.Today)
                MessageBox.Show("Choose date in the future");
            else if (x < dateTimePicker_WorkReq_StartDate.Value)
                MessageBox.Show("End date must be bigger the start date");
            else if (x.DayOfWeek == DayOfWeek.Saturday)
                MessageBox.Show("You choose saturday, please choose correct date");
            else
            {
                this.endDate = dateTimePicker_WorkReq_EndDate.Value;
                MessageBox.Show("date added successfully");
            }
        }

        



        private bool IdIsValid()
        {
            return TextBox_WorkReq_RequestNum.Text.Length > 0 && TextBox_WorkReq_RequestNum.Text.Length <= 10 && allNumbers(TextBox_WorkReq_RequestNum.Text) && !idExist(TextBox_WorkReq_RequestNum.Text);

        }

        private bool allNumbers(string toCheck)
        {
            for (int i = 0; i < toCheck.Length; i++)

                if (toCheck[i] < '0' || toCheck[i] > '9')
                    return false;

            return true;
        }
        private bool idExist(string idToCheck)
        {
            if (Program.workingRequests == null)
                return false;
            foreach (WorkingRequest w in Program.workingRequests)
                if (idToCheck == w.getRequestNum())
                    return true;
            return false;
        }

        private void AdditionalCommentBottom_Click(object sender, EventArgs e)
        {
            if (AdditionalCommentIsValid())
            {
                this.additionalComment = this.AdditionalCommentTextBox1.Text;
                MessageBox.Show("Additional Comment  was changed successfully");
            }
            else
            {
                MessageBox.Show("Error !!Additional Comment  un valid");
                this.AdditionalCommentTextBox1.Text = "";

            }
        }

        private bool AdditionalCommentIsValid()
        {
            return this.AdditionalCommentTextBox1.Text.Length <= 100;
        }

        private void RequestNumBotton_Click(object sender, EventArgs e)
        {
            if (IdIsValid())
            {
                this.requestNum = TextBox_WorkReq_RequestNum.Text;
                MessageBox.Show("Request Number was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Request Number is unvalid");
                TextBox_WorkReq_RequestNum.Text = "";

            }
        }

        private void btn_WorkReq_Submit_Click(object sender, EventArgs e)
        {
            if (this.requestNum != null && this.additionalComment != null && this.requestedBy != null&&approvedBy!=null&&this.endDate!=null&&this.startDate!=null)
            {
                WorkingRequest w = new WorkingRequest(this.requestedBy, this.approvedBy, this.requestNum, this.startDate, this.endDate, this.purpose, this.additionalComment, RequestStatusEnum.Approved, true);
                MessageBox.Show("Working Request added successfully");
            }
            else
                MessageBox.Show("One or more details are missing");
        }

        private void MyIDSet_Click(object sender, EventArgs e)
        {
            if (IdIsValid(MyIDTextBox.Text))
            {

                Employee em = Program.seekEmployee(MyIDTextBox.Text);
                this.requestedBy = em;
                MessageBox.Show("Id was found");
            }
            else
            {
                MessageBox.Show("Id was not found");
                MyIDTextBox.Text = "";

            }
        }

        private bool IdIsValid(string id)
        {
            return allNumbers(id) && Program.seekEmployee(id) != null;
        }

        private void comboBox_WorkReq_Purpose_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.purpose = matchStringToPurpose(comboBox_WorkReq_Purpose.Text);

        }

        private WorkingRequestEnumPurpose matchStringToPurpose(string text)
        {
            switch (text)
            {
                case "sick_day":
                    return WorkingRequestEnumPurpose.sick_day;

                case "vacation":
                    return WorkingRequestEnumPurpose.vacation;
                case "Birth_Of_Child":
                    return WorkingRequestEnumPurpose.Birth_Of_Child;
                case "submitting_shifts":
                    return WorkingRequestEnumPurpose.submitting_shifts;
                case "Day_Off":
                    return WorkingRequestEnumPurpose.Day_Off;
                case "Work_Schedule":
                    return WorkingRequestEnumPurpose.Work_Schedule;
                case "Other":
                    return WorkingRequestEnumPurpose.Other;



            }
            return WorkingRequestEnumPurpose.Other;
        }

        private void projectManagerListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.approvedBy = Program.seekEmployee(this.projectManagerListBox.Text);
            MessageBox.Show("Project Manager " + this.approvedBy.getId() + " was selected");
        }
    }
}


