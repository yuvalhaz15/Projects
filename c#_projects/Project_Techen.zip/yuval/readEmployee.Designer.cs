﻿namespace WindowsFormsApp1
{
    partial class readEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkDetailsButton = new System.Windows.Forms.Button();
            this.employeesList = new System.Windows.Forms.ListBox();
            this.selectEmployeeLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkDetailsButton
            // 
            this.checkDetailsButton.Location = new System.Drawing.Point(489, 302);
            this.checkDetailsButton.Name = "checkDetailsButton";
            this.checkDetailsButton.Size = new System.Drawing.Size(130, 96);
            this.checkDetailsButton.TabIndex = 5;
            this.checkDetailsButton.Text = "Check Details";
            this.checkDetailsButton.UseVisualStyleBackColor = true;
            this.checkDetailsButton.Click += new System.EventHandler(this.checkDetailsButton_Click);
            // 
            // employeesList
            // 
            this.employeesList.FormattingEnabled = true;
            this.employeesList.ItemHeight = 16;
            this.employeesList.Location = new System.Drawing.Point(609, 52);
            this.employeesList.Name = "employeesList";
            this.employeesList.Size = new System.Drawing.Size(192, 148);
            this.employeesList.TabIndex = 4;
            this.employeesList.SelectedIndexChanged += new System.EventHandler(this.employeesList_SelectedIndexChanged);
            // 
            // selectEmployeeLabel
            // 
            this.selectEmployeeLabel.AutoSize = true;
            this.selectEmployeeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.selectEmployeeLabel.Location = new System.Drawing.Point(-1, 60);
            this.selectEmployeeLabel.Name = "selectEmployeeLabel";
            this.selectEmployeeLabel.Size = new System.Drawing.Size(341, 29);
            this.selectEmployeeLabel.TabIndex = 3;
            this.selectEmployeeLabel.Text = "Select employee from the list : ";
            // 
            // readEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.checkDetailsButton);
            this.Controls.Add(this.employeesList);
            this.Controls.Add(this.selectEmployeeLabel);
            this.Name = "readEmployee";
            this.Text = "readEmployee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button checkDetailsButton;
        private System.Windows.Forms.ListBox employeesList;
        private System.Windows.Forms.Label selectEmployeeLabel;
    }
}