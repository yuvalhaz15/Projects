﻿namespace WindowsFormsApp1
{
    partial class CreateProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_CreateProject_CreateProj = new System.Windows.Forms.Label();
            this.Label_CreateProject_ProjManag = new System.Windows.Forms.Label();
            this.btn_CreateProj_Exit = new System.Windows.Forms.Button();
            this.btn_CreateProj_AddProj = new System.Windows.Forms.Button();
            this.dateTimePicker_CreateProj_EndTime = new System.Windows.Forms.DateTimePicker();
            this.textBox_CreateProj_SimuLoc = new System.Windows.Forms.TextBox();
            this.textBox_CreateProj_Cost = new System.Windows.Forms.TextBox();
            this.textBox_CreateProj_CompLevel = new System.Windows.Forms.TextBox();
            this.textBox_CreateProj_Name = new System.Windows.Forms.TextBox();
            this.textBox_CreateProj_ProjectID = new System.Windows.Forms.TextBox();
            this.label_CreateProj_SimuLoc = new System.Windows.Forms.Label();
            this.label_CreateProj_Cost = new System.Windows.Forms.Label();
            this.label_CreateProj_ComplexLev = new System.Windows.Forms.Label();
            this.label_CreateProj_ProjectID = new System.Windows.Forms.Label();
            this.label_CreateProj_EndTime = new System.Windows.Forms.Label();
            this.label_CreateProj__Name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.customerIDTextBox = new System.Windows.Forms.TextBox();
            this.setCustomerIdButton = new System.Windows.Forms.Button();
            this.setSimulationLocationButton = new System.Windows.Forms.Button();
            this.setCostButton = new System.Windows.Forms.Button();
            this.setComplexityButton = new System.Windows.Forms.Button();
            this.setProjectNameButton = new System.Windows.Forms.Button();
            this.setProjectIdButton = new System.Windows.Forms.Button();
            this.summaryProjectLabel = new System.Windows.Forms.Label();
            this.summaryTextBox = new System.Windows.Forms.TextBox();
            this.summaryProjectSetButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.managerIdTextBox = new System.Windows.Forms.TextBox();
            this.managerIdButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_CreateProject_CreateProj
            // 
            this.Label_CreateProject_CreateProj.AutoSize = true;
            this.Label_CreateProject_CreateProj.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateProject_CreateProj.Location = new System.Drawing.Point(318, 89);
            this.Label_CreateProject_CreateProj.Name = "Label_CreateProject_CreateProj";
            this.Label_CreateProject_CreateProj.Size = new System.Drawing.Size(145, 27);
            this.Label_CreateProject_CreateProj.TabIndex = 27;
            this.Label_CreateProject_CreateProj.Text = "Create Project";
            // 
            // Label_CreateProject_ProjManag
            // 
            this.Label_CreateProject_ProjManag.AutoSize = true;
            this.Label_CreateProject_ProjManag.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateProject_ProjManag.Location = new System.Drawing.Point(256, 38);
            this.Label_CreateProject_ProjManag.Name = "Label_CreateProject_ProjManag";
            this.Label_CreateProject_ProjManag.Size = new System.Drawing.Size(310, 37);
            this.Label_CreateProject_ProjManag.TabIndex = 26;
            this.Label_CreateProject_ProjManag.Text = "Project management";
            this.Label_CreateProject_ProjManag.Click += new System.EventHandler(this.Label_CreateCustomer_CustManag_Click);
            // 
            // btn_CreateProj_Exit
            // 
            this.btn_CreateProj_Exit.Location = new System.Drawing.Point(664, 494);
            this.btn_CreateProj_Exit.Name = "btn_CreateProj_Exit";
            this.btn_CreateProj_Exit.Size = new System.Drawing.Size(114, 36);
            this.btn_CreateProj_Exit.TabIndex = 25;
            this.btn_CreateProj_Exit.Text = "Exit";
            this.btn_CreateProj_Exit.UseVisualStyleBackColor = true;
            this.btn_CreateProj_Exit.Click += new System.EventHandler(this.btn_CreateProj_Exit_Click);
            // 
            // btn_CreateProj_AddProj
            // 
            this.btn_CreateProj_AddProj.Location = new System.Drawing.Point(25, 494);
            this.btn_CreateProj_AddProj.Name = "btn_CreateProj_AddProj";
            this.btn_CreateProj_AddProj.Size = new System.Drawing.Size(114, 36);
            this.btn_CreateProj_AddProj.TabIndex = 24;
            this.btn_CreateProj_AddProj.Text = "Add Project";
            this.btn_CreateProj_AddProj.UseVisualStyleBackColor = true;
            this.btn_CreateProj_AddProj.Click += new System.EventHandler(this.btn_CreateProj_AddProj_Click);
            // 
            // dateTimePicker_CreateProj_EndTime
            // 
            this.dateTimePicker_CreateProj_EndTime.Location = new System.Drawing.Point(366, 230);
            this.dateTimePicker_CreateProj_EndTime.Name = "dateTimePicker_CreateProj_EndTime";
            this.dateTimePicker_CreateProj_EndTime.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker_CreateProj_EndTime.TabIndex = 47;
            this.dateTimePicker_CreateProj_EndTime.ValueChanged += new System.EventHandler(this.dateTimePicker_CreateProj_EndTime_ValueChanged);
            // 
            // textBox_CreateProj_SimuLoc
            // 
            this.textBox_CreateProj_SimuLoc.Location = new System.Drawing.Point(366, 361);
            this.textBox_CreateProj_SimuLoc.Name = "textBox_CreateProj_SimuLoc";
            this.textBox_CreateProj_SimuLoc.Size = new System.Drawing.Size(200, 22);
            this.textBox_CreateProj_SimuLoc.TabIndex = 44;
            // 
            // textBox_CreateProj_Cost
            // 
            this.textBox_CreateProj_Cost.Location = new System.Drawing.Point(366, 319);
            this.textBox_CreateProj_Cost.Name = "textBox_CreateProj_Cost";
            this.textBox_CreateProj_Cost.Size = new System.Drawing.Size(200, 22);
            this.textBox_CreateProj_Cost.TabIndex = 45;
            // 
            // textBox_CreateProj_CompLevel
            // 
            this.textBox_CreateProj_CompLevel.Location = new System.Drawing.Point(366, 274);
            this.textBox_CreateProj_CompLevel.Name = "textBox_CreateProj_CompLevel";
            this.textBox_CreateProj_CompLevel.Size = new System.Drawing.Size(200, 22);
            this.textBox_CreateProj_CompLevel.TabIndex = 42;
            // 
            // textBox_CreateProj_Name
            // 
            this.textBox_CreateProj_Name.Location = new System.Drawing.Point(366, 180);
            this.textBox_CreateProj_Name.Name = "textBox_CreateProj_Name";
            this.textBox_CreateProj_Name.Size = new System.Drawing.Size(200, 22);
            this.textBox_CreateProj_Name.TabIndex = 41;
            // 
            // textBox_CreateProj_ProjectID
            // 
            this.textBox_CreateProj_ProjectID.Location = new System.Drawing.Point(366, 135);
            this.textBox_CreateProj_ProjectID.Name = "textBox_CreateProj_ProjectID";
            this.textBox_CreateProj_ProjectID.Size = new System.Drawing.Size(200, 22);
            this.textBox_CreateProj_ProjectID.TabIndex = 40;
            // 
            // label_CreateProj_SimuLoc
            // 
            this.label_CreateProj_SimuLoc.AutoSize = true;
            this.label_CreateProj_SimuLoc.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_SimuLoc.Location = new System.Drawing.Point(181, 363);
            this.label_CreateProj_SimuLoc.Name = "label_CreateProj_SimuLoc";
            this.label_CreateProj_SimuLoc.Size = new System.Drawing.Size(147, 20);
            this.label_CreateProj_SimuLoc.TabIndex = 38;
            this.label_CreateProj_SimuLoc.Text = "Simulation Location:";
            // 
            // label_CreateProj_Cost
            // 
            this.label_CreateProj_Cost.AutoSize = true;
            this.label_CreateProj_Cost.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_Cost.Location = new System.Drawing.Point(241, 321);
            this.label_CreateProj_Cost.Name = "label_CreateProj_Cost";
            this.label_CreateProj_Cost.Size = new System.Drawing.Size(41, 20);
            this.label_CreateProj_Cost.TabIndex = 39;
            this.label_CreateProj_Cost.Text = "Cost:";
            // 
            // label_CreateProj_ComplexLev
            // 
            this.label_CreateProj_ComplexLev.AutoSize = true;
            this.label_CreateProj_ComplexLev.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_ComplexLev.Location = new System.Drawing.Point(206, 274);
            this.label_CreateProj_ComplexLev.Name = "label_CreateProj_ComplexLev";
            this.label_CreateProj_ComplexLev.Size = new System.Drawing.Size(122, 20);
            this.label_CreateProj_ComplexLev.TabIndex = 35;
            this.label_CreateProj_ComplexLev.Text = "Complexity level:";
            // 
            // label_CreateProj_ProjectID
            // 
            this.label_CreateProj_ProjectID.AutoSize = true;
            this.label_CreateProj_ProjectID.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_ProjectID.Location = new System.Drawing.Point(229, 137);
            this.label_CreateProj_ProjectID.Name = "label_CreateProj_ProjectID";
            this.label_CreateProj_ProjectID.Size = new System.Drawing.Size(78, 20);
            this.label_CreateProj_ProjectID.TabIndex = 34;
            this.label_CreateProj_ProjectID.Text = "Project ID:";
            // 
            // label_CreateProj_EndTime
            // 
            this.label_CreateProj_EndTime.AutoSize = true;
            this.label_CreateProj_EndTime.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_EndTime.Location = new System.Drawing.Point(232, 233);
            this.label_CreateProj_EndTime.Name = "label_CreateProj_EndTime";
            this.label_CreateProj_EndTime.Size = new System.Drawing.Size(75, 20);
            this.label_CreateProj_EndTime.TabIndex = 33;
            this.label_CreateProj_EndTime.Text = "End Time:";
            // 
            // label_CreateProj__Name
            // 
            this.label_CreateProj__Name.AutoSize = true;
            this.label_CreateProj__Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj__Name.Location = new System.Drawing.Point(241, 182);
            this.label_CreateProj__Name.Name = "label_CreateProj__Name";
            this.label_CreateProj__Name.Size = new System.Drawing.Size(52, 20);
            this.label_CreateProj__Name.TabIndex = 32;
            this.label_CreateProj__Name.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(218, 412);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 48;
            this.label1.Text = "Customer ID:";
            // 
            // customerIDTextBox
            // 
            this.customerIDTextBox.Location = new System.Drawing.Point(367, 407);
            this.customerIDTextBox.Name = "customerIDTextBox";
            this.customerIDTextBox.Size = new System.Drawing.Size(198, 22);
            this.customerIDTextBox.TabIndex = 49;
            // 
            // setCustomerIdButton
            // 
            this.setCustomerIdButton.Location = new System.Drawing.Point(593, 407);
            this.setCustomerIdButton.Name = "setCustomerIdButton";
            this.setCustomerIdButton.Size = new System.Drawing.Size(37, 22);
            this.setCustomerIdButton.TabIndex = 70;
            this.setCustomerIdButton.Text = "set\r\n\r\n";
            this.setCustomerIdButton.UseVisualStyleBackColor = true;
            this.setCustomerIdButton.Click += new System.EventHandler(this.setCustomerIdButton_Click);
            // 
            // setSimulationLocationButton
            // 
            this.setSimulationLocationButton.Location = new System.Drawing.Point(593, 361);
            this.setSimulationLocationButton.Name = "setSimulationLocationButton";
            this.setSimulationLocationButton.Size = new System.Drawing.Size(37, 22);
            this.setSimulationLocationButton.TabIndex = 71;
            this.setSimulationLocationButton.Text = "set\r\n\r\n";
            this.setSimulationLocationButton.UseVisualStyleBackColor = true;
            this.setSimulationLocationButton.Click += new System.EventHandler(this.setSimulationLocationButton_Click);
            // 
            // setCostButton
            // 
            this.setCostButton.Location = new System.Drawing.Point(593, 321);
            this.setCostButton.Name = "setCostButton";
            this.setCostButton.Size = new System.Drawing.Size(37, 22);
            this.setCostButton.TabIndex = 72;
            this.setCostButton.Text = "set\r\n\r\n";
            this.setCostButton.UseVisualStyleBackColor = true;
            this.setCostButton.Click += new System.EventHandler(this.setCostButton_Click);
            // 
            // setComplexityButton
            // 
            this.setComplexityButton.Location = new System.Drawing.Point(593, 272);
            this.setComplexityButton.Name = "setComplexityButton";
            this.setComplexityButton.Size = new System.Drawing.Size(37, 22);
            this.setComplexityButton.TabIndex = 73;
            this.setComplexityButton.Text = "set\r\n\r\n";
            this.setComplexityButton.UseVisualStyleBackColor = true;
            this.setComplexityButton.Click += new System.EventHandler(this.setComplexityButton_Click);
            // 
            // setProjectNameButton
            // 
            this.setProjectNameButton.Location = new System.Drawing.Point(593, 180);
            this.setProjectNameButton.Name = "setProjectNameButton";
            this.setProjectNameButton.Size = new System.Drawing.Size(37, 22);
            this.setProjectNameButton.TabIndex = 74;
            this.setProjectNameButton.Text = "set\r\n\r\n";
            this.setProjectNameButton.UseVisualStyleBackColor = true;
            this.setProjectNameButton.Click += new System.EventHandler(this.setProjectNameButton_Click);
            // 
            // setProjectIdButton
            // 
            this.setProjectIdButton.Location = new System.Drawing.Point(593, 135);
            this.setProjectIdButton.Name = "setProjectIdButton";
            this.setProjectIdButton.Size = new System.Drawing.Size(37, 22);
            this.setProjectIdButton.TabIndex = 75;
            this.setProjectIdButton.Text = "set\r\n\r\n";
            this.setProjectIdButton.UseVisualStyleBackColor = true;
            this.setProjectIdButton.Click += new System.EventHandler(this.setProjectIdButton_Click);
            // 
            // summaryProjectLabel
            // 
            this.summaryProjectLabel.AutoSize = true;
            this.summaryProjectLabel.Location = new System.Drawing.Point(222, 454);
            this.summaryProjectLabel.Name = "summaryProjectLabel";
            this.summaryProjectLabel.Size = new System.Drawing.Size(71, 17);
            this.summaryProjectLabel.TabIndex = 76;
            this.summaryProjectLabel.Text = "Summary ";
            // 
            // summaryTextBox
            // 
            this.summaryTextBox.Location = new System.Drawing.Point(371, 450);
            this.summaryTextBox.Name = "summaryTextBox";
            this.summaryTextBox.Size = new System.Drawing.Size(193, 22);
            this.summaryTextBox.TabIndex = 77;
            // 
            // summaryProjectSetButton
            // 
            this.summaryProjectSetButton.Location = new System.Drawing.Point(593, 449);
            this.summaryProjectSetButton.Name = "summaryProjectSetButton";
            this.summaryProjectSetButton.Size = new System.Drawing.Size(37, 22);
            this.summaryProjectSetButton.TabIndex = 78;
            this.summaryProjectSetButton.Text = "set\r\n\r\n";
            this.summaryProjectSetButton.UseVisualStyleBackColor = true;
            this.summaryProjectSetButton.Click += new System.EventHandler(this.summaryProjectSetButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(222, 504);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 17);
            this.label2.TabIndex = 79;
            this.label2.Text = "Manager ID:";
            // 
            // managerIdTextBox
            // 
            this.managerIdTextBox.Location = new System.Drawing.Point(371, 501);
            this.managerIdTextBox.Name = "managerIdTextBox";
            this.managerIdTextBox.Size = new System.Drawing.Size(193, 22);
            this.managerIdTextBox.TabIndex = 80;
            // 
            // managerIdButton
            // 
            this.managerIdButton.Location = new System.Drawing.Point(593, 501);
            this.managerIdButton.Name = "managerIdButton";
            this.managerIdButton.Size = new System.Drawing.Size(37, 22);
            this.managerIdButton.TabIndex = 81;
            this.managerIdButton.Text = "set\r\n\r\n";
            this.managerIdButton.UseVisualStyleBackColor = true;
            this.managerIdButton.Click += new System.EventHandler(this.managerIdButton_Click);
            // 
            // CreateProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 565);
            this.Controls.Add(this.managerIdButton);
            this.Controls.Add(this.managerIdTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.summaryProjectSetButton);
            this.Controls.Add(this.summaryTextBox);
            this.Controls.Add(this.summaryProjectLabel);
            this.Controls.Add(this.setProjectIdButton);
            this.Controls.Add(this.setProjectNameButton);
            this.Controls.Add(this.setComplexityButton);
            this.Controls.Add(this.setCostButton);
            this.Controls.Add(this.setSimulationLocationButton);
            this.Controls.Add(this.setCustomerIdButton);
            this.Controls.Add(this.customerIDTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker_CreateProj_EndTime);
            this.Controls.Add(this.textBox_CreateProj_SimuLoc);
            this.Controls.Add(this.textBox_CreateProj_Cost);
            this.Controls.Add(this.textBox_CreateProj_CompLevel);
            this.Controls.Add(this.textBox_CreateProj_Name);
            this.Controls.Add(this.textBox_CreateProj_ProjectID);
            this.Controls.Add(this.label_CreateProj_SimuLoc);
            this.Controls.Add(this.label_CreateProj_Cost);
            this.Controls.Add(this.label_CreateProj_ComplexLev);
            this.Controls.Add(this.label_CreateProj_ProjectID);
            this.Controls.Add(this.label_CreateProj_EndTime);
            this.Controls.Add(this.label_CreateProj__Name);
            this.Controls.Add(this.Label_CreateProject_CreateProj);
            this.Controls.Add(this.Label_CreateProject_ProjManag);
            this.Controls.Add(this.btn_CreateProj_Exit);
            this.Controls.Add(this.btn_CreateProj_AddProj);
            this.Name = "CreateProject";
            this.Text = "CreateProject";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_CreateProject_CreateProj;
        private System.Windows.Forms.Label Label_CreateProject_ProjManag;
        private System.Windows.Forms.Button btn_CreateProj_Exit;
        private System.Windows.Forms.Button btn_CreateProj_AddProj;
        private System.Windows.Forms.DateTimePicker dateTimePicker_CreateProj_EndTime;
        private System.Windows.Forms.TextBox textBox_CreateProj_SimuLoc;
        private System.Windows.Forms.TextBox textBox_CreateProj_Cost;
        private System.Windows.Forms.TextBox textBox_CreateProj_CompLevel;
        private System.Windows.Forms.TextBox textBox_CreateProj_Name;
        private System.Windows.Forms.TextBox textBox_CreateProj_ProjectID;
        private System.Windows.Forms.Label label_CreateProj_SimuLoc;
        private System.Windows.Forms.Label label_CreateProj_Cost;
        private System.Windows.Forms.Label label_CreateProj_ComplexLev;
        private System.Windows.Forms.Label label_CreateProj_ProjectID;
        private System.Windows.Forms.Label label_CreateProj_EndTime;
        private System.Windows.Forms.Label label_CreateProj__Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox customerIDTextBox;
        private System.Windows.Forms.Button setCustomerIdButton;
        private System.Windows.Forms.Button setSimulationLocationButton;
        private System.Windows.Forms.Button setCostButton;
        private System.Windows.Forms.Button setComplexityButton;
        private System.Windows.Forms.Button setProjectNameButton;
        private System.Windows.Forms.Button setProjectIdButton;
        private System.Windows.Forms.Label summaryProjectLabel;
        private System.Windows.Forms.TextBox summaryTextBox;
        private System.Windows.Forms.Button summaryProjectSetButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox managerIdTextBox;
        private System.Windows.Forms.Button managerIdButton;
    }
}