﻿namespace WindowsFormsApp1
{
    partial class MarketingManagrWelcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_MarketMangWel_Hello = new System.Windows.Forms.Label();
            this.btn_MarketMang_ReadEmp = new System.Windows.Forms.Button();
            this.btn_MarketMang_CustomerMang = new System.Windows.Forms.Button();
            this.btn_MarketMang_EditCalendar = new System.Windows.Forms.Button();
            this.btn_CustMange_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_MarketMangWel_Hello
            // 
            this.Label_MarketMangWel_Hello.AutoSize = true;
            this.Label_MarketMangWel_Hello.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MarketMangWel_Hello.Location = new System.Drawing.Point(58, 118);
            this.Label_MarketMangWel_Hello.Name = "Label_MarketMangWel_Hello";
            this.Label_MarketMangWel_Hello.Size = new System.Drawing.Size(389, 31);
            this.Label_MarketMangWel_Hello.TabIndex = 0;
            this.Label_MarketMangWel_Hello.Text = "Hello ! Please choose an action ..";
            this.Label_MarketMangWel_Hello.Click += new System.EventHandler(this.Label_MarketMangWel_Hello_Click);
            // 
            // btn_MarketMang_ReadEmp
            // 
            this.btn_MarketMang_ReadEmp.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MarketMang_ReadEmp.Location = new System.Drawing.Point(64, 200);
            this.btn_MarketMang_ReadEmp.Name = "btn_MarketMang_ReadEmp";
            this.btn_MarketMang_ReadEmp.Size = new System.Drawing.Size(172, 42);
            this.btn_MarketMang_ReadEmp.TabIndex = 1;
            this.btn_MarketMang_ReadEmp.Text = "Read Employee Info";
            this.btn_MarketMang_ReadEmp.UseVisualStyleBackColor = true;
            this.btn_MarketMang_ReadEmp.Click += new System.EventHandler(this.btn_MarketMang_ReadEmp_Click);
            // 
            // btn_MarketMang_CustomerMang
            // 
            this.btn_MarketMang_CustomerMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MarketMang_CustomerMang.Location = new System.Drawing.Point(320, 200);
            this.btn_MarketMang_CustomerMang.Name = "btn_MarketMang_CustomerMang";
            this.btn_MarketMang_CustomerMang.Size = new System.Drawing.Size(172, 42);
            this.btn_MarketMang_CustomerMang.TabIndex = 2;
            this.btn_MarketMang_CustomerMang.Text = "Customer managment";
            this.btn_MarketMang_CustomerMang.UseVisualStyleBackColor = true;
            this.btn_MarketMang_CustomerMang.Click += new System.EventHandler(this.btn_MarketMang_CustomerMang_Click);
            // 
            // btn_MarketMang_EditCalendar
            // 
            this.btn_MarketMang_EditCalendar.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MarketMang_EditCalendar.Location = new System.Drawing.Point(576, 200);
            this.btn_MarketMang_EditCalendar.Name = "btn_MarketMang_EditCalendar";
            this.btn_MarketMang_EditCalendar.Size = new System.Drawing.Size(172, 42);
            this.btn_MarketMang_EditCalendar.TabIndex = 3;
            this.btn_MarketMang_EditCalendar.Text = "Edit Calendar";
            this.btn_MarketMang_EditCalendar.UseVisualStyleBackColor = true;
            this.btn_MarketMang_EditCalendar.Click += new System.EventHandler(this.btn_MarketMang_EditCalendar_Click);
            // 
            // btn_CustMange_Back
            // 
            this.btn_CustMange_Back.Location = new System.Drawing.Point(696, 406);
            this.btn_CustMange_Back.Name = "btn_CustMange_Back";
            this.btn_CustMange_Back.Size = new System.Drawing.Size(83, 32);
            this.btn_CustMange_Back.TabIndex = 8;
            this.btn_CustMange_Back.Text = "Back";
            this.btn_CustMange_Back.UseVisualStyleBackColor = true;
            this.btn_CustMange_Back.Click += new System.EventHandler(this.btn_CustMange_Back_Click);
            // 
            // MarketingManagrWelcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_CustMange_Back);
            this.Controls.Add(this.btn_MarketMang_EditCalendar);
            this.Controls.Add(this.btn_MarketMang_CustomerMang);
            this.Controls.Add(this.btn_MarketMang_ReadEmp);
            this.Controls.Add(this.Label_MarketMangWel_Hello);
            this.Name = "MarketingManagrWelcome";
            this.Text = "MarketingManagrWelcome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_MarketMangWel_Hello;
        private System.Windows.Forms.Button btn_MarketMang_ReadEmp;
        private System.Windows.Forms.Button btn_MarketMang_CustomerMang;
        private System.Windows.Forms.Button btn_MarketMang_EditCalendar;
        private System.Windows.Forms.Button btn_CustMange_Back;
    }
}