﻿namespace WindowsFormsApp1
{
    partial class UpdateEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.employeeRankTextBox = new System.Windows.Forms.TextBox();
            this.employeeRankLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeStatusLabel = new System.Windows.Forms.Label();
            this.employeeForm101Label = new System.Windows.Forms.Label();
            this.EmployeePhoneNumberLabel = new System.Windows.Forms.Label();
            this.employeeAdressLabel = new System.Windows.Forms.Label();
            this.employeeBankAccountLabel = new System.Windows.Forms.Label();
            this.employeeEmailLabel = new System.Windows.Forms.Label();
            this.employeeGenderLabel = new System.Windows.Forms.Label();
            this.employeeSalaryLabel1 = new System.Windows.Forms.Label();
            this.employeeForm101TextBox = new System.Windows.Forms.TextBox();
            this.employeeEmailTextBox = new System.Windows.Forms.TextBox();
            this.employeeBankNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeAdressTextBox = new System.Windows.Forms.TextBox();
            this.EmployeePhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.employeeSalaryTextBox = new System.Windows.Forms.TextBox();
            this.EmployeeLasNameBox = new System.Windows.Forms.TextBox();
            this.EmployeeLasNameLeabel = new System.Windows.Forms.Label();
            this.employeeFirstNameTextBox1 = new System.Windows.Forms.TextBox();
            this.EmployeeFirstNameLabel = new System.Windows.Forms.Label();
            this.employeeTypeLabel = new System.Windows.Forms.Label();
            this.EmployeeIDTextBox = new System.Windows.Forms.TextBox();
            this.EmployeeIdLabel = new System.Windows.Forms.Label();
            this.employeesRolesLIst = new System.Windows.Forms.ListBox();
            this.rankSetButton = new System.Windows.Forms.Button();
            this.EmployeeForm101SetButton = new System.Windows.Forms.Button();
            this.employeeEmailSetButton = new System.Windows.Forms.Button();
            this.bankAccountSetBottun = new System.Windows.Forms.Button();
            this.employeeAdressSetButton = new System.Windows.Forms.Button();
            this.employeePhoneNumberSet = new System.Windows.Forms.Button();
            this.employeeSetSalaryButton = new System.Windows.Forms.Button();
            this.employeeLastNameSetBottun = new System.Windows.Forms.Button();
            this.firstNameButton = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.employeeGenderListBox = new System.Windows.Forms.ListBox();
            this.employeeStatusListBox = new System.Windows.Forms.ListBox();
            this.bankAccountBranchTextBox = new System.Windows.Forms.TextBox();
            this.employeeBankAccountBankNumTextBox = new System.Windows.Forms.TextBox();
            this.updateButton = new System.Windows.Forms.Button();
            this.managerLabel = new System.Windows.Forms.Label();
            this.managerTextBox = new System.Windows.Forms.TextBox();
            this.manageSetButton = new System.Windows.Forms.Button();
            this.form101ToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.calculateRankButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // employeeRankTextBox
            // 
            this.employeeRankTextBox.Location = new System.Drawing.Point(522, 526);
            this.employeeRankTextBox.Name = "employeeRankTextBox";
            this.employeeRankTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeRankTextBox.TabIndex = 56;
            // 
            // employeeRankLabel
            // 
            this.employeeRankLabel.AutoSize = true;
            this.employeeRankLabel.Location = new System.Drawing.Point(22, 531);
            this.employeeRankLabel.Name = "employeeRankLabel";
            this.employeeRankLabel.Size = new System.Drawing.Size(115, 17);
            this.employeeRankLabel.TabIndex = 55;
            this.employeeRankLabel.Text = "Employee Rank :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 17);
            this.label1.TabIndex = 54;
            this.label1.Text = "Employee Hire Date :";
            // 
            // employeeStatusLabel
            // 
            this.employeeStatusLabel.AutoSize = true;
            this.employeeStatusLabel.Location = new System.Drawing.Point(21, 443);
            this.employeeStatusLabel.Name = "employeeStatusLabel";
            this.employeeStatusLabel.Size = new System.Drawing.Size(122, 17);
            this.employeeStatusLabel.TabIndex = 53;
            this.employeeStatusLabel.Text = "Employee Status :";
            // 
            // employeeForm101Label
            // 
            this.employeeForm101Label.AutoSize = true;
            this.employeeForm101Label.Location = new System.Drawing.Point(21, 482);
            this.employeeForm101Label.Name = "employeeForm101Label";
            this.employeeForm101Label.Size = new System.Drawing.Size(168, 17);
            this.employeeForm101Label.TabIndex = 52;
            this.employeeForm101Label.Text = "Employee Form101 Link :";
            // 
            // EmployeePhoneNumberLabel
            // 
            this.EmployeePhoneNumberLabel.AutoSize = true;
            this.EmployeePhoneNumberLabel.Location = new System.Drawing.Point(21, 250);
            this.EmployeePhoneNumberLabel.Name = "EmployeePhoneNumberLabel";
            this.EmployeePhoneNumberLabel.Size = new System.Drawing.Size(173, 17);
            this.EmployeePhoneNumberLabel.TabIndex = 51;
            this.EmployeePhoneNumberLabel.Text = "Employee Phone Number:";
            // 
            // employeeAdressLabel
            // 
            this.employeeAdressLabel.AutoSize = true;
            this.employeeAdressLabel.Location = new System.Drawing.Point(21, 292);
            this.employeeAdressLabel.Name = "employeeAdressLabel";
            this.employeeAdressLabel.Size = new System.Drawing.Size(126, 17);
            this.employeeAdressLabel.TabIndex = 50;
            this.employeeAdressLabel.Text = "Employee Adress :";
            // 
            // employeeBankAccountLabel
            // 
            this.employeeBankAccountLabel.AutoSize = true;
            this.employeeBankAccountLabel.Location = new System.Drawing.Point(21, 329);
            this.employeeBankAccountLabel.Name = "employeeBankAccountLabel";
            this.employeeBankAccountLabel.Size = new System.Drawing.Size(169, 17);
            this.employeeBankAccountLabel.TabIndex = 49;
            this.employeeBankAccountLabel.Text = "Employee Bank Account :";
            // 
            // employeeEmailLabel
            // 
            this.employeeEmailLabel.AutoSize = true;
            this.employeeEmailLabel.Location = new System.Drawing.Point(21, 362);
            this.employeeEmailLabel.Name = "employeeEmailLabel";
            this.employeeEmailLabel.Size = new System.Drawing.Size(116, 17);
            this.employeeEmailLabel.TabIndex = 48;
            this.employeeEmailLabel.Text = "Employee Email :";
            // 
            // employeeGenderLabel
            // 
            this.employeeGenderLabel.AutoSize = true;
            this.employeeGenderLabel.Location = new System.Drawing.Point(21, 405);
            this.employeeGenderLabel.Name = "employeeGenderLabel";
            this.employeeGenderLabel.Size = new System.Drawing.Size(130, 17);
            this.employeeGenderLabel.TabIndex = 47;
            this.employeeGenderLabel.Text = "Employee Gender :";
            // 
            // employeeSalaryLabel1
            // 
            this.employeeSalaryLabel1.AutoSize = true;
            this.employeeSalaryLabel1.Location = new System.Drawing.Point(21, 176);
            this.employeeSalaryLabel1.Name = "employeeSalaryLabel1";
            this.employeeSalaryLabel1.Size = new System.Drawing.Size(122, 17);
            this.employeeSalaryLabel1.TabIndex = 46;
            this.employeeSalaryLabel1.Text = "Employee Salary :";
            // 
            // employeeForm101TextBox
            // 
            this.employeeForm101TextBox.Location = new System.Drawing.Point(522, 482);
            this.employeeForm101TextBox.Name = "employeeForm101TextBox";
            this.employeeForm101TextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeForm101TextBox.TabIndex = 45;
            // 
            // employeeEmailTextBox
            // 
            this.employeeEmailTextBox.Location = new System.Drawing.Point(519, 360);
            this.employeeEmailTextBox.Name = "employeeEmailTextBox";
            this.employeeEmailTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeEmailTextBox.TabIndex = 44;
            // 
            // employeeBankNameTextBox
            // 
            this.employeeBankNameTextBox.Location = new System.Drawing.Point(563, 326);
            this.employeeBankNameTextBox.Name = "employeeBankNameTextBox";
            this.employeeBankNameTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeBankNameTextBox.TabIndex = 43;
            // 
            // employeeAdressTextBox
            // 
            this.employeeAdressTextBox.Location = new System.Drawing.Point(486, 289);
            this.employeeAdressTextBox.Name = "employeeAdressTextBox";
            this.employeeAdressTextBox.Size = new System.Drawing.Size(196, 22);
            this.employeeAdressTextBox.TabIndex = 42;
            // 
            // EmployeePhoneNumberTextBox
            // 
            this.EmployeePhoneNumberTextBox.Location = new System.Drawing.Point(517, 250);
            this.EmployeePhoneNumberTextBox.Name = "EmployeePhoneNumberTextBox";
            this.EmployeePhoneNumberTextBox.Size = new System.Drawing.Size(165, 22);
            this.EmployeePhoneNumberTextBox.TabIndex = 38;
            // 
            // employeeSalaryTextBox
            // 
            this.employeeSalaryTextBox.Location = new System.Drawing.Point(517, 176);
            this.employeeSalaryTextBox.Name = "employeeSalaryTextBox";
            this.employeeSalaryTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeSalaryTextBox.TabIndex = 37;
            // 
            // EmployeeLasNameBox
            // 
            this.EmployeeLasNameBox.Location = new System.Drawing.Point(517, 139);
            this.EmployeeLasNameBox.Name = "EmployeeLasNameBox";
            this.EmployeeLasNameBox.Size = new System.Drawing.Size(165, 22);
            this.EmployeeLasNameBox.TabIndex = 36;
            // 
            // EmployeeLasNameLeabel
            // 
            this.EmployeeLasNameLeabel.AutoSize = true;
            this.EmployeeLasNameLeabel.Location = new System.Drawing.Point(21, 130);
            this.EmployeeLasNameLeabel.Name = "EmployeeLasNameLeabel";
            this.EmployeeLasNameLeabel.Size = new System.Drawing.Size(150, 17);
            this.EmployeeLasNameLeabel.TabIndex = 35;
            this.EmployeeLasNameLeabel.Text = "Employee Last Name :";
            // 
            // employeeFirstNameTextBox1
            // 
            this.employeeFirstNameTextBox1.Location = new System.Drawing.Point(517, 95);
            this.employeeFirstNameTextBox1.Name = "employeeFirstNameTextBox1";
            this.employeeFirstNameTextBox1.Size = new System.Drawing.Size(165, 22);
            this.employeeFirstNameTextBox1.TabIndex = 34;
            // 
            // EmployeeFirstNameLabel
            // 
            this.EmployeeFirstNameLabel.AutoSize = true;
            this.EmployeeFirstNameLabel.Location = new System.Drawing.Point(21, 95);
            this.EmployeeFirstNameLabel.Name = "EmployeeFirstNameLabel";
            this.EmployeeFirstNameLabel.Size = new System.Drawing.Size(150, 17);
            this.EmployeeFirstNameLabel.TabIndex = 33;
            this.EmployeeFirstNameLabel.Text = "Employee First Name :";
            // 
            // employeeTypeLabel
            // 
            this.employeeTypeLabel.AutoSize = true;
            this.employeeTypeLabel.Location = new System.Drawing.Point(21, 51);
            this.employeeTypeLabel.Name = "employeeTypeLabel";
            this.employeeTypeLabel.Size = new System.Drawing.Size(111, 17);
            this.employeeTypeLabel.TabIndex = 31;
            this.employeeTypeLabel.Text = "Employee Role :";
            // 
            // EmployeeIDTextBox
            // 
            this.EmployeeIDTextBox.Location = new System.Drawing.Point(517, 9);
            this.EmployeeIDTextBox.Name = "EmployeeIDTextBox";
            this.EmployeeIDTextBox.ReadOnly = true;
            this.EmployeeIDTextBox.Size = new System.Drawing.Size(165, 22);
            this.EmployeeIDTextBox.TabIndex = 30;
            // 
            // EmployeeIdLabel
            // 
            this.EmployeeIdLabel.AutoSize = true;
            this.EmployeeIdLabel.Location = new System.Drawing.Point(21, 9);
            this.EmployeeIdLabel.Name = "EmployeeIdLabel";
            this.EmployeeIdLabel.Size = new System.Drawing.Size(95, 17);
            this.EmployeeIdLabel.TabIndex = 29;
            this.EmployeeIdLabel.Text = "Employee ID :";
            // 
            // employeesRolesLIst
            // 
            this.employeesRolesLIst.FormattingEnabled = true;
            this.employeesRolesLIst.ItemHeight = 16;
            this.employeesRolesLIst.Location = new System.Drawing.Point(519, 51);
            this.employeesRolesLIst.Name = "employeesRolesLIst";
            this.employeesRolesLIst.Size = new System.Drawing.Size(163, 20);
            this.employeesRolesLIst.TabIndex = 57;
            this.employeesRolesLIst.SelectedIndexChanged += new System.EventHandler(this.employeesRolesLIst_SelectedIndexChanged);
            // 
            // rankSetButton
            // 
            this.rankSetButton.Location = new System.Drawing.Point(693, 526);
            this.rankSetButton.Name = "rankSetButton";
            this.rankSetButton.Size = new System.Drawing.Size(37, 22);
            this.rankSetButton.TabIndex = 59;
            this.rankSetButton.Text = "set\r\n\r\n";
            this.rankSetButton.UseVisualStyleBackColor = true;
            this.rankSetButton.Click += new System.EventHandler(this.rankSetButton_Click);
            // 
            // EmployeeForm101SetButton
            // 
            this.EmployeeForm101SetButton.Location = new System.Drawing.Point(693, 484);
            this.EmployeeForm101SetButton.Name = "EmployeeForm101SetButton";
            this.EmployeeForm101SetButton.Size = new System.Drawing.Size(37, 22);
            this.EmployeeForm101SetButton.TabIndex = 60;
            this.EmployeeForm101SetButton.Text = "set\r\n\r\n";
            this.EmployeeForm101SetButton.UseVisualStyleBackColor = true;
            this.EmployeeForm101SetButton.Click += new System.EventHandler(this.EmployeeForm101SetButton_Click);
            // 
            // employeeEmailSetButton
            // 
            this.employeeEmailSetButton.Location = new System.Drawing.Point(700, 362);
            this.employeeEmailSetButton.Name = "employeeEmailSetButton";
            this.employeeEmailSetButton.Size = new System.Drawing.Size(37, 22);
            this.employeeEmailSetButton.TabIndex = 61;
            this.employeeEmailSetButton.Text = "set\r\n\r\n";
            this.employeeEmailSetButton.UseVisualStyleBackColor = true;
            this.employeeEmailSetButton.Click += new System.EventHandler(this.employeeEmailSetButton_Click);
            // 
            // bankAccountSetBottun
            // 
            this.bankAccountSetBottun.Location = new System.Drawing.Point(751, 326);
            this.bankAccountSetBottun.Name = "bankAccountSetBottun";
            this.bankAccountSetBottun.Size = new System.Drawing.Size(37, 22);
            this.bankAccountSetBottun.TabIndex = 63;
            this.bankAccountSetBottun.Text = "set\r\n\r\n";
            this.bankAccountSetBottun.UseVisualStyleBackColor = true;
            this.bankAccountSetBottun.Click += new System.EventHandler(this.bankAccountSetBottun_Click);
            // 
            // employeeAdressSetButton
            // 
            this.employeeAdressSetButton.Location = new System.Drawing.Point(691, 287);
            this.employeeAdressSetButton.Name = "employeeAdressSetButton";
            this.employeeAdressSetButton.Size = new System.Drawing.Size(37, 22);
            this.employeeAdressSetButton.TabIndex = 64;
            this.employeeAdressSetButton.Text = "set\r\n\r\n";
            this.employeeAdressSetButton.UseVisualStyleBackColor = true;
            this.employeeAdressSetButton.Click += new System.EventHandler(this.employeeAdressSetButton_Click);
            // 
            // employeePhoneNumberSet
            // 
            this.employeePhoneNumberSet.Location = new System.Drawing.Point(693, 247);
            this.employeePhoneNumberSet.Name = "employeePhoneNumberSet";
            this.employeePhoneNumberSet.Size = new System.Drawing.Size(37, 22);
            this.employeePhoneNumberSet.TabIndex = 65;
            this.employeePhoneNumberSet.Text = "set\r\n\r\n";
            this.employeePhoneNumberSet.UseVisualStyleBackColor = true;
            this.employeePhoneNumberSet.Click += new System.EventHandler(this.employeePhoneNumberSet_Click);
            // 
            // employeeSetSalaryButton
            // 
            this.employeeSetSalaryButton.Location = new System.Drawing.Point(691, 176);
            this.employeeSetSalaryButton.Name = "employeeSetSalaryButton";
            this.employeeSetSalaryButton.Size = new System.Drawing.Size(37, 22);
            this.employeeSetSalaryButton.TabIndex = 67;
            this.employeeSetSalaryButton.Text = "set\r\n\r\n";
            this.employeeSetSalaryButton.UseVisualStyleBackColor = true;
            this.employeeSetSalaryButton.Click += new System.EventHandler(this.employeeSetSalaryButton_Click);
            // 
            // employeeLastNameSetBottun
            // 
            this.employeeLastNameSetBottun.Location = new System.Drawing.Point(693, 139);
            this.employeeLastNameSetBottun.Name = "employeeLastNameSetBottun";
            this.employeeLastNameSetBottun.Size = new System.Drawing.Size(37, 22);
            this.employeeLastNameSetBottun.TabIndex = 68;
            this.employeeLastNameSetBottun.Text = "set\r\n\r\n";
            this.employeeLastNameSetBottun.UseVisualStyleBackColor = true;
            this.employeeLastNameSetBottun.Click += new System.EventHandler(this.employeeLastNameSetBottun_Click);
            // 
            // firstNameButton
            // 
            this.firstNameButton.Location = new System.Drawing.Point(691, 95);
            this.firstNameButton.Name = "firstNameButton";
            this.firstNameButton.Size = new System.Drawing.Size(37, 22);
            this.firstNameButton.TabIndex = 69;
            this.firstNameButton.Text = "set\r\n\r\n";
            this.firstNameButton.UseVisualStyleBackColor = true;
            this.firstNameButton.Click += new System.EventHandler(this.firstNameButton_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(428, 213);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(254, 22);
            this.dateTimePicker1.TabIndex = 70;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // employeeGenderListBox
            // 
            this.employeeGenderListBox.FormattingEnabled = true;
            this.employeeGenderListBox.ItemHeight = 16;
            this.employeeGenderListBox.Location = new System.Drawing.Point(522, 402);
            this.employeeGenderListBox.Name = "employeeGenderListBox";
            this.employeeGenderListBox.Size = new System.Drawing.Size(163, 20);
            this.employeeGenderListBox.TabIndex = 71;
            this.employeeGenderListBox.SelectedIndexChanged += new System.EventHandler(this.employeeGenderListBox_SelectedIndexChanged);
            // 
            // employeeStatusListBox
            // 
            this.employeeStatusListBox.FormattingEnabled = true;
            this.employeeStatusListBox.ItemHeight = 16;
            this.employeeStatusListBox.Location = new System.Drawing.Point(522, 443);
            this.employeeStatusListBox.Name = "employeeStatusListBox";
            this.employeeStatusListBox.Size = new System.Drawing.Size(163, 20);
            this.employeeStatusListBox.TabIndex = 72;
            this.employeeStatusListBox.SelectedIndexChanged += new System.EventHandler(this.employeeStatusListBox_SelectedIndexChanged);
            // 
            // bankAccountBranchTextBox
            // 
            this.bankAccountBranchTextBox.Location = new System.Drawing.Point(392, 326);
            this.bankAccountBranchTextBox.Name = "bankAccountBranchTextBox";
            this.bankAccountBranchTextBox.Size = new System.Drawing.Size(165, 22);
            this.bankAccountBranchTextBox.TabIndex = 73;
            // 
            // employeeBankAccountBankNumTextBox
            // 
            this.employeeBankAccountBankNumTextBox.Location = new System.Drawing.Point(221, 326);
            this.employeeBankAccountBankNumTextBox.Name = "employeeBankAccountBankNumTextBox";
            this.employeeBankAccountBankNumTextBox.Size = new System.Drawing.Size(165, 22);
            this.employeeBankAccountBankNumTextBox.TabIndex = 74;
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(300, 642);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(117, 40);
            this.updateButton.TabIndex = 75;
            this.updateButton.Text = "UPDATE";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // managerLabel
            // 
            this.managerLabel.AutoSize = true;
            this.managerLabel.Location = new System.Drawing.Point(22, 571);
            this.managerLabel.Name = "managerLabel";
            this.managerLabel.Size = new System.Drawing.Size(72, 17);
            this.managerLabel.TabIndex = 76;
            this.managerLabel.Text = "Manager :";
            // 
            // managerTextBox
            // 
            this.managerTextBox.Location = new System.Drawing.Point(522, 571);
            this.managerTextBox.Name = "managerTextBox";
            this.managerTextBox.Size = new System.Drawing.Size(165, 22);
            this.managerTextBox.TabIndex = 77;
            // 
            // manageSetButton
            // 
            this.manageSetButton.Location = new System.Drawing.Point(693, 571);
            this.manageSetButton.Name = "manageSetButton";
            this.manageSetButton.Size = new System.Drawing.Size(37, 22);
            this.manageSetButton.TabIndex = 78;
            this.manageSetButton.Text = "set\r\n\r\n";
            this.manageSetButton.UseVisualStyleBackColor = true;
            this.manageSetButton.Click += new System.EventHandler(this.manageSetButton_Click);
            // 
            // form101ToolTip
            // 
            this.form101ToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.form101ToolTip.Popup += new System.Windows.Forms.PopupEventHandler(this.form101ToolTip_Popup);
            // 
            // calculateRankButton
            // 
            this.calculateRankButton.Location = new System.Drawing.Point(173, 526);
            this.calculateRankButton.Name = "calculateRankButton";
            this.calculateRankButton.Size = new System.Drawing.Size(140, 27);
            this.calculateRankButton.TabIndex = 79;
            this.calculateRankButton.Text = "Calculate Rank";
            this.calculateRankButton.UseVisualStyleBackColor = true;
            this.calculateRankButton.Click += new System.EventHandler(this.calculateRankButton_Click);
            // 
            // UpdateEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 740);
            this.Controls.Add(this.calculateRankButton);
            this.Controls.Add(this.manageSetButton);
            this.Controls.Add(this.managerTextBox);
            this.Controls.Add(this.managerLabel);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.employeeBankAccountBankNumTextBox);
            this.Controls.Add(this.bankAccountBranchTextBox);
            this.Controls.Add(this.employeeStatusListBox);
            this.Controls.Add(this.employeeGenderListBox);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.firstNameButton);
            this.Controls.Add(this.employeeLastNameSetBottun);
            this.Controls.Add(this.employeeSetSalaryButton);
            this.Controls.Add(this.employeePhoneNumberSet);
            this.Controls.Add(this.employeeAdressSetButton);
            this.Controls.Add(this.bankAccountSetBottun);
            this.Controls.Add(this.employeeEmailSetButton);
            this.Controls.Add(this.EmployeeForm101SetButton);
            this.Controls.Add(this.rankSetButton);
            this.Controls.Add(this.employeesRolesLIst);
            this.Controls.Add(this.employeeRankTextBox);
            this.Controls.Add(this.employeeRankLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.employeeStatusLabel);
            this.Controls.Add(this.employeeForm101Label);
            this.Controls.Add(this.EmployeePhoneNumberLabel);
            this.Controls.Add(this.employeeAdressLabel);
            this.Controls.Add(this.employeeBankAccountLabel);
            this.Controls.Add(this.employeeEmailLabel);
            this.Controls.Add(this.employeeGenderLabel);
            this.Controls.Add(this.employeeSalaryLabel1);
            this.Controls.Add(this.employeeForm101TextBox);
            this.Controls.Add(this.employeeEmailTextBox);
            this.Controls.Add(this.employeeBankNameTextBox);
            this.Controls.Add(this.employeeAdressTextBox);
            this.Controls.Add(this.EmployeePhoneNumberTextBox);
            this.Controls.Add(this.employeeSalaryTextBox);
            this.Controls.Add(this.EmployeeLasNameBox);
            this.Controls.Add(this.EmployeeLasNameLeabel);
            this.Controls.Add(this.employeeFirstNameTextBox1);
            this.Controls.Add(this.EmployeeFirstNameLabel);
            this.Controls.Add(this.employeeTypeLabel);
            this.Controls.Add(this.EmployeeIDTextBox);
            this.Controls.Add(this.EmployeeIdLabel);
            this.Name = "UpdateEmployee";
            this.Text = "UpdateEmployee";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox employeeRankTextBox;
        private System.Windows.Forms.Label employeeRankLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label employeeStatusLabel;
        private System.Windows.Forms.Label employeeForm101Label;
        private System.Windows.Forms.Label EmployeePhoneNumberLabel;
        private System.Windows.Forms.Label employeeAdressLabel;
        private System.Windows.Forms.Label employeeBankAccountLabel;
        private System.Windows.Forms.Label employeeEmailLabel;
        private System.Windows.Forms.Label employeeGenderLabel;
        private System.Windows.Forms.Label employeeSalaryLabel1;
        private System.Windows.Forms.TextBox employeeForm101TextBox;
        private System.Windows.Forms.TextBox employeeEmailTextBox;
        private System.Windows.Forms.TextBox employeeBankNameTextBox;
        private System.Windows.Forms.TextBox employeeAdressTextBox;
        private System.Windows.Forms.TextBox EmployeePhoneNumberTextBox;
        private System.Windows.Forms.TextBox employeeSalaryTextBox;
        private System.Windows.Forms.TextBox EmployeeLasNameBox;
        private System.Windows.Forms.Label EmployeeLasNameLeabel;
        private System.Windows.Forms.TextBox employeeFirstNameTextBox1;
        private System.Windows.Forms.Label EmployeeFirstNameLabel;
        private System.Windows.Forms.Label employeeTypeLabel;
        private System.Windows.Forms.TextBox EmployeeIDTextBox;
        private System.Windows.Forms.Label EmployeeIdLabel;
        private System.Windows.Forms.ListBox employeesRolesLIst;
        private System.Windows.Forms.Button rankSetButton;
        private System.Windows.Forms.Button EmployeeForm101SetButton;
        private System.Windows.Forms.Button employeeEmailSetButton;
        private System.Windows.Forms.Button bankAccountSetBottun;
        private System.Windows.Forms.Button employeeAdressSetButton;
        private System.Windows.Forms.Button employeePhoneNumberSet;
        private System.Windows.Forms.Button employeeSetSalaryButton;
        private System.Windows.Forms.Button employeeLastNameSetBottun;
        private System.Windows.Forms.Button firstNameButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ListBox employeeGenderListBox;
        private System.Windows.Forms.ListBox employeeStatusListBox;
        private System.Windows.Forms.TextBox bankAccountBranchTextBox;
        private System.Windows.Forms.TextBox employeeBankAccountBankNumTextBox;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Label managerLabel;
        private System.Windows.Forms.TextBox managerTextBox;
        private System.Windows.Forms.Button manageSetButton;
        private System.Windows.Forms.ToolTip form101ToolTip;
        private System.Windows.Forms.Button calculateRankButton;
    }
}