﻿namespace WindowsFormsApp1
{
    partial class ProjectDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.summaryTextBox = new System.Windows.Forms.TextBox();
            this.label_CreateProj__Name = new System.Windows.Forms.Label();
            this.label_CreateProj_EndTime = new System.Windows.Forms.Label();
            this.label_CreateProj_ProjectID = new System.Windows.Forms.Label();
            this.label_CreateProj_ComplexLev = new System.Windows.Forms.Label();
            this.label_CreateProj_Cost = new System.Windows.Forms.Label();
            this.label_CreateProj_SimuLoc = new System.Windows.Forms.Label();
            this.textBox_ProjectID = new System.Windows.Forms.TextBox();
            this.textBox_CreateProj_Name = new System.Windows.Forms.TextBox();
            this.textBox_CompLevel = new System.Windows.Forms.TextBox();
            this.textBox_Cost = new System.Windows.Forms.TextBox();
            this.textBox_SimuLoc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.customerIDTextBox = new System.Windows.Forms.TextBox();
            this.summaryProjectLabel = new System.Windows.Forms.Label();
            this.endTimeTextBox = new System.Windows.Forms.TextBox();
            this.managerIdLabel = new System.Windows.Forms.Label();
            this.managerIdTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // summaryTextBox
            // 
            this.summaryTextBox.Location = new System.Drawing.Point(470, 366);
            this.summaryTextBox.Name = "summaryTextBox";
            this.summaryTextBox.ReadOnly = true;
            this.summaryTextBox.Size = new System.Drawing.Size(199, 22);
            this.summaryTextBox.TabIndex = 95;
            // 
            // label_CreateProj__Name
            // 
            this.label_CreateProj__Name.AutoSize = true;
            this.label_CreateProj__Name.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj__Name.Location = new System.Drawing.Point(346, 98);
            this.label_CreateProj__Name.Name = "label_CreateProj__Name";
            this.label_CreateProj__Name.Size = new System.Drawing.Size(52, 20);
            this.label_CreateProj__Name.TabIndex = 80;
            this.label_CreateProj__Name.Text = "Name:";
            // 
            // label_CreateProj_EndTime
            // 
            this.label_CreateProj_EndTime.AutoSize = true;
            this.label_CreateProj_EndTime.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_EndTime.Location = new System.Drawing.Point(337, 149);
            this.label_CreateProj_EndTime.Name = "label_CreateProj_EndTime";
            this.label_CreateProj_EndTime.Size = new System.Drawing.Size(75, 20);
            this.label_CreateProj_EndTime.TabIndex = 81;
            this.label_CreateProj_EndTime.Text = "End Time:";
            // 
            // label_CreateProj_ProjectID
            // 
            this.label_CreateProj_ProjectID.AutoSize = true;
            this.label_CreateProj_ProjectID.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_ProjectID.Location = new System.Drawing.Point(334, 53);
            this.label_CreateProj_ProjectID.Name = "label_CreateProj_ProjectID";
            this.label_CreateProj_ProjectID.Size = new System.Drawing.Size(78, 20);
            this.label_CreateProj_ProjectID.TabIndex = 82;
            this.label_CreateProj_ProjectID.Text = "Project ID:";
            // 
            // label_CreateProj_ComplexLev
            // 
            this.label_CreateProj_ComplexLev.AutoSize = true;
            this.label_CreateProj_ComplexLev.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_ComplexLev.Location = new System.Drawing.Point(311, 190);
            this.label_CreateProj_ComplexLev.Name = "label_CreateProj_ComplexLev";
            this.label_CreateProj_ComplexLev.Size = new System.Drawing.Size(122, 20);
            this.label_CreateProj_ComplexLev.TabIndex = 83;
            this.label_CreateProj_ComplexLev.Text = "Complexity level:";
            // 
            // label_CreateProj_Cost
            // 
            this.label_CreateProj_Cost.AutoSize = true;
            this.label_CreateProj_Cost.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_Cost.Location = new System.Drawing.Point(346, 237);
            this.label_CreateProj_Cost.Name = "label_CreateProj_Cost";
            this.label_CreateProj_Cost.Size = new System.Drawing.Size(41, 20);
            this.label_CreateProj_Cost.TabIndex = 85;
            this.label_CreateProj_Cost.Text = "Cost:";
            // 
            // label_CreateProj_SimuLoc
            // 
            this.label_CreateProj_SimuLoc.AutoSize = true;
            this.label_CreateProj_SimuLoc.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_SimuLoc.Location = new System.Drawing.Point(286, 279);
            this.label_CreateProj_SimuLoc.Name = "label_CreateProj_SimuLoc";
            this.label_CreateProj_SimuLoc.Size = new System.Drawing.Size(147, 20);
            this.label_CreateProj_SimuLoc.TabIndex = 84;
            this.label_CreateProj_SimuLoc.Text = "Simulation Location:";
            // 
            // textBox_ProjectID
            // 
            this.textBox_ProjectID.Location = new System.Drawing.Point(471, 51);
            this.textBox_ProjectID.Name = "textBox_ProjectID";
            this.textBox_ProjectID.ReadOnly = true;
            this.textBox_ProjectID.Size = new System.Drawing.Size(200, 22);
            this.textBox_ProjectID.TabIndex = 86;
            // 
            // textBox_CreateProj_Name
            // 
            this.textBox_CreateProj_Name.Location = new System.Drawing.Point(471, 96);
            this.textBox_CreateProj_Name.Name = "textBox_CreateProj_Name";
            this.textBox_CreateProj_Name.ReadOnly = true;
            this.textBox_CreateProj_Name.Size = new System.Drawing.Size(200, 22);
            this.textBox_CreateProj_Name.TabIndex = 87;
            // 
            // textBox_CompLevel
            // 
            this.textBox_CompLevel.Location = new System.Drawing.Point(471, 190);
            this.textBox_CompLevel.Name = "textBox_CompLevel";
            this.textBox_CompLevel.ReadOnly = true;
            this.textBox_CompLevel.Size = new System.Drawing.Size(200, 22);
            this.textBox_CompLevel.TabIndex = 88;
            // 
            // textBox_Cost
            // 
            this.textBox_Cost.Location = new System.Drawing.Point(471, 235);
            this.textBox_Cost.Name = "textBox_Cost";
            this.textBox_Cost.ReadOnly = true;
            this.textBox_Cost.Size = new System.Drawing.Size(200, 22);
            this.textBox_Cost.TabIndex = 90;
            // 
            // textBox_SimuLoc
            // 
            this.textBox_SimuLoc.Location = new System.Drawing.Point(471, 277);
            this.textBox_SimuLoc.Name = "textBox_SimuLoc";
            this.textBox_SimuLoc.ReadOnly = true;
            this.textBox_SimuLoc.Size = new System.Drawing.Size(200, 22);
            this.textBox_SimuLoc.TabIndex = 89;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(323, 328);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 92;
            this.label1.Text = "Customer ID:";
            // 
            // customerIDTextBox
            // 
            this.customerIDTextBox.Location = new System.Drawing.Point(472, 323);
            this.customerIDTextBox.Name = "customerIDTextBox";
            this.customerIDTextBox.ReadOnly = true;
            this.customerIDTextBox.Size = new System.Drawing.Size(198, 22);
            this.customerIDTextBox.TabIndex = 93;
            // 
            // summaryProjectLabel
            // 
            this.summaryProjectLabel.AutoSize = true;
            this.summaryProjectLabel.Location = new System.Drawing.Point(327, 370);
            this.summaryProjectLabel.Name = "summaryProjectLabel";
            this.summaryProjectLabel.Size = new System.Drawing.Size(71, 17);
            this.summaryProjectLabel.TabIndex = 94;
            this.summaryProjectLabel.Text = "Summary ";
            // 
            // endTimeTextBox
            // 
            this.endTimeTextBox.Location = new System.Drawing.Point(470, 147);
            this.endTimeTextBox.Name = "endTimeTextBox";
            this.endTimeTextBox.ReadOnly = true;
            this.endTimeTextBox.Size = new System.Drawing.Size(200, 22);
            this.endTimeTextBox.TabIndex = 96;
            // 
            // managerIdLabel
            // 
            this.managerIdLabel.AutoSize = true;
            this.managerIdLabel.Location = new System.Drawing.Point(327, 403);
            this.managerIdLabel.Name = "managerIdLabel";
            this.managerIdLabel.Size = new System.Drawing.Size(89, 17);
            this.managerIdLabel.TabIndex = 97;
            this.managerIdLabel.Text = "Manager ID: ";
            // 
            // managerIdTextBox
            // 
            this.managerIdTextBox.Location = new System.Drawing.Point(470, 403);
            this.managerIdTextBox.Name = "managerIdTextBox";
            this.managerIdTextBox.ReadOnly = true;
            this.managerIdTextBox.Size = new System.Drawing.Size(199, 22);
            this.managerIdTextBox.TabIndex = 98;
            // 
            // ProjectDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 450);
            this.Controls.Add(this.managerIdTextBox);
            this.Controls.Add(this.managerIdLabel);
            this.Controls.Add(this.endTimeTextBox);
            this.Controls.Add(this.summaryTextBox);
            this.Controls.Add(this.summaryProjectLabel);
            this.Controls.Add(this.customerIDTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_SimuLoc);
            this.Controls.Add(this.textBox_Cost);
            this.Controls.Add(this.textBox_CompLevel);
            this.Controls.Add(this.textBox_CreateProj_Name);
            this.Controls.Add(this.textBox_ProjectID);
            this.Controls.Add(this.label_CreateProj_SimuLoc);
            this.Controls.Add(this.label_CreateProj_Cost);
            this.Controls.Add(this.label_CreateProj_ComplexLev);
            this.Controls.Add(this.label_CreateProj_ProjectID);
            this.Controls.Add(this.label_CreateProj_EndTime);
            this.Controls.Add(this.label_CreateProj__Name);
            this.Name = "ProjectDetails";
            this.Text = "ProjectDetails";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox summaryTextBox;
        private System.Windows.Forms.Label label_CreateProj__Name;
        private System.Windows.Forms.Label label_CreateProj_EndTime;
        private System.Windows.Forms.Label label_CreateProj_ProjectID;
        private System.Windows.Forms.Label label_CreateProj_ComplexLev;
        private System.Windows.Forms.Label label_CreateProj_Cost;
        private System.Windows.Forms.Label label_CreateProj_SimuLoc;
        private System.Windows.Forms.TextBox textBox_ProjectID;
        private System.Windows.Forms.TextBox textBox_CreateProj_Name;
        private System.Windows.Forms.TextBox textBox_CompLevel;
        private System.Windows.Forms.TextBox textBox_Cost;
        private System.Windows.Forms.TextBox textBox_SimuLoc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox customerIDTextBox;
        private System.Windows.Forms.Label summaryProjectLabel;
        private System.Windows.Forms.TextBox endTimeTextBox;
        private System.Windows.Forms.Label managerIdLabel;
        private System.Windows.Forms.TextBox managerIdTextBox;
    }
}