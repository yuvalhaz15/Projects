﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Employee
    {
        private String employeeID;
        private EType employeeType;
        private String firstName;
        private String lastName;
        private double salary;
        private DateTime hireDate;
        private String phoneNumber;
        private String adress;
        private String bankAccountNum;
        private String bankAccountBranch;
        private String bankName;
        private String email;
        private Gender gender;
        private EStatus employeeStatus;
        private String form101;
        private int rank;
        private Employee manager;
        private System.Collections.Generic.List<Meeting> createdMeetings;
        private System.Collections.Generic.List<Meeting> myMeetings;
        private System.Collections.Generic.List<Assignment> assignments;
        private System.Collections.Generic.List<WorkingRequest> requests;
        private System.Collections.Generic.List<Project> myProjects;
        private DateTime[,] monthlyWorkHours;
        public Employee(string employeeID, EType employeeType, string firstName, string lastName, double salary, DateTime hireDate, string phoneNumber, string adress, string bankName, string bankAccountNum, string bankAccountBranch, string email, Gender gender, EStatus employeeStatus, string form101, int rank, Employee manager, bool isNew)
        {
            this.employeeID = employeeID;
            this.employeeType = employeeType;
            this.firstName = firstName;
            this.lastName = lastName;
            this.salary = salary;
            this.hireDate = hireDate;
            this.phoneNumber = phoneNumber;
            this.adress = adress;
            this.bankAccountNum = bankAccountNum;
            this.bankAccountBranch = bankAccountBranch;
            this.bankName = bankName;
            this.email = email;
            this.gender = gender;
            this.employeeStatus = employeeStatus;
            this.form101 = form101;
            this.rank = rank;
            this.manager = manager;
            this.requests = new List<WorkingRequest>();
            this.myMeetings = new List<Meeting>();

            if (employeeType.ToString() == "Simulation_Developer")
                this.assignments = new List<Assignment>();
            if (employeeType.ToString() == "Project_Manager")
            {
                this.assignments = new List<Assignment>();
                this.myProjects = new List<Project>();
            }
            if (employeeType.ToString() == "Marketing_Manager")
                this.createdMeetings = new List<Meeting>();


            if (isNew)
            {
                this.create_Employee();
                Program.employees.Add(this);
            }
            if (employeeType.ToString() == "Simulation_Developer")
                this.monthlyWorkHours = new DateTime[2, 31];


        }




        public void readEmployee()
        {
            

            showEmployeeDetails();
            
            

        }
        public bool updateEmployee()
        {
            
            UpdateEmployee form = new UpdateEmployee(this);
            form.showForm();
           
            return true;
         }
            

        public void update(string employeeID, EType employeeType, string firstName, string lastName, double salary, DateTime hireDate, string phoneNumber, string adress, string bankAccountNum, string bankAccountBranch, string bankName, string email, Gender gender, EStatus employeeStatus, string form101, int rank,Employee manager)
        {

            this.setId(employeeID);
            this.setEmployeeType(employeeType);
            this.setFirstName(firstName);
            this.setLastName(lastName);
            this.setSalary(salary);
            this.setHireDate(hireDate);
            this.setPhoneNumber(phoneNumber);
            this.setAdress(adress);
            this.setBankAccountBranch(bankAccountBranch);
            this.setBankName(bankName);
            this.setBankAccountNum(bankAccountNum);
            this.setEmail(email);
            this.setGender(gender);
            this.setEmployeeStatus(employeeStatus);
            this.setForm101(form101);
            this.setRank(rank);
            this.setManager(this.manager);
            update_Employee();
        }
        public void setManager(Employee manager)
        {
            this.manager = manager;

        }
        public Employee getManager()
        {
            return this.manager;

        }
        

        private void showEmployeeDetails()
        {
            EmployeeDetails form = new EmployeeDetails(this);
            form.showForm();
        }

      

    
        public string getId()
        {
            return this.employeeID;
        }
        public void setId(String id)
        {
            this.employeeID = id;
        }
        public EType getEmployeeType()
        {
            return this.employeeType;

        }
        public void setEmployeeType(EType type)
        {
            this.employeeType = type;
        }
        public String getFirstName()
        {
            return this.firstName;

        }
        public void setFirstName(String name)
        {
            this.firstName = name;
        }
        public String getLastName()
        {
            return this.lastName;

        }
        public void setLastName(String name)
        {
            this.lastName = name;
        }
        public double getSalary()
        {
            return this.salary;
        }
        public void setSalary(Double salary)
        {
            this.salary = salary;

        }

        public DateTime getHireDate()
        {
            return this.hireDate;
        }
        public void setHireDate(DateTime hireDate)
        {
            this.hireDate = hireDate;

        }
        public String getPhoneNumber()
        {
            return this.phoneNumber;

        }

        public void setPhoneNumber(String phoneNumber)
        {
            this.phoneNumber = phoneNumber;
        }
        public String getAdress()
        {
            return this.adress;
        }
        public void setAdress(String adress)
        {
            this.adress = adress;

        }
        public String getBankAccountNum()
        {
            return this.bankAccountNum;
        }
        public void setBankAccountNum(String bankAccountNum)
        {
            this.bankAccountNum = bankAccountNum;
        }
        public String getBankAccountBranch()
        {
            return this.bankAccountBranch;
        }
        public void setBankAccountBranch(String bankAccountBranch)
        {
            this.bankAccountBranch = bankAccountBranch;
        }
        public String getBankName()
        {
            return this.bankName;
        }
        public void setBankName(String bankName)
        {
            this.bankName = bankName;
        }





        public String getEmail()
        {
            return this.email;

        }
        public void setEmail(String email)
        {
            this.email = email;
        }
        public Gender getGender()
        {
            return this.gender;
        }
        public void setGender(Gender gender)
        {
            this.gender = gender;
        }
        public EStatus getEmployeeStatus()
        {
            return this.employeeStatus;
        }
        public void setEmployeeStatus(EStatus status)
        {
            this.employeeStatus = status;
        }


        public String getform101()
        {
            return this.form101;

        }
        public void setForm101(String form)
        {
            this.form101 = form;

        }
        public int getRank()
        {
            return this.rank;

        }
        public void setRank(int rank)
        {
            this.rank = rank;
        }


        public DateTime[,] getMonthlyWorkHours()
        {
            return this.monthlyWorkHours;
        }

        public void setMonthlyWorkHours(DateTime[,] table)
        {
            this.monthlyWorkHours = table;

        }
        public void create_Employee()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_employee @employeeID , @employeeType,@firstName , @lastName,@salary ,@hireDate ,@phoneNumber ,@adress ,@bankName  ,@bankAccountNum,@bankAccountBrench,@email  ,@gender,@employeeStatus,@form101 ,@rank,@manager";
            c.Parameters.AddWithValue("@employeeID", this.employeeID);
            c.Parameters.AddWithValue("@employeeType", this.employeeType.ToString());
            c.Parameters.AddWithValue("@firstName", this.firstName);
            c.Parameters.AddWithValue("@lastName", this.lastName);
            c.Parameters.AddWithValue("@salary", this.salary);
            c.Parameters.AddWithValue("@hireDate", this.hireDate);
            c.Parameters.AddWithValue("@phoneNumber ", this.phoneNumber);
            c.Parameters.AddWithValue("@adress", this.adress);
            c.Parameters.AddWithValue("@bankName", this.bankName);
            c.Parameters.AddWithValue("@bankAccountNum", this.bankAccountNum);
            c.Parameters.AddWithValue("@bankAccountBrench", this.bankAccountBranch);
            c.Parameters.AddWithValue("@email", this.email);
            c.Parameters.AddWithValue("@gender", this.gender.ToString());
            c.Parameters.AddWithValue("@employeeStatus", this.employeeStatus.ToString());
            c.Parameters.AddWithValue("@form101", this.form101);
            c.Parameters.AddWithValue("@rank", this.rank);
            c.Parameters.AddWithValue("@manager", this.manager.getId());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);

        }
        public void update_Employee()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_Update_employee @employeeID , @employeeType,@firstName , @lastName,@salary ,@hireDate ,@phoneNumber ,@adress ,@bankName  ,@bankAccountNum,@bankAccountBrench,@email  ,@gender,@employeeStatus,@form101 ,@rank,@manager";
            c.Parameters.AddWithValue("@employeeID", this.employeeID);
            c.Parameters.AddWithValue("@employeeType", this.employeeType.ToString());
            c.Parameters.AddWithValue("@firstName", this.firstName);
            c.Parameters.AddWithValue("@lastName", this.lastName);
            c.Parameters.AddWithValue("@salary", this.salary);
            c.Parameters.AddWithValue("@hireDate", this.hireDate);
            c.Parameters.AddWithValue("@phoneNumber ", this.phoneNumber);
            c.Parameters.AddWithValue("@adress", this.adress);
            c.Parameters.AddWithValue("@bankName", this.bankName);
            c.Parameters.AddWithValue("@bankAccountNum", this.bankAccountNum);
            c.Parameters.AddWithValue("@bankAccountBrench", this.bankAccountBranch);
            c.Parameters.AddWithValue("@email", this.email);
            c.Parameters.AddWithValue("@gender", this.gender.ToString());
            c.Parameters.AddWithValue("@employeeStatus", this.employeeStatus.ToString());
            c.Parameters.AddWithValue("@form101", this.form101);
            c.Parameters.AddWithValue("@rank", this.rank);
            c.Parameters.AddWithValue("@manager", this.manager.getId());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);

        }
        public List<Project> getProjects()
        {
            return this.myProjects;
        }
        public List<Meeting> getCreatedMeetings()
        {
            return this.createdMeetings;
        }
        public List<Meeting> getMyMeetings()
        {
            return this.myMeetings;
        }
        public List<Assignment> getAssignments()
        {
            return this.assignments;
        }
        public List<WorkingRequest> getRequests()
        {
            return this.requests;
        }



        public static int getTotalRank()
        {
            int total = 0;
            foreach (Employee e in Program.employees)
            {
                if (e.getEmployeeType().ToString() == "Simulation_Developer")
                {
                    total += e.calculateRank();
                }

            }
            return total;
        }

        public static int calculateNumOfDevelopers()
        {
            int counter = 0;
            foreach (Employee e in Program.employees)
            {
                if (e.getEmployeeType().ToString() == "Simulation_Developer")
                    counter++;
            }
            return counter;
        }

        public int calculateRank()
        {
            int numOfProjects = this.numOfProjects();
            if (daysOfWork() <= 60)
                return 0;
            if (daysOfWork() < 210 && numOfProjects <= 1)
                return 1;
            if (daysOfWork() < 390 || numOfProjects > 1)
                return 2;
            if (daysOfWork() < 750 || numOfProjects > 3)
                return 3;
            if (daysOfWork() < 1000 || numOfProjects > 5)
                return 4;
            return 5;
        }

        private Double daysOfWork()
        {
            TimeSpan diffResult = DateTime.Today.Subtract(hireDate);
            Double d = diffResult.TotalDays;
            return d;
        }

        public int numOfProjects()
        {
            System.Collections.Generic.HashSet<Project> pCounter = new HashSet<Project>();
            foreach (Assignment a in assignments)
                pCounter.Add(a.getProject());
            return pCounter.Count;
        }


        public void enterToWork(DateTime enterTime)
        {
            monthlyWorkHours[0, DateTime.Today.Day] = enterTime;
        }
        public void exitFromWork(DateTime exitTime)
        {
            monthlyWorkHours[1, DateTime.Today.Day] = exitTime;
        }



    }




}
