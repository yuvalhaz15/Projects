﻿namespace WindowsFormsApp1
{
    partial class CEOForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeesButton = new System.Windows.Forms.Button();
            this.Label_CEOWel_Hello = new System.Windows.Forms.Label();
            this.btn_CEO_ProjMang = new System.Windows.Forms.Button();
            this.btn_CEO_CustomerMang = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EmployeesButton
            // 
            this.EmployeesButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeesButton.Location = new System.Drawing.Point(51, 231);
            this.EmployeesButton.Name = "EmployeesButton";
            this.EmployeesButton.Size = new System.Drawing.Size(251, 42);
            this.EmployeesButton.TabIndex = 0;
            this.EmployeesButton.Text = "Employees Management";
            this.EmployeesButton.UseVisualStyleBackColor = true;
            this.EmployeesButton.Click += new System.EventHandler(this.EmployeesButton_Click);
            // 
            // Label_CEOWel_Hello
            // 
            this.Label_CEOWel_Hello.AutoSize = true;
            this.Label_CEOWel_Hello.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CEOWel_Hello.Location = new System.Drawing.Point(73, 87);
            this.Label_CEOWel_Hello.Name = "Label_CEOWel_Hello";
            this.Label_CEOWel_Hello.Size = new System.Drawing.Size(389, 31);
            this.Label_CEOWel_Hello.TabIndex = 10;
            this.Label_CEOWel_Hello.Text = "Hello ! Please choose an action ..";
            // 
            // btn_CEO_ProjMang
            // 
            this.btn_CEO_ProjMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CEO_ProjMang.Location = new System.Drawing.Point(355, 231);
            this.btn_CEO_ProjMang.Name = "btn_CEO_ProjMang";
            this.btn_CEO_ProjMang.Size = new System.Drawing.Size(251, 42);
            this.btn_CEO_ProjMang.TabIndex = 12;
            this.btn_CEO_ProjMang.Text = "Project Management";
            this.btn_CEO_ProjMang.UseVisualStyleBackColor = true;
            this.btn_CEO_ProjMang.Click += new System.EventHandler(this.btn_CEO_ProjMang_Click);
            // 
            // btn_CEO_CustomerMang
            // 
            this.btn_CEO_CustomerMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CEO_CustomerMang.Location = new System.Drawing.Point(667, 231);
            this.btn_CEO_CustomerMang.Name = "btn_CEO_CustomerMang";
            this.btn_CEO_CustomerMang.Size = new System.Drawing.Size(241, 42);
            this.btn_CEO_CustomerMang.TabIndex = 13;
            this.btn_CEO_CustomerMang.Text = "Customer managment";
            this.btn_CEO_CustomerMang.UseVisualStyleBackColor = true;
            this.btn_CEO_CustomerMang.Click += new System.EventHandler(this.btn_CEO_CustomerMang_Click);
            // 
            // CEOForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 540);
            this.Controls.Add(this.btn_CEO_CustomerMang);
            this.Controls.Add(this.btn_CEO_ProjMang);
            this.Controls.Add(this.Label_CEOWel_Hello);
            this.Controls.Add(this.EmployeesButton);
            this.Name = "CEOForm";
            this.Text = "CEOForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EmployeesButton;
        private System.Windows.Forms.Label Label_CEOWel_Hello;
        private System.Windows.Forms.Button btn_CEO_ProjMang;
        private System.Windows.Forms.Button btn_CEO_CustomerMang;
    }
}