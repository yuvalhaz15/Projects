﻿namespace WindowsFormsApp1
{
    partial class ApproveWorkingRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextBox_WorkReq_RequestNum = new System.Windows.Forms.TextBox();
            this.label_WorkReq_RequestNum = new System.Windows.Forms.Label();
            this.textBoxNote = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Label_WorkReq_Purpose = new System.Windows.Forms.Label();
            this.Label_WorkReq_EndDate = new System.Windows.Forms.Label();
            this.Label_WorkReq_StartDate = new System.Windows.Forms.Label();
            this.Label_WorkReq = new System.Windows.Forms.Label();
            this.EndDateTextBox = new System.Windows.Forms.TextBox();
            this.StartDateTextBox = new System.Windows.Forms.TextBox();
            this.textBoxPurpose = new System.Windows.Forms.TextBox();
            this.btn_Approve = new System.Windows.Forms.Button();
            this.btn_NotApprove = new System.Windows.Forms.Button();
            this.btn_WorkReq_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TextBox_WorkReq_RequestNum
            // 
            this.TextBox_WorkReq_RequestNum.Location = new System.Drawing.Point(348, 110);
            this.TextBox_WorkReq_RequestNum.Margin = new System.Windows.Forms.Padding(2);
            this.TextBox_WorkReq_RequestNum.Name = "TextBox_WorkReq_RequestNum";
            this.TextBox_WorkReq_RequestNum.ReadOnly = true;
            this.TextBox_WorkReq_RequestNum.Size = new System.Drawing.Size(151, 20);
            this.TextBox_WorkReq_RequestNum.TabIndex = 83;
            // 
            // label_WorkReq_RequestNum
            // 
            this.label_WorkReq_RequestNum.AutoSize = true;
            this.label_WorkReq_RequestNum.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_WorkReq_RequestNum.Location = new System.Drawing.Point(264, 111);
            this.label_WorkReq_RequestNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_WorkReq_RequestNum.Name = "label_WorkReq_RequestNum";
            this.label_WorkReq_RequestNum.Size = new System.Drawing.Size(79, 16);
            this.label_WorkReq_RequestNum.TabIndex = 82;
            this.label_WorkReq_RequestNum.Text = "Request Num";
            // 
            // textBoxNote
            // 
            this.textBoxNote.Location = new System.Drawing.Point(348, 260);
            this.textBoxNote.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxNote.Name = "textBoxNote";
            this.textBoxNote.ReadOnly = true;
            this.textBoxNote.Size = new System.Drawing.Size(151, 82);
            this.textBoxNote.TabIndex = 81;
            this.textBoxNote.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(226, 261);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 76;
            this.label1.Text = "Additional Comment";
            // 
            // Label_WorkReq_Purpose
            // 
            this.Label_WorkReq_Purpose.AutoSize = true;
            this.Label_WorkReq_Purpose.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq_Purpose.Location = new System.Drawing.Point(291, 223);
            this.Label_WorkReq_Purpose.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_WorkReq_Purpose.Name = "Label_WorkReq_Purpose";
            this.Label_WorkReq_Purpose.Size = new System.Drawing.Size(51, 16);
            this.Label_WorkReq_Purpose.TabIndex = 77;
            this.Label_WorkReq_Purpose.Text = "Purpose";
            // 
            // Label_WorkReq_EndDate
            // 
            this.Label_WorkReq_EndDate.AutoSize = true;
            this.Label_WorkReq_EndDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq_EndDate.Location = new System.Drawing.Point(285, 183);
            this.Label_WorkReq_EndDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_WorkReq_EndDate.Name = "Label_WorkReq_EndDate";
            this.Label_WorkReq_EndDate.Size = new System.Drawing.Size(55, 16);
            this.Label_WorkReq_EndDate.TabIndex = 78;
            this.Label_WorkReq_EndDate.Text = "End Date";
            // 
            // Label_WorkReq_StartDate
            // 
            this.Label_WorkReq_StartDate.AutoSize = true;
            this.Label_WorkReq_StartDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq_StartDate.Location = new System.Drawing.Point(282, 147);
            this.Label_WorkReq_StartDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_WorkReq_StartDate.Name = "Label_WorkReq_StartDate";
            this.Label_WorkReq_StartDate.Size = new System.Drawing.Size(59, 16);
            this.Label_WorkReq_StartDate.TabIndex = 75;
            this.Label_WorkReq_StartDate.Text = "Start Date";
            // 
            // Label_WorkReq
            // 
            this.Label_WorkReq.AutoSize = true;
            this.Label_WorkReq.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq.Location = new System.Drawing.Point(343, 58);
            this.Label_WorkReq.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_WorkReq.Name = "Label_WorkReq";
            this.Label_WorkReq.Size = new System.Drawing.Size(170, 30);
            this.Label_WorkReq.TabIndex = 74;
            this.Label_WorkReq.Text = "Work Request";
            // 
            // EndDateTextBox
            // 
            this.EndDateTextBox.Location = new System.Drawing.Point(348, 183);
            this.EndDateTextBox.Name = "EndDateTextBox";
            this.EndDateTextBox.ReadOnly = true;
            this.EndDateTextBox.Size = new System.Drawing.Size(151, 20);
            this.EndDateTextBox.TabIndex = 85;
            // 
            // StartDateTextBox
            // 
            this.StartDateTextBox.Location = new System.Drawing.Point(348, 147);
            this.StartDateTextBox.Name = "StartDateTextBox";
            this.StartDateTextBox.ReadOnly = true;
            this.StartDateTextBox.Size = new System.Drawing.Size(151, 20);
            this.StartDateTextBox.TabIndex = 85;
            // 
            // textBoxPurpose
            // 
            this.textBoxPurpose.Location = new System.Drawing.Point(348, 221);
            this.textBoxPurpose.Name = "textBoxPurpose";
            this.textBoxPurpose.ReadOnly = true;
            this.textBoxPurpose.Size = new System.Drawing.Size(151, 20);
            this.textBoxPurpose.TabIndex = 86;
            // 
            // btn_Approve
            // 
            this.btn_Approve.Location = new System.Drawing.Point(288, 383);
            this.btn_Approve.Name = "btn_Approve";
            this.btn_Approve.Size = new System.Drawing.Size(75, 23);
            this.btn_Approve.TabIndex = 87;
            this.btn_Approve.Text = "Approve";
            this.btn_Approve.UseVisualStyleBackColor = true;
            this.btn_Approve.Click += new System.EventHandler(this.btn_Approve_Click);
            // 
            // btn_NotApprove
            // 
            this.btn_NotApprove.Location = new System.Drawing.Point(487, 383);
            this.btn_NotApprove.Name = "btn_NotApprove";
            this.btn_NotApprove.Size = new System.Drawing.Size(82, 23);
            this.btn_NotApprove.TabIndex = 87;
            this.btn_NotApprove.Text = "Not Approve";
            this.btn_NotApprove.UseVisualStyleBackColor = true;
            this.btn_NotApprove.Click += new System.EventHandler(this.btn_NotApprove_Click);
            // 
            // btn_WorkReq_Back
            // 
            this.btn_WorkReq_Back.Location = new System.Drawing.Point(691, 415);
            this.btn_WorkReq_Back.Name = "btn_WorkReq_Back";
            this.btn_WorkReq_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_WorkReq_Back.TabIndex = 88;
            this.btn_WorkReq_Back.Text = "back";
            this.btn_WorkReq_Back.UseVisualStyleBackColor = true;
            this.btn_WorkReq_Back.Click += new System.EventHandler(this.btn_WorkReq_Back_Click);
            // 
            // ApproveWorkingRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_WorkReq_Back);
            this.Controls.Add(this.btn_NotApprove);
            this.Controls.Add(this.btn_Approve);
            this.Controls.Add(this.textBoxPurpose);
            this.Controls.Add(this.StartDateTextBox);
            this.Controls.Add(this.EndDateTextBox);
            this.Controls.Add(this.TextBox_WorkReq_RequestNum);
            this.Controls.Add(this.label_WorkReq_RequestNum);
            this.Controls.Add(this.textBoxNote);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Label_WorkReq_Purpose);
            this.Controls.Add(this.Label_WorkReq_EndDate);
            this.Controls.Add(this.Label_WorkReq_StartDate);
            this.Controls.Add(this.Label_WorkReq);
            this.Name = "ApproveWorkingRequest";
            this.Text = "ApproveWorkingRequest";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TextBox_WorkReq_RequestNum;
        private System.Windows.Forms.Label label_WorkReq_RequestNum;
        private System.Windows.Forms.RichTextBox textBoxNote;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Label_WorkReq_Purpose;
        private System.Windows.Forms.Label Label_WorkReq_EndDate;
        private System.Windows.Forms.Label Label_WorkReq_StartDate;
        private System.Windows.Forms.Label Label_WorkReq;
        private System.Windows.Forms.TextBox EndDateTextBox;
        private System.Windows.Forms.TextBox StartDateTextBox;
        private System.Windows.Forms.TextBox textBoxPurpose;
        private System.Windows.Forms.Button btn_Approve;
        private System.Windows.Forms.Button btn_NotApprove;
        private System.Windows.Forms.Button btn_WorkReq_Back;
    }
}