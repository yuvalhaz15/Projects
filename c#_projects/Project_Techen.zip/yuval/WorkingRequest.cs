﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    
        public class WorkingRequest
        {
            private Employee requestedBy;
            private Employee approvedBy;
            private string requestNum;
            private DateTime startDate;
            private DateTime endDate;
            private WorkingRequestEnumPurpose purpose;
            private string additionalComment;
            private RequestStatusEnum status;

            public WorkingRequest(Employee requestedBy, Employee approvedBy, String requestNum, DateTime startDate, DateTime endDate, WorkingRequestEnumPurpose purpose, string additionalComment, RequestStatusEnum status, bool isNew)
            {
                this.requestedBy = requestedBy;
                this.approvedBy = approvedBy;
                this.requestNum = requestNum;
                this.startDate = startDate;
                this.endDate = endDate;
                this.purpose = purpose;
                this.additionalComment = additionalComment;
                this.status = status;
                this.requestedBy.getRequests().Add(this);
                this.approvedBy.getRequests().Add(this);
                if (isNew)
                {
                    createWorkingRequest();
                    Program.workingRequests.Add(this);

                }
            }
        private void createWorkingRequest()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_workingRequest @requestedBy, @approvedBy, @requestNumber, @startDate, @endDate, @purpuse, @aditionalComment, @status";
            c.Parameters.AddWithValue("@requestedBy", this.requestedBy.getId());
            c.Parameters.AddWithValue("@approvedBy", this.approvedBy.getId());
            c.Parameters.AddWithValue("@requestNumber", this.requestNum);
            c.Parameters.AddWithValue("@startDate", this.startDate);
            c.Parameters.AddWithValue("@endDate", this.endDate);
            c.Parameters.AddWithValue("@purpuse", this.purpose.ToString());
            c.Parameters.AddWithValue("@aditionalComment", this.additionalComment);
            c.Parameters.AddWithValue("@status", this.status.ToString());
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }
        public void setRequestNum(string requestNum) {
            this.requestNum = requestNum;

        }
        public string getRequestNum() {
            return this.requestNum;

        }
        public void setStartDate(DateTime startDate)
        {
            this.startDate = startDate;

        }
        public DateTime getStartDate()
        {
            return this.startDate;
        }
        public WorkingRequestEnumPurpose get_purpose()
        {
            return this.purpose;
        }
        public void set_purpose(WorkingRequestEnumPurpose purpose)
        {
            this.purpose = purpose;
        }

        public void set_additionalComment(String additionalComment)
        {
            this.additionalComment = additionalComment;
        }
        public String get_additionalComment()
        {
            return this.additionalComment;
        }
        public void set_RequestStatusEnum(RequestStatusEnum status)
        {
            this.status = status;
        }
        public RequestStatusEnum get_RequestStatusEnum()
        {
            return this.status;
        }
        public void setRequestedBy(Employee requsted) {

            this.requestedBy = requsted;
        }
        public Employee getRequestedBy()
        {
            return this.requestedBy;


        }
        public void setApprovedBy(Employee approved)
        {

            this.approvedBy = approved;
        }
        public Employee getApprovedBy()
        {
            return this.approvedBy;


        }
        public void setEndDate(DateTime endDate)
        {
            this.endDate = endDate;


        }
        public DateTime getEndDate()
        {


            return this.endDate;
        }





    }
}
