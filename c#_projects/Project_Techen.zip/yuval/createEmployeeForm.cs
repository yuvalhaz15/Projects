﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class createEmployeeForm : Form
    {
        private String employeeID;
        private EType employeeType;
        private String firstName;
        private String lastName;
        private double salary;
        private DateTime hireDate;
        private String phoneNumber;
        private String adress;
        private String bankAccountNum;
        private String bankAccountBranch;
        private String bankName;
        private String email;
        private Gender gender;
        private EStatus employeeStatus;
        private String form101;
        private int rank;
        private Employee manager;

        public createEmployeeForm()
        {
            InitializeComponent();

        }
        public void showForm()
        {
            this.initializeData();
            this.Show();

        }
        private void initializeData()
        {
            setEmployeeTypeTextBox();
            setGenderTextBox();
            setEmployeeStatusTextBox();








        }





        private void setEmployeeStatusTextBox()
        {


            addAllEmployeesStaus();
        }


        private void setGenderTextBox()
        {


            addAllGendersToList();

        }

       



        private void setEmployeeTypeTextBox()
        {


            addAllEmployeesTypes();
        }
        private bool allNumbers(string toCheck)
        {
            for (int i = 0; i < toCheck.Length; i++)

                if (toCheck[i] < '0' || toCheck[i] > '9')
                    return false;

            return true;
        }
        private void addAllEmployeesTypes()
        {
            this.employeesRolesLIst.Items.Add(EType.CEO);
            this.employeesRolesLIst.Items.Add(EType.Marketing_Manager);
            this.employeesRolesLIst.Items.Add(EType.Project_Manager);
            this.employeesRolesLIst.Items.Add(EType.Simulation_Developer);

        }
        private void addAllGendersToList()
        {
            this.employeeGenderListBox.Items.Add(Gender.Female);
            this.employeeGenderListBox.Items.Add(Gender.Male);
            this.employeeGenderListBox.Items.Add(Gender.Other);
        }
        private void addAllEmployeesStaus()
        {
            this.employeeStatusListBox.Items.Add(EStatus.Current);
            this.employeeStatusListBox.Items.Add(EStatus.In_learning);
            this.employeeStatusListBox.Items.Add(EStatus.Past);

        }

        private void employeesRolesLIst_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.employeeType = matchStringToEnumEmployeeType(this.employeesRolesLIst.SelectedItem.ToString());
            MessageBox.Show("you change employee role to " + this.employeeType);

        }

        private EType matchStringToEnumEmployeeType(string type)
        {
            switch (type)
            {
                case "CEO":
                    return EType.CEO;


                case "Project_Manager":
                    return EType.Project_Manager;

                case "Simulation_Developer":
                    return EType.Simulation_Developer;

                case "Marketing_Manager":
                    return EType.Marketing_Manager;



            }
            return EType.Simulation_Developer;
        }

        private bool nameIsValid(string name)
        {

            return allLetters(name) && name.Length > 0 && name.Length < 20;
        }

        private bool allLetters(string name)
        {
            for (int i = 0; i < name.Length; i++)

                if ((name[i] < 'a' || name[i] > 'z') && name[i] != ' ')
                    if ((name[i] < 'A' || name[i] > 'Z'))
                        return false;

            return true;
        }



        private void firstNameButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(employeeFirstNameTextBox1.Text))
            {
                this.firstName = employeeFirstNameTextBox1.Text;
                MessageBox.Show("first name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                employeeFirstNameTextBox1.Text = "";

            }
        }

        private void employeeLastNameSetBottun_Click(object sender, EventArgs e)
        {
            if (nameIsValid(EmployeeLasNameBox.Text))
            {
                this.lastName = EmployeeLasNameBox.Text;
                MessageBox.Show("Last name was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                EmployeeLasNameBox.Text = "";
            }
        }

        private void employeeSetSalaryButton_Click(object sender, EventArgs e)
        {
            if (validDoubleAsString(employeeSalaryTextBox.Text))
            {
                if (salaryIsValid(Double.Parse(employeeSalaryTextBox.Text)))
                {
                    this.salary = Double.Parse(employeeSalaryTextBox.Text);
                    MessageBox.Show("salary was changed successfully");

                }
                else
                {
                    MessageBox.Show("Error!! Salary amount is to low ");
                    employeeSalaryTextBox.Text = "";
                }
            }

            else
            {
                MessageBox.Show("Error!! Salary characters are unvalid ");
                employeeSalaryTextBox.Text = "";
            }
        }

        private bool validDoubleAsString(string text)
        {
            Boolean dotWasFound = false;
            if (text[0] < '0' || text[0] > '9')
                return false;
            for (int i = 1; i < text.Length; i++)
            {
                if (text[i] == '.')
                    if (dotWasFound)
                        return true;
                    else
                        return dotWasFound = true; ;
                if (text[i] < '0' || text[i] > '9')
                    return false;
            }
            return true;
        }

        private bool salaryIsValid(double salary)
        {
            return salary > 45;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value <= DateTime.Now)
                this.hireDate = dateTimePicker1.Value;
            else
                MessageBox.Show("Error!! The date must be smaller from the current date ");

        }

        private void employeePhoneNumberSet_Click(object sender, EventArgs e)
        {
            if (phoneNumberIsValid())
            {
                this.phoneNumber = EmployeePhoneNumberTextBox.Text;
                MessageBox.Show("phone number was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! The phone number must contain only numbers and must contain 10 digits ");
                EmployeePhoneNumberTextBox.Text = "";
            }
        }

        private bool phoneNumberIsValid()
        {
            return allNumbers(EmployeePhoneNumberTextBox.Text) && EmployeePhoneNumberTextBox.Text.Length == 10;
        }

        private void employeeAdressSetButton_Click(object sender, EventArgs e)
        {
            if (employeeAdressTextBox.Text.Length <= 50)
            {
                this.adress = employeeAdressTextBox.Text;
                MessageBox.Show("adress was changed successfully");

            }
            else
            {


                MessageBox.Show("Error!! adress is to long must be 50 characters");
                employeeAdressTextBox.Text = "";
            }

        }

        private void employeeEmailSetButton_Click(object sender, EventArgs e)
        {
            if (emailIsValid(employeeEmailTextBox.Text))
            {
                this.email = employeeEmailTextBox.Text;
                MessageBox.Show("email was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! Email adress is not valid ");
                employeeEmailTextBox.Text = "";
            }

        }

        private bool emailIsValid(string email)
        {
            Regex rx = new Regex(
        @"^[-!#$%&'*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+/0-9=?A-Z^_a-z{|}~])*@[a-zA-Z](-?[a-zA-Z0-9])*(\.[a-zA-Z](-?[a-zA-Z0-9])*)+$");
            return rx.IsMatch(email) && email.Length <= 50;
        }

        private void employeeGenderListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            this.gender = matchStringToEnumGender(employeeGenderListBox.SelectedItem.ToString());
            MessageBox.Show("The gender is : " + employeeGenderListBox.SelectedItem.ToString());
        }

        private Gender matchStringToEnumGender(string gender)
        {
            switch (gender)
            {
                case "Female":
                    return Gender.Female;


                case "Male":
                    return Gender.Male;

                case "Other":
                    return Gender.Other;




            }
            return Gender.Other;
        }

        private void employeeStatusListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.employeeStatus = matchStringToEnumEmployeeStatus(employeeStatusListBox.SelectedItem.ToString());
            MessageBox.Show("The status is : " + employeeStatusListBox.SelectedItem.ToString());
        }

        private EStatus matchStringToEnumEmployeeStatus(string status)
        {
            switch (status)
            {
                case "Current":
                    return EStatus.Current;


                case "Past":
                    return EStatus.Past;

                case "In_learnin":
                    return EStatus.In_learning;




            }
            return EStatus.Current;
        }



        private void EmployeeForm101SetButton_Click(object sender, EventArgs e)
        {
            if (form101IsValid(this.employeeForm101TextBox.Text))
            {
                this.form101 = this.employeeForm101TextBox.Text;
                MessageBox.Show("form101 was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! URL adress is unvalid");
                this.employeeForm101TextBox.Text = "";
            }
        }
        private bool form101IsValid(string form101)
        {
            if (form101.Length > 200 || form101.Length < 10)
                return false;
            if (form101.Substring(0, 8).Equals("https://") == false)
                return false;
            return true;

        }

        private void bankAccountSetBottun_Click(object sender, EventArgs e)
        {
            if (bankAccountNumIsValid() && bankAccountBranchIsValid() & bankNameIsValid())
            {
                setBankAccountDetails();
                MessageBox.Show("bank account was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!!  one or more details of bank account are un valid ");
                employeeBankNameTextBox.Text = "";
                bankAccountBranchTextBox.Text = "";
                employeeBankAccountBankNumTextBox.Text = "";
            }


        }

        private void setBankAccountDetails()
        {
            this.bankAccountNum = this.employeeBankAccountBankNumTextBox.Text;
            this.bankAccountBranch = this.bankAccountBranchTextBox.Text;
            this.bankName = employeeBankNameTextBox.Text;


        }

        private bool bankNameIsValid()
        {
            return this.employeeBankNameTextBox.Text.Length > 0 && allLetters(this.employeeBankNameTextBox.Text);
        }

        private bool bankAccountBranchIsValid()
        {
            return this.bankAccountBranchTextBox.Text.Length > 0 && this.bankAccountBranchTextBox.Text.Length <= 3 && allNumbers(this.bankAccountBranchTextBox.Text);
        }

        private bool bankAccountNumIsValid()
        {
            return this.employeeBankAccountBankNumTextBox.Text.Length > 0 && this.employeeBankAccountBankNumTextBox.Text.Length <= 10 && allNumbers(this.employeeBankAccountBankNumTextBox.Text);
        }



        private void manageSetButton_Click(object sender, EventArgs e)
        {
            if (managerIdIValid())
            {
                this.manager = seekEmployee(this.managerTextBox.Text);
                MessageBox.Show("manager was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!!  manager was not found ");
                this.managerTextBox.Text = "";
            }

        }


        private bool managerIdIValid()
        {
            return this.managerTextBox.Text.Length > 0 && allNumbers(this.managerTextBox.Text) && idIsBelongToManager(this.managerTextBox.Text);
        }

        private bool idIsBelongToManager(String id)
        {
            if (seekEmployee(id) == null)
                return false;
            return seekEmployee(id).getEmployeeType().ToString() == "CEO" || seekEmployee(id).getEmployeeType().ToString() == "Project_Manager";
        }

        private Employee seekEmployee(string id)
        {

            foreach (Employee e in Program.employees)
            {
                if (e.getId() == id)
                    return e;
            }
            return null;
        }


        private void form101ToolTip_Popup(object sender, PopupEventArgs e)
        {
            MessageBox.Show("The address must start with https://");
        }

        


        private void createButton_Click(object sender, EventArgs e)
        {
            if (allFieldsWasInit())
            {
                Employee em = new Employee(this.employeeID, this.employeeType, this.firstName, this.lastName, this.salary, this.hireDate, this.phoneNumber, this.adress, this.bankAccountNum, this.bankAccountBranch, this.bankName, this.email, this.gender, this.employeeStatus, this.form101, 0, this.manager,true);
                MessageBox.Show("Employee was added sucsessfully ");
            }
            else
            {

                MessageBox.Show("One or more field are missing ");
            }






        }


        private bool allFieldsWasInit()
        {
            return this.employeeID != null && firstName != null&& lastName != null
        && salary != 0
        && hireDate != null
        && phoneNumber != null
         && adress != null
         && bankAccountNum != null
         && bankAccountBranch != null
       && bankName != null
       && email != null
       && form101 != null
       && manager != null;
        }
       

        private void employeeIdSetButton_Click(object sender, EventArgs e)
        {
            if (idIsValid(this.EmployeeIDTextBox.Text))
            {
                this.employeeID = this.EmployeeIDTextBox.Text;
                MessageBox.Show("ID was changed succsessfully");
            }
            else
            {
                MessageBox.Show("Error!! Id is unvalid");
                this.EmployeeIDTextBox.Text="";

            }
        }



        

        private bool idIsValid(string idToCheck)
        {
            return idToCheck.Length > 0 && idToCheck.Length <= 10 && !idExist(idToCheck) && allNumbers(idToCheck);
        }

        private bool idExist(String idToCheck)
        {
            if (Program.employees == null)
                return false;
            foreach (Employee e in Program.employees)
                if (idToCheck == e.getId())
                    return true;

            return false;
        }
    }



}

