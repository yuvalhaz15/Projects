﻿namespace WindowsFormsApp1
{
   public enum EType
    {
        Simulation_Developer,
        Project_Manager,
        CEO,
        Marketing_Manager


    }
}