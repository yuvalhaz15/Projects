﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ProjectManagementForm : Form
    {
        public ProjectManagementForm()
        {
            InitializeComponent();
        }

        private void btn_CustomerCRU_NewProject_Click(object sender, EventArgs e)
        {
            CreateProject createProject = new CreateProject();
            
            createProject.ShowDialog();
            
        }

        private void btn_ProjectCRU_ExistingProj_Click(object sender, EventArgs e)
        {
            ProjectManageExitstingForm projectManageExitstingForm = new ProjectManageExitstingForm();
            
            projectManageExitstingForm.ShowDialog();
            
        }

        private void btn_ProjMange_Back_Click(object sender, EventArgs e)
        {

            this.Hide();
            this.Close();
        }
    }
}
