﻿namespace WindowsFormsApp1
{
    partial class ProjectManageExitstingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.projectsList = new System.Windows.Forms.ComboBox();
            this.Label_ChooseProj = new System.Windows.Forms.Label();
            this.Label_ChooseCust_ExistingProj = new System.Windows.Forms.Label();
            this.Label_ChooseCust_ProjMang = new System.Windows.Forms.Label();
            this.btn_ExistingProjBack = new System.Windows.Forms.Button();
            this.updateProjectButton = new System.Windows.Forms.Button();
            this.viewButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // projectsList
            // 
            this.projectsList.FormattingEnabled = true;
            this.projectsList.Location = new System.Drawing.Point(347, 268);
            this.projectsList.Name = "projectsList";
            this.projectsList.Size = new System.Drawing.Size(121, 24);
            this.projectsList.TabIndex = 8;
            this.projectsList.SelectedIndexChanged += new System.EventHandler(this.projectsList_SelectedIndexChanged);
            // 
            // Label_ChooseProj
            // 
            this.Label_ChooseProj.AutoSize = true;
            this.Label_ChooseProj.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ChooseProj.Location = new System.Drawing.Point(205, 272);
            this.Label_ChooseProj.Name = "Label_ChooseProj";
            this.Label_ChooseProj.Size = new System.Drawing.Size(110, 20);
            this.Label_ChooseProj.TabIndex = 7;
            this.Label_ChooseProj.Text = "Choose Project";
            // 
            // Label_ChooseCust_ExistingProj
            // 
            this.Label_ChooseCust_ExistingProj.AutoSize = true;
            this.Label_ChooseCust_ExistingProj.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ChooseCust_ExistingProj.Location = new System.Drawing.Point(321, 163);
            this.Label_ChooseCust_ExistingProj.Name = "Label_ChooseCust_ExistingProj";
            this.Label_ChooseCust_ExistingProj.Size = new System.Drawing.Size(156, 27);
            this.Label_ChooseCust_ExistingProj.TabIndex = 6;
            this.Label_ChooseCust_ExistingProj.Text = "Existing Project";
            // 
            // Label_ChooseCust_ProjMang
            // 
            this.Label_ChooseCust_ProjMang.AutoSize = true;
            this.Label_ChooseCust_ProjMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ChooseCust_ProjMang.Location = new System.Drawing.Point(258, 100);
            this.Label_ChooseCust_ProjMang.Name = "Label_ChooseCust_ProjMang";
            this.Label_ChooseCust_ProjMang.Size = new System.Drawing.Size(311, 37);
            this.Label_ChooseCust_ProjMang.TabIndex = 5;
            this.Label_ChooseCust_ProjMang.Text = "Project Management";
            // 
            // btn_ExistingProjBack
            // 
            this.btn_ExistingProjBack.Location = new System.Drawing.Point(694, 406);
            this.btn_ExistingProjBack.Name = "btn_ExistingProjBack";
            this.btn_ExistingProjBack.Size = new System.Drawing.Size(83, 32);
            this.btn_ExistingProjBack.TabIndex = 9;
            this.btn_ExistingProjBack.Text = "Back";
            this.btn_ExistingProjBack.UseVisualStyleBackColor = true;
            this.btn_ExistingProjBack.Click += new System.EventHandler(this.btn_ExistingProjBack_Click);
            // 
            // updateProjectButton
            // 
            this.updateProjectButton.Location = new System.Drawing.Point(501, 353);
            this.updateProjectButton.Name = "updateProjectButton";
            this.updateProjectButton.Size = new System.Drawing.Size(107, 53);
            this.updateProjectButton.TabIndex = 10;
            this.updateProjectButton.Text = "UPDATE";
            this.updateProjectButton.UseVisualStyleBackColor = true;
            this.updateProjectButton.Click += new System.EventHandler(this.updateProjectButton_Click);
            // 
            // viewButton
            // 
            this.viewButton.Location = new System.Drawing.Point(161, 353);
            this.viewButton.Name = "viewButton";
            this.viewButton.Size = new System.Drawing.Size(96, 53);
            this.viewButton.TabIndex = 11;
            this.viewButton.Text = "VIEW";
            this.viewButton.UseVisualStyleBackColor = true;
            this.viewButton.Click += new System.EventHandler(this.viewButton_Click);
            // 
            // ProjectManageExitstingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.viewButton);
            this.Controls.Add(this.updateProjectButton);
            this.Controls.Add(this.btn_ExistingProjBack);
            this.Controls.Add(this.projectsList);
            this.Controls.Add(this.Label_ChooseProj);
            this.Controls.Add(this.Label_ChooseCust_ExistingProj);
            this.Controls.Add(this.Label_ChooseCust_ProjMang);
            this.Name = "ProjectManageExitstingForm";
            this.Text = "ProjectManageExitstingForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox projectsList;
        private System.Windows.Forms.Label Label_ChooseProj;
        private System.Windows.Forms.Label Label_ChooseCust_ExistingProj;
        private System.Windows.Forms.Label Label_ChooseCust_ProjMang;
        private System.Windows.Forms.Button btn_ExistingProjBack;
        private System.Windows.Forms.Button updateProjectButton;
        private System.Windows.Forms.Button viewButton;
    }
}