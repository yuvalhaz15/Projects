﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CustomerDetails : Form
    {

        private Customer customerToShowDetails;
        public CustomerDetails(Customer c)
        {
            InitializeComponent();
            this.customerToShowDetails = c;

        }
        public void showForm()
        {
            this.initializeData();
            this.Show();

        }

        private void initializeData()
        {
            setCustomerID();
            setCustomerName();
            setCustomerStatus();
            setCustomerMail();
            setCustomerContactName();
            setCustomerPhone();
            setCustomerLastContactDate();
        }

        private void setCustomerLastContactDate()
        {
            this.customerLastContactDateTextBox.Text = this.customerToShowDetails.get_lastContact() + "";
        }

        private void setCustomerPhone()
        {
            this.CustomerPhoneNumberTextBox.Text = this.customerToShowDetails.get_cPhone();
        }

        private void setCustomerContactName()
        {
            this.customerContactNameBox.Text = this.customerToShowDetails.get_cName();
        }

        private void setCustomerMail()
        {
            this.customerMailTextBox.Text = this.customerToShowDetails.get_cMail();
        }

        private void setCustomerStatus()
        {
            this.customerStatusTextBox.Text = this.customerToShowDetails.get_status().ToString();
        }

        private void setCustomerName()
        {
            this.customerNameTextBox1.Text = this.customerToShowDetails.get_name();
        }

        private void setCustomerID()
        {
            this.customerIDTextBox.Text = this.customerToShowDetails.getID();
        }







    }
}
