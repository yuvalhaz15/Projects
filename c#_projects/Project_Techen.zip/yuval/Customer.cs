﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
  public  class Customer
    {
        private string customerID;
        private string customerName;
        private CustomerStatus status;
        private string cMail;
        private string cName;
        private string cPhone;
        private DateTime lastContact;
        private System.Collections.Generic.List<Project> projects;
        private System.Collections.Generic.List<Meeting> myMeetings;

        public Customer(string id, string name, CustomerStatus status, string cMail, string cName, string cPhone, DateTime lastContact, bool isNew)
        {
            this.customerID = id;
            this.customerName = name;
            this.status = status;
            this.cMail = cMail;
            this.cName = cName;
            this.cPhone = cPhone;
            this.lastContact = lastContact;
            projects = new List<Project>();
            myMeetings = new List<Meeting>();

            if (isNew)
            {
                this.create_customer();
                Program.customers.Add(this);
            }

        }

        public List<Project> getProjects()
        {
            return this.projects;
        }
        public List<Meeting> getMyMeetings()
        {
            return this.myMeetings;
        }
        public void readCustomer()
        {


            showCustomerDetails();



        }

       public void updateCustomer()
        {
            CustomerUpdate cuForm = new CustomerUpdate(this);
            cuForm.showForm();
        }

        private void showCustomerDetails()
        {
            CustomerDetails form = new CustomerDetails(this);
            form.showForm();
        }
        public string getID()
        {
            return this.customerID;
        }
        public string get_cMail()
        {
            return this.cMail;
        }
        public void set_cMail(string cMail)
        {
            this.cMail = cMail;
        }
        public string get_cName()
        {
            return this.cName;
        }
        public void set_cName(string cName)
        {
            this.cName = cName;
        }
        public string get_cPhone()
        {
            return this.cPhone;
        }
        public void set_cPhone(string cPhone)
        {
            this.cPhone = cPhone;
        }

        public DateTime get_lastContact()
        {
            return this.lastContact;
        }
        public void set_lastContact(DateTime lastContact)
        {
            this.lastContact = lastContact;
        }

        public string get_name()
        {
            return this.customerName;
        }

        public CustomerStatus get_status()
        {
            return this.status;
        }

       

        public void set_name(string name)
        {
            this.customerName = name;
        }

        public void set_status(CustomerStatus s)
        {
            this.status = s;
        }

        public void create_customer()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_add_customer @id, @name, @status, @cMail, @cName, @cPhone, @lastContact";
            c.Parameters.AddWithValue("@id", this.customerID);
            c.Parameters.AddWithValue("@name", this.customerName);
            c.Parameters.AddWithValue("@status", this.status.ToString());
            c.Parameters.AddWithValue("@cMail", this.cMail);
            c.Parameters.AddWithValue("@cName", this.cName);
            c.Parameters.AddWithValue("@cPhone", this.cPhone);
            c.Parameters.AddWithValue("@lastContact", this.lastContact);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void Update_customer()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE SP_update_customer @id, @name, @status, @cMail, @cName, @cPhone, @lastContact";
            c.Parameters.AddWithValue("@id", this.customerID);
            c.Parameters.AddWithValue("@name", this.customerName);
            c.Parameters.AddWithValue("@status", this.status.ToString());
            c.Parameters.AddWithValue("@cMail", this.cMail);
            c.Parameters.AddWithValue("@cName", this.cName);
            c.Parameters.AddWithValue("@cPhone", this.cPhone);
            c.Parameters.AddWithValue("@lastContact", this.lastContact);
            SQL_CON SC = new SQL_CON();
            SC.execute_non_query(c);
        }

        public void update(string customerID, string customerName, CustomerStatus status, string cMail, string cName, string cPhone, DateTime lastContact)
        {
            this.customerID = customerID;
            this.customerName = customerName;
            this.status = status;
            this.cMail = cMail;
            this.cName = cName;
            this.cPhone = cPhone;
            this.lastContact = lastContact;
            Update_customer();
        }
    }
}