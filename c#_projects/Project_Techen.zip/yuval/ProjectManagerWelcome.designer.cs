﻿namespace WindowsFormsApp1
{
    partial class ProjectManagerWelcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_CustMange_Back = new System.Windows.Forms.Button();
            this.btn_ProjMang_CustomerMang = new System.Windows.Forms.Button();
            this.btn_MarketMang_ReadEmp = new System.Windows.Forms.Button();
            this.Label_ProjMangWel_Hello = new System.Windows.Forms.Label();
            this.btn_ProjMang_ProjMang = new System.Windows.Forms.Button();
            this.btn_ProjMang_ViewWorkReq = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_CustMange_Back
            // 
            this.btn_CustMange_Back.Location = new System.Drawing.Point(678, 353);
            this.btn_CustMange_Back.Name = "btn_CustMange_Back";
            this.btn_CustMange_Back.Size = new System.Drawing.Size(83, 32);
            this.btn_CustMange_Back.TabIndex = 13;
            this.btn_CustMange_Back.Text = "Back";
            this.btn_CustMange_Back.UseVisualStyleBackColor = true;
            this.btn_CustMange_Back.Click += new System.EventHandler(this.btn_CustMange_Back_Click);
            // 
            // btn_ProjMang_CustomerMang
            // 
            this.btn_ProjMang_CustomerMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjMang_CustomerMang.Location = new System.Drawing.Point(46, 251);
            this.btn_ProjMang_CustomerMang.Name = "btn_ProjMang_CustomerMang";
            this.btn_ProjMang_CustomerMang.Size = new System.Drawing.Size(172, 42);
            this.btn_ProjMang_CustomerMang.TabIndex = 11;
            this.btn_ProjMang_CustomerMang.Text = "Read Customer Info";
            this.btn_ProjMang_CustomerMang.UseVisualStyleBackColor = true;
            this.btn_ProjMang_CustomerMang.Click += new System.EventHandler(this.btn_ProjMang_CustomerMang_Click);
            // 
            // btn_MarketMang_ReadEmp
            // 
            this.btn_MarketMang_ReadEmp.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MarketMang_ReadEmp.Location = new System.Drawing.Point(46, 147);
            this.btn_MarketMang_ReadEmp.Name = "btn_MarketMang_ReadEmp";
            this.btn_MarketMang_ReadEmp.Size = new System.Drawing.Size(172, 42);
            this.btn_MarketMang_ReadEmp.TabIndex = 10;
            this.btn_MarketMang_ReadEmp.Text = "Read Employee Info";
            this.btn_MarketMang_ReadEmp.UseVisualStyleBackColor = true;
            this.btn_MarketMang_ReadEmp.Click += new System.EventHandler(this.btn_MarketMang_ReadEmp_Click);
            // 
            // Label_ProjMangWel_Hello
            // 
            this.Label_ProjMangWel_Hello.AutoSize = true;
            this.Label_ProjMangWel_Hello.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ProjMangWel_Hello.Location = new System.Drawing.Point(187, 69);
            this.Label_ProjMangWel_Hello.Name = "Label_ProjMangWel_Hello";
            this.Label_ProjMangWel_Hello.Size = new System.Drawing.Size(389, 31);
            this.Label_ProjMangWel_Hello.TabIndex = 9;
            this.Label_ProjMangWel_Hello.Text = "Hello ! Please choose an action ..";
            // 
            // btn_ProjMang_ProjMang
            // 
            this.btn_ProjMang_ProjMang.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjMang_ProjMang.Location = new System.Drawing.Point(543, 147);
            this.btn_ProjMang_ProjMang.Name = "btn_ProjMang_ProjMang";
            this.btn_ProjMang_ProjMang.Size = new System.Drawing.Size(186, 42);
            this.btn_ProjMang_ProjMang.TabIndex = 11;
            this.btn_ProjMang_ProjMang.Text = "Project Management";
            this.btn_ProjMang_ProjMang.UseVisualStyleBackColor = true;
            this.btn_ProjMang_ProjMang.Click += new System.EventHandler(this.btn_ProjMang_ProjMang_Click);
            // 
            // btn_ProjMang_ViewWorkReq
            // 
            this.btn_ProjMang_ViewWorkReq.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjMang_ViewWorkReq.Location = new System.Drawing.Point(543, 251);
            this.btn_ProjMang_ViewWorkReq.Name = "btn_ProjMang_ViewWorkReq";
            this.btn_ProjMang_ViewWorkReq.Size = new System.Drawing.Size(186, 42);
            this.btn_ProjMang_ViewWorkReq.TabIndex = 11;
            this.btn_ProjMang_ViewWorkReq.Text = "View Working Requests";
            this.btn_ProjMang_ViewWorkReq.UseVisualStyleBackColor = true;
            this.btn_ProjMang_ViewWorkReq.Click += new System.EventHandler(this.btn_ProjMang_ViewWorkReq_Click);
            // 
            // ProjectManagerWelcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_CustMange_Back);
            this.Controls.Add(this.btn_ProjMang_ViewWorkReq);
            this.Controls.Add(this.btn_ProjMang_ProjMang);
            this.Controls.Add(this.btn_ProjMang_CustomerMang);
            this.Controls.Add(this.btn_MarketMang_ReadEmp);
            this.Controls.Add(this.Label_ProjMangWel_Hello);
            this.Name = "ProjectManagerWelcome";
            this.Text = "ProjectManagerWelcome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_CustMange_Back;
        private System.Windows.Forms.Button btn_ProjMang_CustomerMang;
        private System.Windows.Forms.Button btn_MarketMang_ReadEmp;
        private System.Windows.Forms.Label Label_ProjMangWel_Hello;
        private System.Windows.Forms.Button btn_ProjMang_ProjMang;
        private System.Windows.Forms.Button btn_ProjMang_ViewWorkReq;
    }
}