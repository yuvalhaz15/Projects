﻿namespace WindowsFormsApp1
{
    partial class CustomersMangementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_CustCrud_CustomerManagement = new System.Windows.Forms.Label();
            this.btn_CustomerCRU_NewCustomer = new System.Windows.Forms.Button();
            this.btn_CustomerCRU_ExistingCust = new System.Windows.Forms.Button();
            this.btn_CustMange_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_CustCrud_CustomerManagement
            // 
            this.Label_CustCrud_CustomerManagement.AutoSize = true;
            this.Label_CustCrud_CustomerManagement.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CustCrud_CustomerManagement.Location = new System.Drawing.Point(286, 126);
            this.Label_CustCrud_CustomerManagement.Name = "Label_CustCrud_CustomerManagement";
            this.Label_CustCrud_CustomerManagement.Size = new System.Drawing.Size(369, 40);
            this.Label_CustCrud_CustomerManagement.TabIndex = 0;
            this.Label_CustCrud_CustomerManagement.Text = "Customer Management";
            // 
            // btn_CustomerCRU_NewCustomer
            // 
            this.btn_CustomerCRU_NewCustomer.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CustomerCRU_NewCustomer.Location = new System.Drawing.Point(204, 288);
            this.btn_CustomerCRU_NewCustomer.Name = "btn_CustomerCRU_NewCustomer";
            this.btn_CustomerCRU_NewCustomer.Size = new System.Drawing.Size(184, 60);
            this.btn_CustomerCRU_NewCustomer.TabIndex = 1;
            this.btn_CustomerCRU_NewCustomer.Text = "New customer";
            this.btn_CustomerCRU_NewCustomer.UseVisualStyleBackColor = true;
            this.btn_CustomerCRU_NewCustomer.Click += new System.EventHandler(this.btn_CustomerCRU_NewCustomer_Click);
            // 
            // btn_CustomerCRU_ExistingCust
            // 
            this.btn_CustomerCRU_ExistingCust.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CustomerCRU_ExistingCust.Location = new System.Drawing.Point(563, 288);
            this.btn_CustomerCRU_ExistingCust.Name = "btn_CustomerCRU_ExistingCust";
            this.btn_CustomerCRU_ExistingCust.Size = new System.Drawing.Size(179, 60);
            this.btn_CustomerCRU_ExistingCust.TabIndex = 2;
            this.btn_CustomerCRU_ExistingCust.Text = "Existing customer";
            this.btn_CustomerCRU_ExistingCust.UseVisualStyleBackColor = true;
            this.btn_CustomerCRU_ExistingCust.Click += new System.EventHandler(this.btn_CustomerCRU_ExistingCust_Click);
            // 
            // btn_CustMange_Back
            // 
            this.btn_CustMange_Back.Location = new System.Drawing.Point(820, 531);
            this.btn_CustMange_Back.Name = "btn_CustMange_Back";
            this.btn_CustMange_Back.Size = new System.Drawing.Size(83, 32);
            this.btn_CustMange_Back.TabIndex = 7;
            this.btn_CustMange_Back.Text = "Back";
            this.btn_CustMange_Back.UseVisualStyleBackColor = true;
            this.btn_CustMange_Back.Click += new System.EventHandler(this.btn_CustMange_Back_Click);
            // 
            // CustomersMangementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 597);
            this.Controls.Add(this.btn_CustMange_Back);
            this.Controls.Add(this.btn_CustomerCRU_ExistingCust);
            this.Controls.Add(this.btn_CustomerCRU_NewCustomer);
            this.Controls.Add(this.Label_CustCrud_CustomerManagement);
            this.Name = "CustomersMangementForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_CustCrud_CustomerManagement;
        private System.Windows.Forms.Button btn_CustomerCRU_NewCustomer;
        private System.Windows.Forms.Button btn_CustomerCRU_ExistingCust;
        private System.Windows.Forms.Button btn_CustMange_Back;
    }
}

