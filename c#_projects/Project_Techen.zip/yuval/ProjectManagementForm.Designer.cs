﻿namespace WindowsFormsApp1
{
    partial class ProjectManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ProjectCRU_ExistingProj = new System.Windows.Forms.Button();
            this.btn_ProjectCRU_NewProject = new System.Windows.Forms.Button();
            this.Label_ProjCrud_ProjManagement = new System.Windows.Forms.Label();
            this.btn_ProjMange_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_ProjectCRU_ExistingProj
            // 
            this.btn_ProjectCRU_ExistingProj.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjectCRU_ExistingProj.Location = new System.Drawing.Point(490, 276);
            this.btn_ProjectCRU_ExistingProj.Name = "btn_ProjectCRU_ExistingProj";
            this.btn_ProjectCRU_ExistingProj.Size = new System.Drawing.Size(179, 60);
            this.btn_ProjectCRU_ExistingProj.TabIndex = 5;
            this.btn_ProjectCRU_ExistingProj.Text = "Existing Project";
            this.btn_ProjectCRU_ExistingProj.UseVisualStyleBackColor = true;
            this.btn_ProjectCRU_ExistingProj.Click += new System.EventHandler(this.btn_ProjectCRU_ExistingProj_Click);
            // 
            // btn_ProjectCRU_NewProject
            // 
            this.btn_ProjectCRU_NewProject.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ProjectCRU_NewProject.Location = new System.Drawing.Point(131, 276);
            this.btn_ProjectCRU_NewProject.Name = "btn_ProjectCRU_NewProject";
            this.btn_ProjectCRU_NewProject.Size = new System.Drawing.Size(184, 60);
            this.btn_ProjectCRU_NewProject.TabIndex = 4;
            this.btn_ProjectCRU_NewProject.Text = "New Project";
            this.btn_ProjectCRU_NewProject.UseVisualStyleBackColor = true;
            this.btn_ProjectCRU_NewProject.Click += new System.EventHandler(this.btn_CustomerCRU_NewProject_Click);
            // 
            // Label_ProjCrud_ProjManagement
            // 
            this.Label_ProjCrud_ProjManagement.AutoSize = true;
            this.Label_ProjCrud_ProjManagement.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ProjCrud_ProjManagement.Location = new System.Drawing.Point(236, 122);
            this.Label_ProjCrud_ProjManagement.Name = "Label_ProjCrud_ProjManagement";
            this.Label_ProjCrud_ProjManagement.Size = new System.Drawing.Size(331, 40);
            this.Label_ProjCrud_ProjManagement.TabIndex = 3;
            this.Label_ProjCrud_ProjManagement.Text = "Project Management";
            // 
            // btn_ProjMange_Back
            // 
            this.btn_ProjMange_Back.Location = new System.Drawing.Point(705, 406);
            this.btn_ProjMange_Back.Name = "btn_ProjMange_Back";
            this.btn_ProjMange_Back.Size = new System.Drawing.Size(83, 32);
            this.btn_ProjMange_Back.TabIndex = 6;
            this.btn_ProjMange_Back.Text = "Back";
            this.btn_ProjMange_Back.UseVisualStyleBackColor = true;
            this.btn_ProjMange_Back.Click += new System.EventHandler(this.btn_ProjMange_Back_Click);
            // 
            // ProjectManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_ProjMange_Back);
            this.Controls.Add(this.btn_ProjectCRU_ExistingProj);
            this.Controls.Add(this.btn_ProjectCRU_NewProject);
            this.Controls.Add(this.Label_ProjCrud_ProjManagement);
            this.Name = "ProjectManagementForm";
            this.Text = "ProjectManagementForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ProjectCRU_ExistingProj;
        private System.Windows.Forms.Button btn_ProjectCRU_NewProject;
        private System.Windows.Forms.Label Label_ProjCrud_ProjManagement;
        private System.Windows.Forms.Button btn_ProjMange_Back;
    }
}