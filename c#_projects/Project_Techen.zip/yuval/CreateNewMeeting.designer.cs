﻿namespace WindowsFormsApp1
{
    partial class CreateNewMeeting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_CreateMeeting_Back = new System.Windows.Forms.Button();
            this.NoteTextBox = new System.Windows.Forms.RichTextBox();
            this.PurposeBox = new System.Windows.Forms.ComboBox();
            this.label_CreateProj_SimuLoc = new System.Windows.Forms.Label();
            this.label_CreateProj_Cost = new System.Windows.Forms.Label();
            this.label_CreateMeeting_Hours = new System.Windows.Forms.Label();
            this.label_CreateMeeting_Purpose = new System.Windows.Forms.Label();
            this.label_CreateMeeting_CustomerID = new System.Windows.Forms.Label();
            this.Label_CreateMeeting = new System.Windows.Forms.Label();
            this.btn_CreateMeeting_AddMeeting = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.NoteSet = new System.Windows.Forms.Button();
            this.MyIDSet1 = new System.Windows.Forms.Button();
            this.MyIDTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EmployeesBox = new System.Windows.Forms.CheckedListBox();
            this.MeetingTimeTextBox = new System.Windows.Forms.TextBox();
            this.CustomerBox = new System.Windows.Forms.ComboBox();
            this.MeetingTimeSet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_CreateMeeting_Back
            // 
            this.btn_CreateMeeting_Back.Location = new System.Drawing.Point(665, 533);
            this.btn_CreateMeeting_Back.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_CreateMeeting_Back.Name = "btn_CreateMeeting_Back";
            this.btn_CreateMeeting_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_CreateMeeting_Back.TabIndex = 73;
            this.btn_CreateMeeting_Back.Text = "Back";
            this.btn_CreateMeeting_Back.UseVisualStyleBackColor = true;
            this.btn_CreateMeeting_Back.Click += new System.EventHandler(this.btn_CreateMeeting_Back_Click);
            // 
            // NoteTextBox
            // 
            this.NoteTextBox.Location = new System.Drawing.Point(312, 404);
            this.NoteTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NoteTextBox.Name = "NoteTextBox";
            this.NoteTextBox.Size = new System.Drawing.Size(177, 96);
            this.NoteTextBox.TabIndex = 72;
            this.NoteTextBox.Text = "";
            // 
            // PurposeBox
            // 
            this.PurposeBox.FormattingEnabled = true;
            this.PurposeBox.Location = new System.Drawing.Point(312, 356);
            this.PurposeBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PurposeBox.Name = "PurposeBox";
            this.PurposeBox.Size = new System.Drawing.Size(177, 24);
            this.PurposeBox.TabIndex = 71;
            this.PurposeBox.SelectedIndexChanged += new System.EventHandler(this.PurposeBox_SelectedIndexChanged);
            // 
            // label_CreateProj_SimuLoc
            // 
            this.label_CreateProj_SimuLoc.AutoSize = true;
            this.label_CreateProj_SimuLoc.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_SimuLoc.Location = new System.Drawing.Point(172, 446);
            this.label_CreateProj_SimuLoc.Name = "label_CreateProj_SimuLoc";
            this.label_CreateProj_SimuLoc.Size = new System.Drawing.Size(124, 20);
            this.label_CreateProj_SimuLoc.TabIndex = 67;
            this.label_CreateProj_SimuLoc.Text = "Additional Note :";
            // 
            // label_CreateProj_Cost
            // 
            this.label_CreateProj_Cost.AutoSize = true;
            this.label_CreateProj_Cost.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateProj_Cost.Location = new System.Drawing.Point(180, 286);
            this.label_CreateProj_Cost.Name = "label_CreateProj_Cost";
            this.label_CreateProj_Cost.Size = new System.Drawing.Size(0, 20);
            this.label_CreateProj_Cost.TabIndex = 68;
            // 
            // label_CreateMeeting_Hours
            // 
            this.label_CreateMeeting_Hours.AutoSize = true;
            this.label_CreateMeeting_Hours.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateMeeting_Hours.Location = new System.Drawing.Point(132, 178);
            this.label_CreateMeeting_Hours.Name = "label_CreateMeeting_Hours";
            this.label_CreateMeeting_Hours.Size = new System.Drawing.Size(162, 20);
            this.label_CreateMeeting_Hours.TabIndex = 66;
            this.label_CreateMeeting_Hours.Text = "Choose Availible Hour:";
            // 
            // label_CreateMeeting_Purpose
            // 
            this.label_CreateMeeting_Purpose.AutoSize = true;
            this.label_CreateMeeting_Purpose.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateMeeting_Purpose.Location = new System.Drawing.Point(227, 362);
            this.label_CreateMeeting_Purpose.Name = "label_CreateMeeting_Purpose";
            this.label_CreateMeeting_Purpose.Size = new System.Drawing.Size(71, 20);
            this.label_CreateMeeting_Purpose.TabIndex = 65;
            this.label_CreateMeeting_Purpose.Text = "Purpose :";
            // 
            // label_CreateMeeting_CustomerID
            // 
            this.label_CreateMeeting_CustomerID.AutoSize = true;
            this.label_CreateMeeting_CustomerID.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateMeeting_CustomerID.Location = new System.Drawing.Point(214, 104);
            this.label_CreateMeeting_CustomerID.Name = "label_CreateMeeting_CustomerID";
            this.label_CreateMeeting_CustomerID.Size = new System.Drawing.Size(80, 20);
            this.label_CreateMeeting_CustomerID.TabIndex = 64;
            this.label_CreateMeeting_CustomerID.Text = "Customer :";
            // 
            // Label_CreateMeeting
            // 
            this.Label_CreateMeeting.AutoSize = true;
            this.Label_CreateMeeting.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_CreateMeeting.Location = new System.Drawing.Point(305, 54);
            this.Label_CreateMeeting.Name = "Label_CreateMeeting";
            this.Label_CreateMeeting.Size = new System.Drawing.Size(207, 37);
            this.Label_CreateMeeting.TabIndex = 63;
            this.Label_CreateMeeting.Text = "New Meeting";
            // 
            // btn_CreateMeeting_AddMeeting
            // 
            this.btn_CreateMeeting_AddMeeting.Location = new System.Drawing.Point(312, 533);
            this.btn_CreateMeeting_AddMeeting.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_CreateMeeting_AddMeeting.Name = "btn_CreateMeeting_AddMeeting";
            this.btn_CreateMeeting_AddMeeting.Size = new System.Drawing.Size(115, 36);
            this.btn_CreateMeeting_AddMeeting.TabIndex = 62;
            this.btn_CreateMeeting_AddMeeting.Text = "Add Meeting";
            this.btn_CreateMeeting_AddMeeting.UseVisualStyleBackColor = true;
            this.btn_CreateMeeting_AddMeeting.Click += new System.EventHandler(this.btn_CreateMeeting_AddMeeting_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 76;
            this.label2.Text = "My ID :";
            // 
            // NoteSet
            // 
            this.NoteSet.Location = new System.Drawing.Point(509, 441);
            this.NoteSet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NoteSet.Name = "NoteSet";
            this.NoteSet.Size = new System.Drawing.Size(72, 25);
            this.NoteSet.TabIndex = 77;
            this.NoteSet.Text = "set\r\n\r\n";
            this.NoteSet.UseVisualStyleBackColor = true;
            this.NoteSet.Click += new System.EventHandler(this.NoteSet_Click);
            // 
            // MyIDSet1
            // 
            this.MyIDSet1.Location = new System.Drawing.Point(80, 65);
            this.MyIDSet1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MyIDSet1.Name = "MyIDSet1";
            this.MyIDSet1.Size = new System.Drawing.Size(72, 25);
            this.MyIDSet1.TabIndex = 78;
            this.MyIDSet1.Text = "set\r\n\r\n";
            this.MyIDSet1.UseVisualStyleBackColor = true;
            this.MyIDSet1.Click += new System.EventHandler(this.MyIDSet_Click);
            // 
            // MyIDTextBox
            // 
            this.MyIDTextBox.Location = new System.Drawing.Point(80, 34);
            this.MyIDTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MyIDTextBox.Name = "MyIDTextBox";
            this.MyIDTextBox.Size = new System.Drawing.Size(132, 22);
            this.MyIDTextBox.TabIndex = 79;
            this.MyIDTextBox.TextChanged += new System.EventHandler(this.MyIDTextBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(217, 257);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 80;
            this.label3.Text = "Employees :";
            // 
            // EmployeesBox
            // 
            this.EmployeesBox.FormattingEnabled = true;
            this.EmployeesBox.Location = new System.Drawing.Point(312, 222);
            this.EmployeesBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EmployeesBox.Name = "EmployeesBox";
            this.EmployeesBox.Size = new System.Drawing.Size(427, 106);
            this.EmployeesBox.TabIndex = 81;
            this.EmployeesBox.SelectedIndexChanged += new System.EventHandler(this.EmployeesBox_SelectedIndexChanged);
            this.EmployeesBox.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.EmployeesBox_ControlAdded);
            // 
            // MeetingTimeTextBox
            // 
            this.MeetingTimeTextBox.Location = new System.Drawing.Point(312, 173);
            this.MeetingTimeTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MeetingTimeTextBox.Name = "MeetingTimeTextBox";
            this.MeetingTimeTextBox.Size = new System.Drawing.Size(177, 22);
            this.MeetingTimeTextBox.TabIndex = 82;
            // 
            // CustomerBox
            // 
            this.CustomerBox.FormattingEnabled = true;
            this.CustomerBox.Location = new System.Drawing.Point(312, 104);
            this.CustomerBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CustomerBox.Name = "CustomerBox";
            this.CustomerBox.Size = new System.Drawing.Size(177, 24);
            this.CustomerBox.TabIndex = 70;
            this.CustomerBox.SelectedIndexChanged += new System.EventHandler(this.CustomerBox_SelectedIndexChanged);
            // 
            // MeetingTimeSet
            // 
            this.MeetingTimeSet.Location = new System.Drawing.Point(218, 222);
            this.MeetingTimeSet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MeetingTimeSet.Name = "MeetingTimeSet";
            this.MeetingTimeSet.Size = new System.Drawing.Size(72, 25);
            this.MeetingTimeSet.TabIndex = 83;
            this.MeetingTimeSet.Text = "set\r\n\r\n";
            this.MeetingTimeSet.UseVisualStyleBackColor = true;
            this.MeetingTimeSet.Click += new System.EventHandler(this.MeetingTimeSet_Click);
            // 
            // CreateNewMeeting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 582);
            this.Controls.Add(this.MeetingTimeSet);
            this.Controls.Add(this.MeetingTimeTextBox);
            this.Controls.Add(this.EmployeesBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.MyIDTextBox);
            this.Controls.Add(this.MyIDSet1);
            this.Controls.Add(this.NoteSet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_CreateMeeting_Back);
            this.Controls.Add(this.NoteTextBox);
            this.Controls.Add(this.PurposeBox);
            this.Controls.Add(this.CustomerBox);
            this.Controls.Add(this.label_CreateProj_SimuLoc);
            this.Controls.Add(this.label_CreateProj_Cost);
            this.Controls.Add(this.label_CreateMeeting_Hours);
            this.Controls.Add(this.label_CreateMeeting_Purpose);
            this.Controls.Add(this.label_CreateMeeting_CustomerID);
            this.Controls.Add(this.Label_CreateMeeting);
            this.Controls.Add(this.btn_CreateMeeting_AddMeeting);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CreateNewMeeting";
            this.Text = "CreateNewMeeting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_CreateMeeting_Back;
        private System.Windows.Forms.RichTextBox NoteTextBox;
        private System.Windows.Forms.ComboBox PurposeBox;
        private System.Windows.Forms.Label label_CreateProj_SimuLoc;
        private System.Windows.Forms.Label label_CreateProj_Cost;
        private System.Windows.Forms.Label label_CreateMeeting_Hours;
        private System.Windows.Forms.Label label_CreateMeeting_Purpose;
        private System.Windows.Forms.Label label_CreateMeeting_CustomerID;
        private System.Windows.Forms.Label Label_CreateMeeting;
        private System.Windows.Forms.Button btn_CreateMeeting_AddMeeting;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button NoteSet;
        private System.Windows.Forms.Button MyIDSet1;
        private System.Windows.Forms.TextBox MyIDTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox EmployeesBox;
        private System.Windows.Forms.TextBox MeetingTimeTextBox;
        private System.Windows.Forms.ComboBox CustomerBox;
        private System.Windows.Forms.Button MeetingTimeSet;
    }
}