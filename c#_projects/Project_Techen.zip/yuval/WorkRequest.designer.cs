﻿namespace WindowsFormsApp1
{
    partial class WorkRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_WorkReq = new System.Windows.Forms.Label();
            this.Label_WorkReq_StartDate = new System.Windows.Forms.Label();
            this.Label_WorkReq_EndDate = new System.Windows.Forms.Label();
            this.dateTimePicker_WorkReq_StartDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_WorkReq_EndDate = new System.Windows.Forms.DateTimePicker();
            this.AdditionalCommentTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label_WorkReq_RequestNum = new System.Windows.Forms.Label();
            this.TextBox_WorkReq_RequestNum = new System.Windows.Forms.TextBox();
            this.Label_WorkReq_Purpose = new System.Windows.Forms.Label();
            this.comboBox_WorkReq_Purpose = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_WorkReq_Submit = new System.Windows.Forms.Button();
            this.AdditionalCommentBottom = new System.Windows.Forms.Button();
            this.RequestNumBotton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.MyIDTextBox = new System.Windows.Forms.TextBox();
            this.MyIDSet = new System.Windows.Forms.Button();
            this.projectManagerList = new System.Windows.Forms.Label();
            this.projectManagerListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Label_WorkReq
            // 
            this.Label_WorkReq.AutoSize = true;
            this.Label_WorkReq.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq.Location = new System.Drawing.Point(283, 17);
            this.Label_WorkReq.Name = "Label_WorkReq";
            this.Label_WorkReq.Size = new System.Drawing.Size(217, 37);
            this.Label_WorkReq.TabIndex = 0;
            this.Label_WorkReq.Text = "Work Request";
            // 
            // Label_WorkReq_StartDate
            // 
            this.Label_WorkReq_StartDate.AutoSize = true;
            this.Label_WorkReq_StartDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq_StartDate.Location = new System.Drawing.Point(201, 148);
            this.Label_WorkReq_StartDate.Name = "Label_WorkReq_StartDate";
            this.Label_WorkReq_StartDate.Size = new System.Drawing.Size(76, 20);
            this.Label_WorkReq_StartDate.TabIndex = 1;
            this.Label_WorkReq_StartDate.Text = "Start Date";
            // 
            // Label_WorkReq_EndDate
            // 
            this.Label_WorkReq_EndDate.AutoSize = true;
            this.Label_WorkReq_EndDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq_EndDate.Location = new System.Drawing.Point(205, 192);
            this.Label_WorkReq_EndDate.Name = "Label_WorkReq_EndDate";
            this.Label_WorkReq_EndDate.Size = new System.Drawing.Size(71, 20);
            this.Label_WorkReq_EndDate.TabIndex = 2;
            this.Label_WorkReq_EndDate.Text = "End Date";
            // 
            // dateTimePicker_WorkReq_StartDate
            // 
            this.dateTimePicker_WorkReq_StartDate.Location = new System.Drawing.Point(289, 148);
            this.dateTimePicker_WorkReq_StartDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker_WorkReq_StartDate.Name = "dateTimePicker_WorkReq_StartDate";
            this.dateTimePicker_WorkReq_StartDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker_WorkReq_StartDate.TabIndex = 3;
            this.dateTimePicker_WorkReq_StartDate.ValueChanged += new System.EventHandler(this.dateTimePicker_WorkReq_StartDate_ValueChanged);
            // 
            // dateTimePicker_WorkReq_EndDate
            // 
            this.dateTimePicker_WorkReq_EndDate.Location = new System.Drawing.Point(289, 192);
            this.dateTimePicker_WorkReq_EndDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker_WorkReq_EndDate.Name = "dateTimePicker_WorkReq_EndDate";
            this.dateTimePicker_WorkReq_EndDate.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker_WorkReq_EndDate.TabIndex = 4;
            this.dateTimePicker_WorkReq_EndDate.ValueChanged += new System.EventHandler(this.dateTimePicker_WorkReq_EndDate_ValueChanged);
            // 
            // AdditionalCommentTextBox1
            // 
            this.AdditionalCommentTextBox1.Location = new System.Drawing.Point(289, 287);
            this.AdditionalCommentTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AdditionalCommentTextBox1.Name = "AdditionalCommentTextBox1";
            this.AdditionalCommentTextBox1.Size = new System.Drawing.Size(200, 100);
            this.AdditionalCommentTextBox1.TabIndex = 5;
            this.AdditionalCommentTextBox1.Text = "";
            // 
            // label_WorkReq_RequestNum
            // 
            this.label_WorkReq_RequestNum.AutoSize = true;
            this.label_WorkReq_RequestNum.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_WorkReq_RequestNum.Location = new System.Drawing.Point(177, 103);
            this.label_WorkReq_RequestNum.Name = "label_WorkReq_RequestNum";
            this.label_WorkReq_RequestNum.Size = new System.Drawing.Size(100, 20);
            this.label_WorkReq_RequestNum.TabIndex = 6;
            this.label_WorkReq_RequestNum.Text = "Request Num";
            this.label_WorkReq_RequestNum.Click += new System.EventHandler(this.label_WorkReq_RequestNum_Click);
            // 
            // TextBox_WorkReq_RequestNum
            // 
            this.TextBox_WorkReq_RequestNum.Location = new System.Drawing.Point(289, 102);
            this.TextBox_WorkReq_RequestNum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TextBox_WorkReq_RequestNum.Name = "TextBox_WorkReq_RequestNum";
            this.TextBox_WorkReq_RequestNum.Size = new System.Drawing.Size(200, 22);
            this.TextBox_WorkReq_RequestNum.TabIndex = 7;
            // 
            // Label_WorkReq_Purpose
            // 
            this.Label_WorkReq_Purpose.AutoSize = true;
            this.Label_WorkReq_Purpose.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WorkReq_Purpose.Location = new System.Drawing.Point(213, 241);
            this.Label_WorkReq_Purpose.Name = "Label_WorkReq_Purpose";
            this.Label_WorkReq_Purpose.Size = new System.Drawing.Size(64, 20);
            this.Label_WorkReq_Purpose.TabIndex = 2;
            this.Label_WorkReq_Purpose.Text = "Purpose";
            // 
            // comboBox_WorkReq_Purpose
            // 
            this.comboBox_WorkReq_Purpose.FormattingEnabled = true;
            this.comboBox_WorkReq_Purpose.Location = new System.Drawing.Point(289, 241);
            this.comboBox_WorkReq_Purpose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox_WorkReq_Purpose.Name = "comboBox_WorkReq_Purpose";
            this.comboBox_WorkReq_Purpose.Size = new System.Drawing.Size(200, 24);
            this.comboBox_WorkReq_Purpose.TabIndex = 8;
            this.comboBox_WorkReq_Purpose.SelectedIndexChanged += new System.EventHandler(this.comboBox_WorkReq_Purpose_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(127, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Additional Comment";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_WorkReq_Submit
            // 
            this.btn_WorkReq_Submit.Location = new System.Drawing.Point(316, 418);
            this.btn_WorkReq_Submit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_WorkReq_Submit.Name = "btn_WorkReq_Submit";
            this.btn_WorkReq_Submit.Size = new System.Drawing.Size(139, 32);
            this.btn_WorkReq_Submit.TabIndex = 10;
            this.btn_WorkReq_Submit.Text = "Submit Request";
            this.btn_WorkReq_Submit.UseVisualStyleBackColor = true;
            this.btn_WorkReq_Submit.Click += new System.EventHandler(this.btn_WorkReq_Submit_Click);
            // 
            // AdditionalCommentBottom
            // 
            this.AdditionalCommentBottom.Location = new System.Drawing.Point(520, 321);
            this.AdditionalCommentBottom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AdditionalCommentBottom.Name = "AdditionalCommentBottom";
            this.AdditionalCommentBottom.Size = new System.Drawing.Size(72, 28);
            this.AdditionalCommentBottom.TabIndex = 72;
            this.AdditionalCommentBottom.Text = "set\r\n\r\n";
            this.AdditionalCommentBottom.UseVisualStyleBackColor = true;
            this.AdditionalCommentBottom.Click += new System.EventHandler(this.AdditionalCommentBottom_Click);
            // 
            // RequestNumBotton
            // 
            this.RequestNumBotton.Location = new System.Drawing.Point(520, 102);
            this.RequestNumBotton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RequestNumBotton.Name = "RequestNumBotton";
            this.RequestNumBotton.Size = new System.Drawing.Size(72, 25);
            this.RequestNumBotton.TabIndex = 73;
            this.RequestNumBotton.Text = "set\r\n\r\n";
            this.RequestNumBotton.UseVisualStyleBackColor = true;
            this.RequestNumBotton.Click += new System.EventHandler(this.RequestNumBotton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 74;
            this.label2.Text = "My ID :";
            // 
            // MyIDTextBox
            // 
            this.MyIDTextBox.Location = new System.Drawing.Point(79, 34);
            this.MyIDTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MyIDTextBox.Name = "MyIDTextBox";
            this.MyIDTextBox.Size = new System.Drawing.Size(132, 22);
            this.MyIDTextBox.TabIndex = 75;
            // 
            // MyIDSet
            // 
            this.MyIDSet.Location = new System.Drawing.Point(79, 65);
            this.MyIDSet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MyIDSet.Name = "MyIDSet";
            this.MyIDSet.Size = new System.Drawing.Size(72, 25);
            this.MyIDSet.TabIndex = 76;
            this.MyIDSet.Text = "set\r\n\r\n";
            this.MyIDSet.UseVisualStyleBackColor = true;
            this.MyIDSet.Click += new System.EventHandler(this.MyIDSet_Click);
            // 
            // projectManagerList
            // 
            this.projectManagerList.AutoSize = true;
            this.projectManagerList.Location = new System.Drawing.Point(629, 54);
            this.projectManagerList.Name = "projectManagerList";
            this.projectManagerList.Size = new System.Drawing.Size(159, 17);
            this.projectManagerList.TabIndex = 78;
            this.projectManagerList.Text = "Select Project Manager ";
            // 
            // projectManagerListBox
            // 
            this.projectManagerListBox.FormattingEnabled = true;
            this.projectManagerListBox.ItemHeight = 16;
            this.projectManagerListBox.Location = new System.Drawing.Point(638, 111);
            this.projectManagerListBox.Name = "projectManagerListBox";
            this.projectManagerListBox.Size = new System.Drawing.Size(149, 164);
            this.projectManagerListBox.TabIndex = 79;
            this.projectManagerListBox.SelectedIndexChanged += new System.EventHandler(this.projectManagerListBox_SelectedIndexChanged);
            // 
            // WorkRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 519);
            this.Controls.Add(this.projectManagerListBox);
            this.Controls.Add(this.projectManagerList);
            this.Controls.Add(this.MyIDSet);
            this.Controls.Add(this.MyIDTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RequestNumBotton);
            this.Controls.Add(this.AdditionalCommentBottom);
            this.Controls.Add(this.btn_WorkReq_Submit);
            this.Controls.Add(this.comboBox_WorkReq_Purpose);
            this.Controls.Add(this.TextBox_WorkReq_RequestNum);
            this.Controls.Add(this.label_WorkReq_RequestNum);
            this.Controls.Add(this.AdditionalCommentTextBox1);
            this.Controls.Add(this.dateTimePicker_WorkReq_EndDate);
            this.Controls.Add(this.dateTimePicker_WorkReq_StartDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Label_WorkReq_Purpose);
            this.Controls.Add(this.Label_WorkReq_EndDate);
            this.Controls.Add(this.Label_WorkReq_StartDate);
            this.Controls.Add(this.Label_WorkReq);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "WorkRequest";
            this.Text = "WorkRequest";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_WorkReq;
        private System.Windows.Forms.Label Label_WorkReq_StartDate;
        private System.Windows.Forms.Label Label_WorkReq_EndDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_WorkReq_StartDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_WorkReq_EndDate;
        private System.Windows.Forms.RichTextBox AdditionalCommentTextBox1;
        private System.Windows.Forms.Label label_WorkReq_RequestNum;
        private System.Windows.Forms.TextBox TextBox_WorkReq_RequestNum;
        private System.Windows.Forms.Label Label_WorkReq_Purpose;
        private System.Windows.Forms.ComboBox comboBox_WorkReq_Purpose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_WorkReq_Submit;
        private System.Windows.Forms.Button AdditionalCommentBottom;
        private System.Windows.Forms.Button RequestNumBotton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox MyIDTextBox;
        private System.Windows.Forms.Button MyIDSet;
        private System.Windows.Forms.Label projectManagerList;
        private System.Windows.Forms.ListBox projectManagerListBox;
    }
}