﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        private Employee employee;
        private String userID;
        public MainForm()
        {
            InitializeComponent();

        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {
            userID = idTextBox.Text;
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            if (idIsValid())
            {
                employee = matchEmployeeToId();
                switch (this.employee.getEmployeeType().ToString())
                {
                    case "CEO":
                        CEOForm ceoForm = new CEOForm();
                        ceoForm.Show();

                        break;
                    case "Project_Manager":
                        ProjectManagerWelcome pmForm = new ProjectManagerWelcome();
                        pmForm.Show();
                        break;
                    case "Simulation_Developer":
                      
                        Employee em = Program.seekEmployee(idTextBox.Text);
                        em.enterToWork(DateTime.Now);
                        SimulationDeveloper sdForm = new SimulationDeveloper(em);
                        sdForm.Show();
                        break;
                    case "Marketing_Manager":
                        MarketingManagrWelcome mkForm = new MarketingManagrWelcome();
                        mkForm.Show();
                        break;
                }


            }
            else
                MessageBox.Show("Error!! ID does not exist in the system ");

        }

        private Employee matchEmployeeToId()
        {
            foreach (Employee e in Program.employees)
                if (this.userID == e.getId())
                    return e;
            return null;
        }

        private bool idIsValid()
        {
            return idExist();
        }
        private bool idExist()
        {
            if (Program.employees == null)
                return false;
            foreach (Employee e in Program.employees)
                if (this.userID == e.getId())
                    return true;

            return false;
        }



    }



}
