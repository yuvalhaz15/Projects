﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CreateProject : Form
    {

        private Customer customer;
        private string projectID;
        private string projectName;
        private int complexityLevel;
        private DateTime startTime;
        private DateTime endTime;
        private double cost;
        private DateTime lastSimulationUpdate;
        private ProjectStatusEnum status;
        private string simulationLocation;
        private string summeryReport;
        private Employee manager;
        public CreateProject()
        {
            InitializeComponent();
            setProjectDate();  
            setProjectStatus();
        }

        private void setProjectDate()
        {
            this.startTime = DateTime.Now;
        }

        private void Label_CreateCustomer_CustManag_Click(object sender, EventArgs e)
        {

        }

        private void btn_CreateProj_Exit_Click(object sender, EventArgs e)
        {
            ProjectManagementForm projectManagementForm = new ProjectManagementForm();
            this.Hide();
            projectManagementForm.ShowDialog();
            this.Close();
        }

        private void setProjectIdButton_Click(object sender, EventArgs e)
        {
            if (IdIsValid())
            {
                this.projectID = textBox_CreateProj_ProjectID.Text;
                MessageBox.Show("Project ID was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!!Project ID is unvalid");
                textBox_CreateProj_ProjectID.Text = "";

            }

        }

        private bool IdIsValid()
        {
            return textBox_CreateProj_ProjectID.Text.Length > 0 && textBox_CreateProj_ProjectID.Text.Length <= 10 && allNumbers(textBox_CreateProj_ProjectID.Text) && !idExist(textBox_CreateProj_ProjectID.Text);

        }

        private bool allNumbers(string toCheck)
        {
            for (int i = 0; i < toCheck.Length; i++)

                if (toCheck[i] < '0' || toCheck[i] > '9')
                    return false;

            return true;
        }
        private bool idExist(String idToCheck)
        {
            if (Program.ProjectsInArchive == null && Program.ProjectsInProgress == null)
                return false;
            foreach (Project p in Program.ProjectsInArchive)
                if (idToCheck == p.getProjectID())
                    return true;
            foreach (Project p in Program.ProjectsInProgress)
                if (idToCheck == p.getProjectID())
                    return true;
            return false;
        }

        private void setProjectNameButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(textBox_CreateProj_Name.Text))
            {
                this.projectName = textBox_CreateProj_Name.Text;
                MessageBox.Show("Project name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                textBox_CreateProj_Name.Text = "";


            }
        }
        private bool nameIsValid(string name)
        {

            return allLetters(name) && name.Length > 0 && name.Length < 20;
        }
        private bool allLetters(string name)
        {
            for (int i = 0; i < name.Length; i++)

                if ((name[i] < 'a' || name[i] > 'z') && name[i] != ' ')
                    if ((name[i] < 'A' || name[i] > 'Z'))
                        return false;

            return true;
        }

        private void dateTimePicker_CreateProj_EndTime_ValueChanged(object sender, EventArgs e)
        {
            if (dateIsValid())
            {
                this.endTime = DateTime.Parse(dateTimePicker_CreateProj_EndTime.Text);
                MessageBox.Show("End time  was changed successfully");

            }
            else
            {
                MessageBox.Show("Date is unvalid");


            }


        }

        private bool dateIsValid()
        {
            return DateTime.Parse(dateTimePicker_CreateProj_EndTime.Text) >= this.startTime;
        }

        private void setCostButton_Click(object sender, EventArgs e)
        {
            if (double.Parse(this.textBox_CreateProj_Cost.Text) > 0)
            {
                this.cost = double.Parse(this.textBox_CreateProj_Cost.Text);
                MessageBox.Show("Cost  was changed successfully");

            }
            else
            {
                MessageBox.Show("Erro!! Cost  un valid");
                this.textBox_CreateProj_Cost.Text = "";
            }




        }

        private void textBox_CreateProj_SimuLoc_TextChanged(object sender, EventArgs e)
        {
            if (simulationLocationIsValid())
            {
                this.simulationLocation = this.textBox_CreateProj_SimuLoc.Text;
                MessageBox.Show("Simulation location  was changed successfully");
            }
            else
            {
                MessageBox.Show("Error !!Simulation location  un valid");
                this.textBox_CreateProj_SimuLoc.Text = "";

            }


        }

        private bool simulationLocationIsValid()
        {
            return this.textBox_CreateProj_CompLevel.Text.Length <= 30;
        }
        private void setProjectStatus()
        {
            this.status = ProjectStatusEnum.Data_Collecting;
        }
        private void btn_CreateProj_AddProj_Click(object sender, EventArgs e)
        {
            if (allFieldsWasInitilized())
            {
                Project p = new Project(this.customer, this.projectID, this.projectName, this.manager,this.status, this.startTime, this.endTime, this.complexityLevel, this.cost, DateTime.Now, this.simulationLocation, this.summeryReport, true);
                MessageBox.Show("Project added successfully");
            }
            else
                MessageBox.Show("One or more details are missing");

        }

        private Customer seekCustomer()
        {
            if (Program.customers == null)
                return null;
            foreach (Customer c in Program.customers)
                if (c.getID() == this.customerIDTextBox.Text)
                    return c;
            return null;
        }

        private bool allFieldsWasInitilized()
        {
            return (projectIDWasInit() && projectNameWasInit() && projectCostWasInit() && projectEndTimeWasInit() && projectCostWasInit() && projectSimulationLocationWasInit()&&customerIdWasInit()&&managerIdWasInit());
        }

        private bool managerIdWasInit()
        {
            return this.manager != null;
        }

        private bool customerIdWasInit()
        {
            return this.customer != null;
        }

        private bool projectSimulationLocationWasInit()
        {
            return this.simulationLocation != null && this.simulationLocation.Length > 0;
        }

        private bool projectEndTimeWasInit()
        {
            return this.endTime != null;
        }

        private bool projectCostWasInit()
        {
            return this.cost != 0;
        }

        private bool projectNameWasInit()
        {
            return this.projectName != null && this.projectName.Length > 0  ;
        }

        private bool projectIDWasInit()
        {
            return this.projectID != null && this.projectID.Length > 0  ;
        }

        private void summaryProjectSetButton_Click(object sender, EventArgs e)
        {
            if (this.summaryTextBox.Text.Length <= 30)
            {
                this.summeryReport = this.summaryTextBox.Text;
                MessageBox.Show("Summary was add successfully");
            }
            else
            {
                MessageBox.Show("Summary must be less then 30 characters");

            }

        }

        private void setCustomerIdButton_Click(object sender, EventArgs e)
        {
            if (cusomerIdIsValid())
            {
                this.customer = seekCustomer();
                MessageBox.Show("Customer was added successfully");
            }
            else
            {

                this.customer = null;
                MessageBox.Show("Customer id was not found or not valid");

            }

        }

        private bool cusomerIdIsValid()
        {
            return this.customerIDTextBox.Text.Length > 0 && this.customerIDTextBox.Text.Length <= 10 && allNumbers(this.customerIDTextBox.Text) && custometIdExist();
        }

        private bool custometIdExist()
        {
            if (Program.customers == null)
                return false;
            foreach (Customer c in Program.customers)
                if (c.getID() == this.customerIDTextBox.Text)
                    return true;
            return false;


        }

        private void setComplexityButton_Click(object sender, EventArgs e)
        {
            if (int.Parse(this.textBox_CreateProj_CompLevel.Text) > 0 && int.Parse(this.textBox_CreateProj_CompLevel.Text) <= 5)
            {
                this.complexityLevel = int.Parse(this.textBox_CreateProj_CompLevel.Text);
                MessageBox.Show("Recommended end date is : "+Project.RecommendedProjectEndTime(int.Parse(this.textBox_CreateProj_CompLevel.Text)));


            }
            else
            {
                MessageBox.Show("Erro!! complexityLevel  un valid");
                this.textBox_CreateProj_CompLevel.Text = "";
            }

        }

        private void setSimulationLocationButton_Click(object sender, EventArgs e)
        {
            if (simulationLocationIsValid())
            {
                this.simulationLocation = this.textBox_CreateProj_CompLevel.Text;
                MessageBox.Show("Simulation location  was changed successfully");
            }
            else
            {
                MessageBox.Show("Error !!Simulation location  un valid");
                this.textBox_CreateProj_CompLevel.Text = "";

            }
        }

        private void managerIdButton_Click(object sender, EventArgs e)
        {
            if (managerIdIsValid()) {
                this.manager = seekEmployee(this.managerIdTextBox.Text);
                MessageBox.Show("Manager  was changed successfully");
            }

            else
            {



            }
        }

        private Employee seekEmployee(string id)
        {
            foreach (Employee e in Program.employees)
                if (e.getId() == id)
                    return e;

            return null;
        }

        private bool managerIdIsValid()
        {
            return managerIdTextBox != null && managerIdTextBox.Text.Length > 0 && managerIdTextBox.Text.Length <= 10 && idIsProjectManagerId();
        }

        private bool idIsProjectManagerId()
        {
            foreach (Employee e in Program.employees)
                if (e.getId() == this.managerIdTextBox.Text)
                    return e.getEmployeeType().ToString() == " Project_Manager";
            return false;

        }
    }
}
