﻿namespace WindowsFormsApp1
{
    partial class SimulationDeveloper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bbtn_SimuDev_WorkRequest = new System.Windows.Forms.Button();
            this.btn_SimuDev_ViewProject = new System.Windows.Forms.Button();
            this.Label_MarketMangWel_Hello = new System.Windows.Forms.Label();
            this.finishWorkButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bbtn_SimuDev_WorkRequest
            // 
            this.bbtn_SimuDev_WorkRequest.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbtn_SimuDev_WorkRequest.Location = new System.Drawing.Point(487, 220);
            this.bbtn_SimuDev_WorkRequest.Name = "bbtn_SimuDev_WorkRequest";
            this.bbtn_SimuDev_WorkRequest.Size = new System.Drawing.Size(172, 42);
            this.bbtn_SimuDev_WorkRequest.TabIndex = 6;
            this.bbtn_SimuDev_WorkRequest.Text = "Submit Work Request";
            this.bbtn_SimuDev_WorkRequest.UseVisualStyleBackColor = true;
            this.bbtn_SimuDev_WorkRequest.Click += new System.EventHandler(this.bbtn_SimuDev_WorkRequest_Click);
            // 
            // btn_SimuDev_ViewProject
            // 
            this.btn_SimuDev_ViewProject.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SimuDev_ViewProject.Location = new System.Drawing.Point(130, 220);
            this.btn_SimuDev_ViewProject.Name = "btn_SimuDev_ViewProject";
            this.btn_SimuDev_ViewProject.Size = new System.Drawing.Size(172, 42);
            this.btn_SimuDev_ViewProject.TabIndex = 5;
            this.btn_SimuDev_ViewProject.Text = "View Project";
            this.btn_SimuDev_ViewProject.UseVisualStyleBackColor = true;
            this.btn_SimuDev_ViewProject.Click += new System.EventHandler(this.btn_MarketMang_ReadEmp_Click);
            // 
            // Label_MarketMangWel_Hello
            // 
            this.Label_MarketMangWel_Hello.AutoSize = true;
            this.Label_MarketMangWel_Hello.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_MarketMangWel_Hello.Location = new System.Drawing.Point(59, 138);
            this.Label_MarketMangWel_Hello.Name = "Label_MarketMangWel_Hello";
            this.Label_MarketMangWel_Hello.Size = new System.Drawing.Size(389, 31);
            this.Label_MarketMangWel_Hello.TabIndex = 4;
            this.Label_MarketMangWel_Hello.Text = "Hello ! Please choose an action ..";
            // 
            // finishWorkButton
            // 
            this.finishWorkButton.Location = new System.Drawing.Point(351, 369);
            this.finishWorkButton.Name = "finishWorkButton";
            this.finishWorkButton.Size = new System.Drawing.Size(85, 58);
            this.finishWorkButton.TabIndex = 9;
            this.finishWorkButton.Text = "Finish Work";
            this.finishWorkButton.UseVisualStyleBackColor = true;
            this.finishWorkButton.Click += new System.EventHandler(this.finishWorkButton_Click);
            // 
            // SimulationDeveloper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.finishWorkButton);
            this.Controls.Add(this.bbtn_SimuDev_WorkRequest);
            this.Controls.Add(this.btn_SimuDev_ViewProject);
            this.Controls.Add(this.Label_MarketMangWel_Hello);
            this.Name = "SimulationDeveloper";
            this.Text = "SimulationDeveloper";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bbtn_SimuDev_WorkRequest;
        private System.Windows.Forms.Button btn_SimuDev_ViewProject;
        private System.Windows.Forms.Label Label_MarketMangWel_Hello;
        private System.Windows.Forms.Button finishWorkButton;
    }
}