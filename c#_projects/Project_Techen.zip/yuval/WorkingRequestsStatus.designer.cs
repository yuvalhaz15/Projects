﻿namespace WindowsFormsApp1
{
    partial class WorkingRequestsStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelRequessToApprove = new System.Windows.Forms.Label();
            this.btn_approveReq = new System.Windows.Forms.Button();
            this.workingRequestListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // labelRequessToApprove
            // 
            this.labelRequessToApprove.AutoSize = true;
            this.labelRequessToApprove.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRequessToApprove.Location = new System.Drawing.Point(259, 53);
            this.labelRequessToApprove.Name = "labelRequessToApprove";
            this.labelRequessToApprove.Size = new System.Drawing.Size(238, 28);
            this.labelRequessToApprove.TabIndex = 0;
            this.labelRequessToApprove.Text = "Requests To Approve";
            // 
            // btn_approveReq
            // 
            this.btn_approveReq.Location = new System.Drawing.Point(311, 304);
            this.btn_approveReq.Name = "btn_approveReq";
            this.btn_approveReq.Size = new System.Drawing.Size(117, 26);
            this.btn_approveReq.TabIndex = 2;
            this.btn_approveReq.Text = "Show Request";
            this.btn_approveReq.UseVisualStyleBackColor = true;
            this.btn_approveReq.Click += new System.EventHandler(this.btn_approveReq_Click);
            // 
            // workingRequestListBox
            // 
            this.workingRequestListBox.FormattingEnabled = true;
            this.workingRequestListBox.Location = new System.Drawing.Point(264, 131);
            this.workingRequestListBox.Name = "workingRequestListBox";
            this.workingRequestListBox.Size = new System.Drawing.Size(224, 121);
            this.workingRequestListBox.TabIndex = 3;
            this.workingRequestListBox.SelectedIndexChanged += new System.EventHandler(this.workingRequestListBox_SelectedIndexChanged);
            // 
            // WorkingRequestsStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.workingRequestListBox);
            this.Controls.Add(this.btn_approveReq);
            this.Controls.Add(this.labelRequessToApprove);
            this.Name = "WorkingRequestsStatus";
            this.Text = "WorkingRequestsStatus";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelRequessToApprove;
        private System.Windows.Forms.Button btn_approveReq;
        private System.Windows.Forms.ListBox workingRequestListBox;
    }
}