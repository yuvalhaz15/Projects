﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class EmployeesEnterMangement : Form
    {
        public EmployeesEnterMangement()
        {
            InitializeComponent();
        }



        private void btn_ProjectCRU_ExistingProj_Click(object sender, EventArgs e)
        {
            ProjectManageExitstingForm projectManageExitstingForm = new ProjectManageExitstingForm();
            this.Hide();
            projectManageExitstingForm.ShowDialog();
            this.Close();
        }

        private void btn_ProjMange_Back_Click(object sender, EventArgs e)
        {

            this.Hide();
            this.Close();
        }

        private void Label_EmpCrud_EmpManagement_Click(object sender, EventArgs e)
        {

        }

        private void btn_EmpCRU_NewEmp_Click(object sender, EventArgs e)
        {
            createEmployeeForm ceForm = new createEmployeeForm();
            ceForm.showForm();


        }

        private void btn_EmpCRU_ExistingEmp_Click(object sender, EventArgs e)
        {
            EmployeesManagementForm emForm = new EmployeesManagementForm();
            emForm.Show();
        }
    }
}
