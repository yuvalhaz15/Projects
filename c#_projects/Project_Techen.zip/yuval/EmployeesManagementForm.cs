﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class EmployeesManagementForm : Form
    {
        private Employee employeeToMakeActionON;
        private string employeeId;
        public EmployeesManagementForm()
        {
            InitializeComponent();
            addValuesToEmployeesList();
        }

        private void addValuesToEmployeesList()
        {
            foreach (Employee e in Program.employees)
                employeesList.Items.Add(e.getId());
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void employeesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.employeeId = this.employeesList.Text;
            employeeToMakeActionON = matchEmployeeToId();
        }

        private void checkDetailsButton_Click(object sender, EventArgs e)
        {
            if (employeeToMakeActionON != null)
                employeeToMakeActionON.readEmployee();
            else
                MessageBox.Show("Please select Employee");
        }


        private Employee matchEmployeeToId()
        {
            foreach (Employee e in Program.employees)
                if (this.employeeId == e.getId())
                    return e;
            return null;
        }

        private void editDetailsButton_Click(object sender, EventArgs e)
        {if(employeeToMakeActionON!=null)
            employeeToMakeActionON.updateEmployee();
            else
                MessageBox.Show("Please select Employee");
        }

        private void selectEmployeeLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
