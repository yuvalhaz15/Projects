﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CustomersMangementForm : Form
    {
        public CustomersMangementForm()
        {
            InitializeComponent();
        }

        

        private void btn_CustomerCRU_NewCustomer_Click(object sender, EventArgs e)
        {
            CreateCustomer createCustomer = new CreateCustomer();
            this.Hide();
            createCustomer.ShowDialog();
            this.Close();
        }

        private void btn_CustomerCRU_ExistingCust_Click(object sender, EventArgs e)
        {
            CustomerManageExistingForm CustomerManageExistingForm = new CustomerManageExistingForm();
            this.Hide();
            CustomerManageExistingForm.ShowDialog();
            this.Close();
        }

        private void btn_CustMange_Back_Click(object sender, EventArgs e)
        {
            MarketingManagrWelcome marketingManagrWelcome = new MarketingManagrWelcome();
            this.Hide();
            marketingManagrWelcome.ShowDialog();
            this.Close();
        }
    }
}
