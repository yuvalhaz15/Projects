﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public enum ProjectStatusEnum
    {
        Data_Analysing,
        First_Simulation,
        Waiting_For_Manager_Approval,
        Main_Simulation,
        Waiting_For_Customer_Approval,
        Data_Collecting,
        Schedule_Planning,
        Summary_Report_Writing,
        In_Archive

    }
}

