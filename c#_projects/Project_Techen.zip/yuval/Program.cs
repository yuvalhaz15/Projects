﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static System.Collections.Generic.List<Customer> customers;
        public static System.Collections.Generic.List<Project> ProjectsInArchive;
        public static System.Collections.Generic.List<Project> ProjectsInProgress;
        public static System.Collections.Generic.List<Assignment> assignments;
        public static System.Collections.Generic.List<Employee> employees;
        public static System.Collections.Generic.List<Calendar> calendars;
        public static System.Collections.Generic.List<Meeting> meetings;
        public static System.Collections.Generic.List<WorkingRequest> workingRequests;

        [STAThread]

        public static void initLists()//מילוי הרשימות מתוך בסיס הנתונים
        {

            init_customers();
            init_employees();//אתחול הרשימה של העובדים
            init_projects();//אתחול הרשימה של הפרויקטים
            init_Calendars();//אתחול הרשימה של הלקוחות
            init_Meetings();
            init_assignments();
            init_WorkingRequests();
        }

        private static void init_WorkingRequests()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_WorkingRequests";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            workingRequests = new List<WorkingRequest>();

            while (rdr.Read())
            {
                WorkingRequestEnumPurpose wrep = (WorkingRequestEnumPurpose)Enum.Parse(typeof(WorkingRequestEnumPurpose), rdr.GetValue(5).ToString());
                RequestStatusEnum rse = (RequestStatusEnum)Enum.Parse(typeof(RequestStatusEnum), rdr.GetValue(7).ToString());

                WorkingRequest wr = new WorkingRequest(seekEmployee(rdr.GetValue(0).ToString()), seekEmployee(rdr.GetValue(1).ToString()), rdr.GetValue(2).ToString(), DateTime.Parse(rdr.GetValue(3).ToString()), DateTime.Parse(rdr.GetValue(4).ToString()), wrep, rdr.GetValue(6).ToString(), rse, false);
                workingRequests.Add(wr);
            }
        }
        private static void init_Meetings()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Meetings";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            meetings = new List<Meeting>();

            while (rdr.Read())
            {
                MeetingPurposeEnum mpe = (MeetingPurposeEnum)Enum.Parse(typeof(MeetingPurposeEnum), rdr.GetValue(4).ToString());
                MeetingStatusEnum mse = (MeetingStatusEnum)Enum.Parse(typeof(MeetingStatusEnum), rdr.GetValue(6).ToString());
                Meeting m = new Meeting(matchDateToCalendar(DateTime.Parse(rdr.GetValue(0).ToString())), seekCustomer(rdr.GetValue(1).ToString()), DateTime.Parse(rdr.GetValue(2).ToString()), seekEmployee(rdr.GetValue(3).ToString()), mpe, rdr.GetValue(5).ToString(), mse, getAllEmployees(DateTime.Parse(rdr.GetValue(0).ToString()), rdr.GetValue(1).ToString(), DateTime.Parse(rdr.GetValue(2).ToString())), false);
                meetings.Add(m);
            }
        }

        private static List<Employee> getAllEmployees(DateTime date, string customerId, DateTime timeOfMeeting)
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_EmployeesInMeeting @meetingDate , @customerID , @timeOfMeeting ";
            c.Parameters.AddWithValue("@meetingDate", date);
            c.Parameters.AddWithValue("@customerID", customerId);
            c.Parameters.AddWithValue("@timeOfMeeting", timeOfMeeting);
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            List<Employee> employeesInMeeting = new List<Employee>();
            while (rdr.Read())
            {
                Employee em = seekEmployee(rdr.GetValue(0).ToString());
                employeesInMeeting.Add(em);

            }
            return employeesInMeeting;
        }
        private static Calendar matchDateToCalendar(DateTime dateTime)
        {
            foreach (Calendar c in calendars)
                if (c.getDate() == dateTime)
                    return c;

            return null;


        }

        private static void init_Calendars()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Calendars";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            calendars = new List<Calendar>();

            while (rdr.Read())
            {

                Calendar ca = new Calendar(DateTime.Parse(rdr.GetValue(0).ToString()), false);
                calendars.Add(ca);
            }



        }

        private static void init_assignments()
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Assignments";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            assignments = new List<Assignment>();
            while (rdr.Read())
            {
                Assignment a = new Assignment(DateTime.Parse(rdr.GetValue(0).ToString()), seekEmployee(rdr.GetValue(1).ToString()), seekEmployee(rdr.GetValue(2).ToString()), seekProject(rdr.GetValue(3).ToString()), rdr.GetValue(4).ToString(), DateTime.Parse(rdr.GetValue(5).ToString()), DateTime.Parse(rdr.GetValue(6).ToString()), false);
                assignments.Add(a);
            }
        }

        private static Project seekProject(string id)
        {
            foreach (Project p in ProjectsInArchive)
                if (p.getProjectID() == id)
                    return p;
            foreach (Project p in ProjectsInProgress)
                if (p.getProjectID() == id)
                    return p;

            return null;
        }

        public static void init_employees()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Employees";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            employees = new List<Employee>();

            while (rdr.Read())
            {
                EType T = (EType)Enum.Parse(typeof(EType), rdr.GetValue(1).ToString());
                Gender g = (Gender)Enum.Parse(typeof(Gender), rdr.GetValue(12).ToString());
                EStatus es = (EStatus)Enum.Parse(typeof(EStatus), rdr.GetValue(13).ToString());

                Employee e = new Employee(rdr.GetValue(0).ToString(), T, rdr.GetValue(2).ToString(), rdr.GetValue(3).ToString(), double.Parse(rdr.GetValue(4).ToString()), DateTime.Parse(rdr.GetValue(5).ToString()), rdr.GetValue(6).ToString(), rdr.GetValue(7).ToString(), rdr.GetValue(8).ToString(), rdr.GetValue(9).ToString(), rdr.GetValue(10).ToString(), rdr.GetValue(11).ToString(), g, es, rdr.GetValue(14).ToString(), int.Parse(rdr.GetValue(15).ToString()), seekEmployee(rdr.GetValue(16).ToString()), false);
                employees.Add(e);
            }
        }
        public static void init_customers()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_customers";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);

            customers = new List<Customer>();

            while (rdr.Read())
            {
                CustomerStatus S = (CustomerStatus)Enum.Parse(typeof(CustomerStatus), rdr.GetValue(2).ToString());

                Customer C = new Customer(rdr.GetValue(0).ToString(), rdr.GetValue(1).ToString(), S, rdr.GetValue(3).ToString(), rdr.GetValue(4).ToString(), rdr.GetValue(5).ToString(), DateTime.Parse(rdr.GetValue(6).ToString()), false);
                customers.Add(C);
            }
        }

        public static void init_projects()//מילוי המערך מתוך בסיס הנתונים
        {
            SqlCommand c = new SqlCommand();
            c.CommandText = "EXECUTE dbo.Get_all_Projects";
            SQL_CON SC = new SQL_CON();
            SqlDataReader rdr = SC.execute_query(c);
            ProjectsInArchive = new List<Project>();
            ProjectsInProgress = new List<Project>();

            while (rdr.Read())
            {
                ProjectStatusEnum pse = (ProjectStatusEnum)Enum.Parse(typeof(ProjectStatusEnum), rdr.GetValue(4).ToString());
                Project p = new Project(seekCustomer(rdr.GetValue(0).ToString()), rdr.GetValue(1).ToString(), rdr.GetValue(2).ToString(), seekEmployee(rdr.GetValue(3).ToString()), pse, DateTime.Parse(rdr.GetValue(5).ToString()), DateTime.Parse(rdr.GetValue(6).ToString()), int.Parse(rdr.GetValue(7).ToString()), double.Parse(rdr.GetValue(8).ToString()), DateTime.Parse(rdr.GetValue(9).ToString()), rdr.GetValue(10).ToString(), rdr.GetValue(11).ToString(), false);
                if (p.getStatus().ToString() == "In_Archive")
                    ProjectsInArchive.Add(p);
                else ProjectsInProgress.Add(p);
            }
        }

        //שיטה שמחפשת לקוח ברשימה לפי תעודת זהות
        public static Customer seekCustomer(string id)
        {
            foreach (Customer cu in customers)
            {
                if (cu.getID() == id)
                    return cu;
            }
            return null;
        }
        public static Employee seekEmployee(string id)
        {
            foreach (Employee e in employees)
            {
                if (e.getId() == id)
                    return e;
            }
            return null;
        }

        static void Main()
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            initLists();
            foreach (Customer c in customers)
                Console.WriteLine(c.get_cMail());
            DateTime myDate = new DateTime(2015, 12, 25, 10, 30, 45);
            //Employee e1 = new Employee("208436712", EType.CEO, "Yuval", "Hazan", 424444, myDate, "0544648589", "shimoni 4","hapoalim" ,"5838583","778", "hazan@fdefdsf.com", Gender.Male, EStatus.Current, "https://lioryyyyy", 5,seekEmployee("100"),true);

            Application.Run(new MainForm());


        }
        public static Calendar isCalendarExist(DateTime date)
        {
            foreach (Calendar c in calendars)
            {
                if (c.getDate() == date)
                    return c;
            }
            return null;
        }


    }
}