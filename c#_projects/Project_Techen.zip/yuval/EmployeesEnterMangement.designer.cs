﻿namespace WindowsFormsApp1
{
    partial class EmployeesEnterMangement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_EmpCRU_ExistingEmp = new System.Windows.Forms.Button();
            this.btn_EmpCRU_NewEmp = new System.Windows.Forms.Button();
            this.Label_EmpCrud_EmpManagement = new System.Windows.Forms.Label();
            this.btn_ProjMange_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_EmpCRU_ExistingEmp
            // 
            this.btn_EmpCRU_ExistingEmp.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EmpCRU_ExistingEmp.Location = new System.Drawing.Point(518, 276);
            this.btn_EmpCRU_ExistingEmp.Name = "btn_EmpCRU_ExistingEmp";
            this.btn_EmpCRU_ExistingEmp.Size = new System.Drawing.Size(179, 60);
            this.btn_EmpCRU_ExistingEmp.TabIndex = 5;
            this.btn_EmpCRU_ExistingEmp.Text = "Existing Employee";
            this.btn_EmpCRU_ExistingEmp.UseVisualStyleBackColor = true;
            this.btn_EmpCRU_ExistingEmp.Click += new System.EventHandler(this.btn_EmpCRU_ExistingEmp_Click);
            // 
            // btn_EmpCRU_NewEmp
            // 
            this.btn_EmpCRU_NewEmp.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EmpCRU_NewEmp.Location = new System.Drawing.Point(118, 276);
            this.btn_EmpCRU_NewEmp.Name = "btn_EmpCRU_NewEmp";
            this.btn_EmpCRU_NewEmp.Size = new System.Drawing.Size(184, 60);
            this.btn_EmpCRU_NewEmp.TabIndex = 4;
            this.btn_EmpCRU_NewEmp.Text = "New Employee";
            this.btn_EmpCRU_NewEmp.UseVisualStyleBackColor = true;
            this.btn_EmpCRU_NewEmp.Click += new System.EventHandler(this.btn_EmpCRU_NewEmp_Click);
            // 
            // Label_EmpCrud_EmpManagement
            // 
            this.Label_EmpCrud_EmpManagement.AutoSize = true;
            this.Label_EmpCrud_EmpManagement.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_EmpCrud_EmpManagement.Location = new System.Drawing.Point(217, 141);
            this.Label_EmpCrud_EmpManagement.Name = "Label_EmpCrud_EmpManagement";
            this.Label_EmpCrud_EmpManagement.Size = new System.Drawing.Size(385, 40);
            this.Label_EmpCrud_EmpManagement.TabIndex = 3;
            this.Label_EmpCrud_EmpManagement.Text = "Employees Management";
            this.Label_EmpCrud_EmpManagement.Click += new System.EventHandler(this.Label_EmpCrud_EmpManagement_Click);
            // 
            // btn_ProjMange_Back
            // 
            this.btn_ProjMange_Back.Location = new System.Drawing.Point(705, 406);
            this.btn_ProjMange_Back.Name = "btn_ProjMange_Back";
            this.btn_ProjMange_Back.Size = new System.Drawing.Size(83, 32);
            this.btn_ProjMange_Back.TabIndex = 6;
            this.btn_ProjMange_Back.Text = "Back";
            this.btn_ProjMange_Back.UseVisualStyleBackColor = true;
            this.btn_ProjMange_Back.Click += new System.EventHandler(this.btn_ProjMange_Back_Click);
            // 
            // EmployeesEnterMangement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_ProjMange_Back);
            this.Controls.Add(this.btn_EmpCRU_ExistingEmp);
            this.Controls.Add(this.btn_EmpCRU_NewEmp);
            this.Controls.Add(this.Label_EmpCrud_EmpManagement);
            this.Name = "EmployeesEnterMangement";
            this.Text = "ProjectManagementForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_EmpCRU_ExistingEmp;
        private System.Windows.Forms.Button btn_EmpCRU_NewEmp;
        private System.Windows.Forms.Label Label_EmpCrud_EmpManagement;
        private System.Windows.Forms.Button btn_ProjMange_Back;
    }
}