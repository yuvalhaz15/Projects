﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ProjectDetails : Form
    {
        private Project projectToShowDetails;
        public ProjectDetails(Project p)
        {
            InitializeComponent();
            this.projectToShowDetails = p;

        }

        internal void showForm()
        {
            this.initializeData();
            this.Show();
        }
        private void initializeData()
        {
            setIDTextBox();
            setNameTextBox();
            setEndTime();
            setCost();
            setSimulationTextBox();
            setCustomerIdTextBox();
            setSummaryTextBox();
            setManagerIdTextBox();
            setComplexityLevel();

        }

        private void setComplexityLevel()
        {
            this.textBox_CompLevel.Text = this.projectToShowDetails.getComplexityLevel()+"";
        }

        private void setManagerIdTextBox()
        {
            this.managerIdTextBox.Text = this.projectToShowDetails.getManager().getId();
        }

        private void setSummaryTextBox()
        {
            this.summaryTextBox.Text = this.projectToShowDetails.getSummaryReport();
        }

        private void setCustomerIdTextBox()
        {
            this.customerIDTextBox.Text = this.projectToShowDetails.getCustomer().getID();
        }

        private void setSimulationTextBox()
        {
            this.textBox_SimuLoc.Text = this.projectToShowDetails.getSimulationLocation();
        }

        private void setCost()
        {

            this.textBox_Cost.Text = this.projectToShowDetails.getCost() + "";

        }

        private void setEndTime()
        {
            this.endTimeTextBox.Text = this.projectToShowDetails.getEndTime() + "";
        }

        private void setNameTextBox()
        {
            this.textBox_CreateProj_Name.Text = this.projectToShowDetails.getProjectName();
        }

        private void setIDTextBox()
        {
            this.textBox_ProjectID.Text = this.projectToShowDetails.getProjectID();
        }
    }
}
