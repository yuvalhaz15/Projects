﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CreateNewMeeting : Form
    {
        private Customer customer;
        private Calendar calendar;
        private MeetingPurposeEnum meetingPurpose;
        private MeetingStatusEnum meetingStatus;
        private string additionalNote;
        private DateTime timeOfMeeting;
        private Employee createdBy;
        private List<Employee> employees;
        private DateTime date;

        public CreateNewMeeting(DateTime date)
        {
            InitializeComponent();
            foreach (Employee e in Program.employees)
                EmployeesBox.Items.Add(e.getId());
            PurposeBox.Items.Add(MeetingPurposeEnum.first_Meeting_With_A_Client);
            PurposeBox.Items.Add(MeetingPurposeEnum.matching_Expectations);
            PurposeBox.Items.Add(MeetingPurposeEnum.other);
            PurposeBox.Items.Add(MeetingPurposeEnum.price_Quote);
            PurposeBox.Items.Add(MeetingPurposeEnum.simulation_Presentation);
            PurposeBox.Items.Add(MeetingPurposeEnum.summary_Meeting);
            this.date = date;
            foreach (Customer c in Program.customers)
                CustomerBox.Items.Add(c.getID());
            calendar = Program.isCalendarExist(date);
            if (calendar == null)
            {
                calendar = new Calendar(this.date, true);
            }
            this.employees = new List<Employee>();

        }


        private void btn_CreateMeeting_Back_Click(object sender, EventArgs e)
        {
            PlanMeetings planMeetings = new PlanMeetings();
            this.Hide();
            planMeetings.ShowDialog();
            this.Close();
        }


        private void MyIDSet_Click(object sender, EventArgs e)
        {
            Employee em = Program.seekEmployee(MyIDTextBox.Text);
            if (em != null)
            {
                this.createdBy = em;
                MessageBox.Show("ID was found");
            }
            else MessageBox.Show("ID was not found");

        }


        private void btn_CreateMeeting_AddMeeting_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                Meeting m = new Meeting(this.calendar, this.customer, this.timeOfMeeting, this.createdBy, this.meetingPurpose, this.additionalNote, MeetingStatusEnum.future, this.employees, true);
            }
else
            MessageBox.Show("One or more feilds are missing");
        }

        private bool isValid()
        {
            return this.calendar.getDate() != null && this.customer != null && this.employees != null && this.additionalNote!=null && this.timeOfMeeting != null && this.createdBy!=null;
        }

        private void EmployeesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (EmployeesBox.Text != null)
                employees.Add(Program.seekEmployee(EmployeesBox.Text));
        }

        private void CustomerBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.customer = Program.seekCustomer(CustomerBox.Text);
        }




        private void MyIDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void MyIDSet1_Click(object sender, EventArgs e)
        {

        }

        private void NoteSet_Click(object sender, EventArgs e)
        {
            if (this.NoteTextBox.Text.Length <= 30)
            {
                this.additionalNote = NoteTextBox.Text;
                MessageBox.Show("note was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! note is unvalid");
                NoteTextBox.Text = "";

            }
        }

        private void PurposeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.meetingPurpose = matchStringToPurpose(PurposeBox.Text);
        }


        private MeetingPurposeEnum matchStringToPurpose(string text)
        {
            switch (text)
            {
                case "matching_Expectations":
                    return MeetingPurposeEnum.matching_Expectations;

                case "first_Meeting_With_A_Client":
                    return MeetingPurposeEnum.first_Meeting_With_A_Client;
                case "simulation_Presentation":
                    return MeetingPurposeEnum.simulation_Presentation;
                case "summary_Meeting":
                    return MeetingPurposeEnum.summary_Meeting;
                case "price_Quote":
                    return MeetingPurposeEnum.price_Quote;
                case "other":
                    return MeetingPurposeEnum.other;




            }
            return MeetingPurposeEnum.other;
        }

        private void MeetingTimeSet_Click(object sender, EventArgs e)
        {
            addCheckedItemsToEmployess();
            if (validTime(MeetingTimeTextBox.Text) && employees != null)
            {
                if (this.calendar.availableTimeForMeeting(DateTime.Parse(MeetingTimeTextBox.Text, System.Globalization.CultureInfo.CurrentCulture), employees))
                {
                    this.timeOfMeeting = DateTime.Parse(MeetingTimeTextBox.Text, System.Globalization.CultureInfo.CurrentCulture);
                    MessageBox.Show("Meeting time updated");
                }
                
            }
            else MessageBox.Show("Meeting time not updated");
        }

        private void addCheckedItemsToEmployess()
        {
            for (int i=0;i<this.EmployeesBox.Items.Count;i++)
            {
                if (this.EmployeesBox.GetItemChecked(i))
                {
                    this.employees.Add(Program.seekEmployee(this.EmployeesBox.Items[i].ToString()));

                }
            }

        }
        private bool validTime(string text)
        {
            if (text.Length != 5)
                return false;

            if (text[0] < '9' && text[0] >= '0' && text[1] <='9' && text[1] > '0'&& text[2]==':' && text[3] == '0' && text[4] == '0')
                return true;
            return false;
        }

        private void EmployeesBox_ControlAdded(object sender, ControlEventArgs e)
        {

        }
    }
}
