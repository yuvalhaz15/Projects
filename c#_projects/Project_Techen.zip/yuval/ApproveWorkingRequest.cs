﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class ApproveWorkingRequest : Form
    {
        private WorkingRequest workingRequestToShowDetails;
        public ApproveWorkingRequest(WorkingRequest wr)
        {
            InitializeComponent();
            this.workingRequestToShowDetails = wr;
            initfields();
        }

        private void initfields()
        {
            setRequestNum();
            setStartDate();
            setEnDate();
            setPurpose();
            setAdditionalNote();
        }

        private void setRequestNum()
        {
            this.TextBox_WorkReq_RequestNum.Text = this.workingRequestToShowDetails.getRequestNum();
        }
        private void setStartDate()
        {
            this.StartDateTextBox.Text = this.workingRequestToShowDetails.getStartDate() + "";
        }
        private void setEnDate()
        {
            this.EndDateTextBox.Text = this.workingRequestToShowDetails.getEndDate() + "";
        }
        private void setPurpose()
        {
            this.textBoxPurpose.Text = this.workingRequestToShowDetails.get_purpose() + "";
        }
        private void setAdditionalNote()
        {
            this.textBoxNote.Text = this.workingRequestToShowDetails.get_additionalComment();
        }

        private void btn_Approve_Click(object sender, EventArgs e)
        {
            workingRequestToShowDetails.set_RequestStatusEnum(RequestStatusEnum.Approved);
            MessageBox.Show("Request approved");
            this.Close();
        }

        private void btn_NotApprove_Click(object sender, EventArgs e)
        {
            workingRequestToShowDetails.set_RequestStatusEnum(RequestStatusEnum.DisApproved);
            MessageBox.Show("Request disapproved");

            this.Close();
        }

        private void btn_WorkReq_Back_Click(object sender, EventArgs e)
        {
            WorkingRequestsStatus workingRequestsStatus = new WorkingRequestsStatus();

            workingRequestsStatus.ShowDialog();

        }
    }
}

