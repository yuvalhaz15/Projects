﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class SimulationDeveloper : Form
    {
        private Employee simulationDeveloper;
        public SimulationDeveloper(Employee e)
        {
            InitializeComponent();
            this.simulationDeveloper = e;
        }

        private void btn_MarketMang_ReadEmp_Click(object sender, EventArgs e)
        {
            ReadProject rpForm = new ReadProject();
            rpForm.Show();
        }

        private void bbtn_SimuDev_WorkRequest_Click(object sender, EventArgs e)
        {
            WorkRequest workRequest = new WorkRequest();
            
            workRequest.ShowDialog();
           
        }

        private void finishWorkButton_Click(object sender, EventArgs e)
        {
            this.simulationDeveloper.exitFromWork(DateTime.Now);
            this.Close();

        }

       
    }
}
