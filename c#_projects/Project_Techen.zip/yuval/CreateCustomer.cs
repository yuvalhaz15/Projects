﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

  



    public partial class CreateCustomer : Form
    {
        private string customerID;
        private string customerName;
        private CustomerStatus status;
        private string cMail;
        private string cName;
        private string cPhone;
        private DateTime lastContact;
        public CreateCustomer()
        {
            InitializeComponent();
            setCustomerStatus();

        }

        private void setCustomerStatus()
        {
            this.status = CustomerStatus.During_Project;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (allFieldsWasInitilized())
            {
                Customer c = new Customer(this.customerID, this.customerName, this.status, this.cMail, this.cName, this.cPhone, DateTime.Now, true);
               MessageBox.Show("Customer added successfully");
            }
            else
                MessageBox.Show("One or more details are missing");

        }

        private bool allFieldsWasInitilized()
        {
            return (customerIDWasInit() && customerNameWasInit() && contactNameWasInit() && contactMailWasInit() && contactPhoneWasInit());
        }

        private bool contactPhoneWasInit()
        {
            return this.phoneNumberTextBox.Text != null && this.phoneNumberTextBox.Text.Length > 0;
        }

        private bool contactMailWasInit()
        {
            return this.emailTextBox.Text!=null&&this.emailTextBox.Text.Length > 0;
        }

        private bool contactNameWasInit()
        {
            return contactNameTextBox.Text != null && contactNameTextBox.Text.Length > 0;
        }

        private bool customerNameWasInit()
        {
            return cuastomerNameTextBox.Text != null && cuastomerNameTextBox.Text.Length > 0;
                }
        private bool customerIDWasInit()
        {
            return customerIDTextBox.Text != null && customerIDTextBox.Text.Length > 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CustomersMangementForm customersMangementForm = new CustomersMangementForm();
            this.Hide();
            customersMangementForm.ShowDialog();
            this.Close();
        }

        private void nameSetButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(this.cuastomerNameTextBox.Text)){
                this.customerName = this.cuastomerNameTextBox.Text;
                MessageBox.Show("Name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                this.cuastomerNameTextBox.Text = "";

            }

        }
        private bool allNumbers(string toCheck)
        {
            for (int i = 0; i < toCheck.Length; i++)

                if (toCheck[i] < '0' || toCheck[i] > '9')
                    return false;

            return true;
        }
        private bool nameIsValid(string name)
        {

            return allLetters(name) && name.Length > 0 && name.Length < 20;
        }
        private bool allLetters(string name)
        {
            for (int i = 0; i < name.Length; i++)

                if ((name[i] < 'a' || name[i] > 'z') && name[i] != ' ')
                    if ((name[i] < 'A' || name[i] > 'Z'))
                        return false;

            return true;
        }

        private void customerIdSetButton_Click(object sender, EventArgs e)
        {
            if (IdIsValid())
            {
                this.customerID = this.customerIDTextBox.Text;

                MessageBox.Show("Id was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! ID unvalid ");
                this.customerIDTextBox.Text = "";

            }


        }
        private bool idExist(String idToCheck)
        {
            if (Program.customers == null )
                return false;
            foreach (Customer c in Program.customers)
                if (idToCheck == c.getID())
                    return true;
           
            return false;
        }
        private bool IdIsValid()
        {
            return customerIDTextBox.Text.Length > 0 && customerIDTextBox.Text.Length <= 10 && allNumbers(customerIDTextBox.Text) && !idExist(customerIDTextBox.Text);

        }

        private void contactNameSetButton_Click(object sender, EventArgs e)
        {
            if (nameIsValid(this.contactNameTextBox.Text))
            {
                this.cName = this.contactNameTextBox.Text;
                MessageBox.Show("Name was changed successfully");

            }
            else
            {
                MessageBox.Show("Error!! Name can only contain letters ");
                this.contactNameTextBox.Text = "";

            }
        }

        private void emailSetButton_Click(object sender, EventArgs e)
        {
            if (emailIsValid(this.emailTextBox.Text))
            {
                this.cMail = this.emailTextBox.Text;
                MessageBox.Show("email was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! Email adress is not valid ");
                this.emailTextBox.Text = "";

            }
        }
        private bool emailIsValid(string email)
        {
            Regex rx = new Regex(
        @"^[-!#$%&'*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+/0-9=?A-Z^_a-z{|}~])*@[a-zA-Z](-?[a-zA-Z0-9])*(\.[a-zA-Z](-?[a-zA-Z0-9])*)+$");
            return rx.IsMatch(email) && email.Length <= 50;
        }

        private void phoneNumberSetButton_Click(object sender, EventArgs e)
        {

            if (phoneNumberIsValid())
            {
                this.cPhone = phoneNumberTextBox.Text;
                MessageBox.Show("phone number was changed successfully");
            }
            else
            {
                MessageBox.Show("Error!! The phone number must contain only numbers and must contain 10 digits ");
               
            }


        }
        private bool phoneNumberIsValid()
        {
            return allNumbers(phoneNumberTextBox.Text) && phoneNumberTextBox.Text.Length == 10;
        }
    }
}
